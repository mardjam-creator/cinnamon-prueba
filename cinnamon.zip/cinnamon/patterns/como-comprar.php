<?php
/**
 * Title: Cómo comprar
 * Slug: cinnamon/como-comprar
 * Categories: cinnamon
 *
 * @package cinnamon
 */

$info  = cinnamon_info();
$steps = array(
	array( 'Elegí tus productos', 'Elegí el peso de cada producto y agregalo al carrito.' ),
	array( 'Pagá como prefieras', 'Con Mercado Pago, QR o transferencia.' ),
	array( 'Recibilo o retiralo', 'Envío gratis en Montevideo y Ciudad de la Costa desde ' . $info['free_from'] . ', o retiro sin costo en el local.' ),
);
?>
<!-- wp:group {"className":"section section-tight","layout":{"type":"constrained"}} -->
<div class="wp-block-group section section-tight"><!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide section-head"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Envíos a domicilio</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Así de fácil es comprar</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"link-arrow"} -->
<p class="link-arrow"><a href="<?php echo esc_url( home_url( '/envios-a-domicilio/' ) ); ?>">Zonas y costos de envío <span aria-hidden="true">→</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:html -->
<ol class="steps alignwide">
<?php foreach ( $steps as $step ) : ?>
	<li class="step reveal"><h3><?php echo esc_html( $step[0] ); ?></h3><p><?php echo esc_html( $step[1] ); ?></p></li>
<?php endforeach; ?>
</ol>
<!-- /wp:html --></div>
<!-- /wp:group -->
