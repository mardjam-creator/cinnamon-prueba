<?php
/**
 * Title: Encabezado
 * Slug: cinnamon/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 *
 * @package cinnamon
 */

$info = cinnamon_info();
$json = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;

/**
 * Navigation link block markup.
 *
 * @param string $label Label.
 * @param string $url   URL.
 * @param string $class Extra class.
 */
$cinnamon_link = static function ( $label, $url, $class = '' ) use ( $json ) {
	$attrs = array( 'label' => $label, 'url' => $url, 'kind' => 'custom' );
	if ( $class ) {
		$attrs['className'] = $class;
	}
	return '<!-- wp:navigation-link ' . wp_json_encode( $attrs, $json ) . ' /-->';
};
$cinnamon_avisos = cinnamon_avisos_bar();
?>
<?php if ( $cinnamon_avisos ) : ?>
<!-- wp:html -->
<?php echo $cinnamon_avisos; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in cinnamon_avisos_bar(). ?>
<!-- /wp:html -->

<?php endif; ?>
<!-- wp:group {"className":"announce","layout":{"type":"constrained"}} -->
<div class="wp-block-group announce"><!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><strong>Envío gratis en Montevideo y Ciudad de la Costa</strong> en compras desde <?php echo esc_html( $info['free_from'] ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"site-header","layout":{"type":"constrained"}} -->
<div class="wp-block-group site-header"><!-- wp:group {"align":"wide","className":"header-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide header-row"><!-- wp:html -->
<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo.jpg' ) ); ?>" alt="Cinnamon boutique gourmet" width="416" height="115"></a>
<!-- /wp:html -->

<!-- wp:navigation {"overlayMenu":"mobile","className":"main-nav","layout":{"type":"flex","justifyContent":"center"}} -->
<!-- wp:navigation-submenu {"label":"Productos","url":"<?php echo esc_url( home_url( '/tienda/' ) ); ?>","kind":"custom","className":"mega-menu"} -->
<?php
// Mega menu: each top-level category is a column; its subcategories hang below it.
foreach ( cinnamon_category_tree() as $cat ) {
	if ( ! $cat['children'] ) {
		echo $cinnamon_link( $cat['name'], $cat['url'], 'mega-col' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- JSON-encoded.
		continue;
	}
	echo '<!-- wp:navigation-submenu ' . wp_json_encode( array( 'label' => $cat['name'], 'url' => $cat['url'], 'kind' => 'custom', 'className' => 'mega-col' ), $json ) . " -->\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	foreach ( $cat['children'] as $child ) {
		echo $cinnamon_link( $child['name'], $child['url'] ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo "<!-- /wp:navigation-submenu -->\n";
}
echo $cinnamon_link( 'Ver toda la tienda', home_url( '/tienda/' ), 'mega-all' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
?>
<!-- /wp:navigation-submenu -->
<?php
echo $cinnamon_link( 'Ofertas', home_url( '/ofertas/' ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
echo $cinnamon_link( 'Envíos', home_url( '/envios-a-domicilio/' ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
echo $cinnamon_link( 'Sobre nosotros', home_url( '/sobre-nosotros/' ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
echo $cinnamon_link( 'Contacto', home_url( '/contacto/' ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
?>
<!-- /wp:navigation -->

<!-- wp:group {"className":"header-actions","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group header-actions"><!-- wp:html -->
<button type="button" class="search-toggle" aria-expanded="false" aria-controls="site-search" aria-label="Buscar productos"><?php echo cinnamon_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
<a class="account-link" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/mi-cuenta/' ) ); ?>" aria-label="Mi cuenta"><?php echo cinnamon_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
<!-- /wp:html -->

<!-- wp:woocommerce/mini-cart {"className":"header-cart"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="site-search" id="site-search" hidden data-api="<?php echo esc_url( function_exists( 'cinnamon_tienda_search_suggestions_url' ) ? cinnamon_tienda_search_suggestions_url() : rest_url( 'wc/store/v1/products' ) ); ?>">
	<form class="site-search__form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<label class="screen-reader-text" for="site-search-input">Buscar productos</label>
		<input type="search" id="site-search-input" name="s" placeholder="Buscá almendras, chía, harinas…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="site-search-list" aria-autocomplete="list">
		<input type="hidden" name="post_type" value="product">
		<button type="submit" class="site-search__submit" aria-label="Buscar"><?php echo cinnamon_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
	</form>
	<ul class="site-search__list" id="site-search-list" role="listbox" aria-label="Sugerencias" hidden></ul>
	<p class="site-search__status screen-reader-text" aria-live="polite"></p>
</div>
<!-- /wp:html --></div>
<!-- /wp:group -->
