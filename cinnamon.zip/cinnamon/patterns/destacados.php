<?php
/**
 * Title: Productos destacados
 * Slug: cinnamon/destacados
 * Categories: cinnamon, woo-commerce
 *
 * Shows products marked as "Destacado" in WooCommerce.
 *
 * @package cinnamon
 */

?>
<!-- wp:group {"className":"section","layout":{"type":"constrained"}} -->
<div class="wp-block-group section"><!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide section-head"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Los más pedidos</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Destacados</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"link-arrow"} -->
<p class="link-arrow"><a href="<?php echo esc_url( home_url( '/tienda/' ) ); ?>">Ver toda la tienda <span aria-hidden="true">→</span></a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:shortcode -->
[products limit="6" columns="3" visibility="featured" orderby="menu_order" order="ASC"]
<!-- /wp:shortcode --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
