<?php
/**
 * Title: Portada
 * Slug: cinnamon/hero
 * Categories: cinnamon, banner
 *
 * @package cinnamon
 */

$info = cinnamon_info();
?>
<!-- wp:group {"className":"hero","layout":{"type":"constrained"}} -->
<div class="wp-block-group hero"><!-- wp:columns {"verticalAlignment":"center","align":"wide","className":"hero-grid"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center hero-grid"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Boutique gourmet en Montevideo</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title">Frutos secos, condimentos y harinas <em>a granel</em></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lead"} -->
<p class="hero-lead">Llevá la cantidad justa para tu cocina. Descuentos por cantidad y envío gratis en Montevideo desde <?php echo esc_html( $info['free_from'] ); ?>.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"hero-ctas"} -->
<div class="wp-block-buttons hero-ctas"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/tienda/' ) ); ?>">Comprar ahora</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/ofertas/' ) ); ?>">Ver ofertas</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:html -->
<?php
// Carousel: the news Cinnamon loads in Apariencia > Novedades de la portada
// (inc/novedades.php), or one fixed photo when there are none.
$slides = cinnamon_hero_slides();
$count  = count( $slides );
?>
<section class="hero-carousel" aria-roledescription="carrusel" aria-label="Novedades">
	<div class="hero-track" aria-live="off">
		<?php foreach ( $slides as $i => $slide ) : ?>
			<div class="hero-slide" role="group" aria-roledescription="diapositiva" aria-label="<?php echo esc_attr( sprintf( '%d de %d: %s', $i + 1, $count, $slide['title'] ) ); ?>">
				<?php echo $slide['url'] ? '<a class="hero-media" href="' . esc_url( $slide['url'] ) . '">' : '<div class="hero-media">'; ?>
					<img src="<?php echo esc_url( $slide['image'] ); ?>" alt="" width="1200" height="900" <?php echo 0 === $i ? 'fetchpriority="high"' : 'loading="lazy"'; ?>>
					<span class="hero-badge"><strong class="hero-badge__title"><?php echo esc_html( $slide['title'] ); ?></strong><?php if ( $slide['text'] ) : ?> <span class="hero-badge__deal"><?php echo esc_html( $slide['text'] ); ?></span><?php endif; ?><?php if ( $slide['price'] ) : ?> <span class="hero-badge__price price"><?php echo wp_kses_post( $slide['price'] ); ?></span><?php endif; ?><?php if ( $slide['note'] ) : ?> <span><?php echo esc_html( $slide['note'] ); ?></span><?php endif; ?></span>
				<?php echo $slide['url'] ? '</a>' : '</div>'; ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php if ( $count > 1 ) : ?>
	<div class="hero-controls" hidden>
		<button type="button" class="hero-arrow hero-prev" aria-label="Anterior"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg></button>
		<button type="button" class="hero-arrow hero-next" aria-label="Siguiente"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg></button>
		<div class="hero-dots">
			<?php foreach ( $slides as $i => $slide ) : ?>
				<button type="button" class="hero-dot" aria-label="<?php echo esc_attr( 'Ver ' . $slide['title'] ); ?>"<?php echo 0 === $i ? ' aria-current="true"' : ''; ?>></button>
			<?php endforeach; ?>
		</div>
	</div>
	<?php endif; ?>
</section>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
