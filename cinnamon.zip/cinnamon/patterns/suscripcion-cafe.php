<?php
/**
 * Title: Suscripción de café
 * Slug: cinnamon/suscripcion-cafe
 * Categories: cinnamon, call-to-action
 *
 * @package cinnamon
 */

$page = get_page_by_path( 'suscripcion-de-cafe' );
$url  = $page ? get_permalink( $page ) : home_url( '/suscripcion-de-cafe/' );
?>
<!-- wp:group {"className":"section section-tight","layout":{"type":"constrained"}} -->
<div class="wp-block-group section section-tight"><!-- wp:columns {"align":"wide","className":"bulk reveal"} -->
<div class="wp-block-columns alignwide bulk reveal"><!-- wp:column {"verticalAlignment":"center","width":"55%","className":"bulk-copy"} -->
<div class="wp-block-column is-vertically-aligned-center bulk-copy" style="flex-basis:55%"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Suscripción de café</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Tu café de especialidad, <em>siempre en casa</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Elegí tu café, cuánto y cómo lo molemos, y recibilo todos los meses. Envío incluido en Montevideo y Ciudad de la Costa.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn-light" href="<?php echo esc_url( $url ); ?>">Quiero suscribirme</a>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%","className":"bulk-media"} -->
<div class="wp-block-column bulk-media" style="flex-basis:45%"><!-- wp:html -->
<img class="bulk-media--cafe" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/suscripcion-cafe.jpg' ) ); ?>" alt="" loading="lazy">
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
