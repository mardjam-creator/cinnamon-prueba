<?php
/**
 * Title: Beneficios
 * Slug: cinnamon/beneficios
 * Categories: cinnamon
 *
 * @package cinnamon
 */

$info  = cinnamon_info();
$items = array(
	array( 'truck', 'Envío gratis', 'En Montevideo y Ciudad de la Costa, desde ' . $info['free_from'] ),
	array( 'store', 'Retiro sin costo', $info['address'] . ', de lunes a viernes de 10 a 19 h' ),
	array( 'card', 'Pago seguro', 'Mercado Pago, QR o transferencia' ),
);
?>
<!-- wp:group {"className":"trust","layout":{"type":"constrained"}} -->
<div class="wp-block-group trust"><!-- wp:html -->
<div class="trust-grid alignwide">
<?php foreach ( $items as $item ) : ?>
	<div class="trust-item"><?php echo cinnamon_icon( $item[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?><div><h2><?php echo esc_html( $item[1] ); ?></h2><p><?php echo esc_html( $item[2] ); ?></p></div></div>
<?php endforeach; ?>
</div>
<!-- /wp:html --></div>
<!-- /wp:group -->
