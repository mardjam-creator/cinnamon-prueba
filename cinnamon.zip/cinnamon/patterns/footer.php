<?php
/**
 * Title: Pie de página
 * Slug: cinnamon/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 *
 * @package cinnamon
 */

$info = cinnamon_info();
?>
<!-- wp:group {"className":"site-footer","layout":{"type":"constrained"}} -->
<div class="wp-block-group site-footer"><!-- wp:columns {"align":"wide","className":"footer-grid"} -->
<div class="wp-block-columns alignwide footer-grid"><!-- wp:column {"width":"40%","className":"footer-brand"} -->
<div class="wp-block-column footer-brand" style="flex-basis:40%"><!-- wp:html -->
<img class="footer-logo" src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo.jpg' ) ); ?>" alt="Cinnamon boutique gourmet" width="416" height="115" loading="lazy">
<!-- /wp:html -->

<!-- wp:paragraph -->
<p>Frutos secos, condimentos, harinas, semillas y productos sin gluten. Una empresa familiar desde 2018.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php echo esc_html( $info['address'] . ', ' . $info['city'] ); ?><br><?php echo esc_html( $info['hours'] ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"footer-title"} -->
<h2 class="wp-block-heading footer-title">Cinnamon</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"footer-links"} -->
<ul class="wp-block-list footer-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/tienda/' ) ); ?>">Tienda</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/sobre-nosotros/' ) ); ?>">Sobre nosotros</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/envios-a-domicilio/' ) ); ?>">Envíos a domicilio</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/politica-de-privacidad/' ) ); ?>">Política de privacidad</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/mi-cuenta/' ) ); ?>">Mi cuenta</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"footer-title"} -->
<h2 class="wp-block-heading footer-title">Escribinos</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"footer-links"} -->
<ul class="wp-block-list footer-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( cinnamon_whatsapp_url() ); ?>" target="_blank" rel="noopener">WhatsApp <?php echo esc_html( $info['whatsapp'] ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( $info['phone_href'] ); ?>">Teléfono <?php echo esc_html( $info['phone'] ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="mailto:<?php echo esc_attr( $info['email'] ); ?>"><?php echo esc_html( $info['email'] ); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( $info['instagram_url'] ); ?>" target="_blank" rel="noopener">Instagram <?php echo esc_html( $info['instagram'] ); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"footer-bottom","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide footer-bottom"><!-- wp:paragraph -->
<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> Cinnamon Boutique Gourmet. Montevideo, Uruguay.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"pay"} -->
<p class="pay"><span>Mercado Pago</span> <span>QR</span> <span>Transferencia</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
