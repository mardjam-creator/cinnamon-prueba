<?php
/**
 * Title: Categorías
 * Slug: cinnamon/categorias
 * Categories: cinnamon, woo-commerce
 *
 * @package cinnamon
 */

$cards = array(
	array( 'frutos-secos', 'Frutos secos', 'Con descuento desde 500 g', 'frutos-secos.jpg' ),
	array( 'harinas-y-moliendas', 'Harinas y moliendas', 'Para hornear y cocinar', 'harinas.jpg' ),
	array( 'condimentos', 'Condimentos', 'A granel y en molinillos', 'especias.jpg' ),
	array( 'semillas-y-granos', 'Semillas y granos', 'Para tus desayunos y ensaladas', 'semillas.jpg' ),
	array( 'sin-gluten', 'Sin gluten', 'Harinas, panificados, pastas y snacks', 'sin-gluten.jpg' ),
	array( 'sin-azucar', 'Sin azúcar', 'Opciones sin azúcar agregada', 'sin-azucar.jpg' ),
	array( 'cereales-y-granolas', 'Cereales y granolas', 'Para empezar el día', 'cereales.jpg' ),
);
?>
<!-- wp:group {"className":"section section-tight","layout":{"type":"constrained"}} -->
<div class="wp-block-group section section-tight"><!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide section-head"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">La tienda</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Elegí por categoría</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"section-lead"} -->
<p class="section-lead">Todo lo que necesitás para cocinar, hornear y desayunar rico.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="cats alignwide">
<?php foreach ( $cards as $i => $card ) : ?>
	<a class="cat reveal<?php echo 0 === $i ? ' cat-large' : ''; ?>" href="<?php echo esc_url( cinnamon_category_url( $card[0] ) ); ?>">
		<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/' . $card[3] ) ); ?>" alt="" loading="lazy">
		<span class="cat-body"><span class="cat-title"><?php echo esc_html( $card[1] ); ?></span><span class="cat-blurb"><?php echo esc_html( $card[2] ); ?></span></span>
	</a>
<?php endforeach; ?>
</div>
<!-- /wp:html --></div>
<!-- /wp:group -->
