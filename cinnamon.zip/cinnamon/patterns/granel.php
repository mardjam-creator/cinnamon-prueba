<?php
/**
 * Title: Compra a granel
 * Slug: cinnamon/granel
 * Categories: cinnamon, call-to-action
 *
 * @package cinnamon
 */

?>
<!-- wp:group {"className":"section section-tight","layout":{"type":"constrained"}} -->
<div class="wp-block-group section section-tight"><!-- wp:columns {"align":"wide","className":"bulk reveal"} -->
<div class="wp-block-columns alignwide bulk reveal"><!-- wp:column {"verticalAlignment":"center","width":"55%","className":"bulk-copy"} -->
<div class="wp-block-column is-vertically-aligned-center bulk-copy" style="flex-basis:55%"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Compra a granel</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Cuanto más llevás, <em>menos pagás</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Fraccionamos nuestros productos a granel en distintas presentaciones. Llevando 500 g o 1 kg, el precio por kilo baja. ¿Necesitás más cantidad? Escribinos.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="btn-wa" href="<?php echo esc_url( cinnamon_whatsapp_url( 'Hola Cinnamon, quiero consultar precios por kilo' ) ); ?>" target="_blank" rel="noopener"><?php echo cinnamon_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> Consultar precios por kilo</a>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%","className":"bulk-media"} -->
<div class="wp-block-column bulk-media" style="flex-basis:45%"><!-- wp:html -->
<img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/frutos-secos.jpg' ) ); ?>" alt="" loading="lazy">
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
