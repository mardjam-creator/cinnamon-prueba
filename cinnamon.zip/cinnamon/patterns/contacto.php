<?php
/**
 * Title: Visitanos
 * Slug: cinnamon/contacto
 * Categories: cinnamon
 *
 * @package cinnamon
 */

$info     = cinnamon_info();
$channels = array(
	array( 'whatsapp', 'WhatsApp', $info['whatsapp'], cinnamon_whatsapp_url() ),
	array( 'phone', 'Teléfono', $info['phone'], $info['phone_href'] ),
	array( 'mail', 'Mail', $info['email'], 'mailto:' . $info['email'] ),
	array( 'instagram', 'Instagram', $info['instagram'], $info['instagram_url'] ),
);
?>
<!-- wp:group {"anchor":"visitanos","className":"section section-tight","layout":{"type":"constrained"}} -->
<div id="visitanos" class="wp-block-group section section-tight"><!-- wp:columns {"align":"wide","className":"visit"} -->
<div class="wp-block-columns alignwide visit"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow">Contacto</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Visitanos o escribinos</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"visit-lead"} -->
<p class="visit-lead">Estamos en <?php echo esc_html( $info['address'] . ', ' . $info['city'] ); ?>. <?php echo esc_html( $info['hours'] ); ?>. Te asesoramos en persona, por teléfono o por WhatsApp.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"visit-ctas"} -->
<div class="wp-block-buttons visit-ctas"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $info['maps_url'] ); ?>" target="_blank" rel="noreferrer noopener">Cómo llegar</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $info['waze_url'] ); ?>" target="_blank" rel="noreferrer noopener">Abrir en Waze</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:html -->
<ul class="contact-list">
<?php foreach ( $channels as $c ) : ?>
	<li><a href="<?php echo esc_url( $c[3] ); ?>"<?php echo 0 === strpos( $c[3], 'http' ) ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo cinnamon_icon( $c[0] ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><small><?php echo esc_html( $c[1] ); ?></small><b><?php echo esc_html( $c[2] ); ?></b></span></a></li>
<?php endforeach; ?>
</ul>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
