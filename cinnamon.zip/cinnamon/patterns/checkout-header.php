<?php
/**
 * Title: Encabezado del checkout
 * Slug: cinnamon/checkout-header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 *
 * Replaces WooCommerce's checkout header (site name in text) with the logo.
 *
 * @package cinnamon
 */

?>
<!-- wp:group {"className":"site-header checkout-header","layout":{"type":"constrained"}} -->
<div class="wp-block-group site-header checkout-header"><!-- wp:group {"align":"wide","className":"header-row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide header-row"><!-- wp:html -->
<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/logo.jpg' ) ); ?>" alt="Cinnamon boutique gourmet" width="416" height="115"></a>
<!-- /wp:html -->

<!-- wp:woocommerce/cart-link {"content":"","className":"checkout-cart-link"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
