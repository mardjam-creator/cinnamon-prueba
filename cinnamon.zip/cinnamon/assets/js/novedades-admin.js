/* Apariencia > Novedades de la portada: pick photos, add, move and remove rows. */
(function ($) {
	'use strict';

	var list = document.getElementById('cinnamon-novedades-list');
	var template = document.getElementById('cinnamon-novedades-template');
	if (!list || !template) return;

	document.getElementById('cinnamon-novedades-add').addEventListener('click', function () {
		list.appendChild(template.content.cloneNode(true));
		var rows = list.querySelectorAll('.cin-nov');
		rows[rows.length - 1].querySelector('[data-field="title"]').focus();
	});

	list.addEventListener('click', function (e) {
		var row = e.target.closest('.cin-nov');
		if (!row) return;
		if (e.target.closest('.cin-nov__up') && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
		else if (e.target.closest('.cin-nov__down') && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
		else if (e.target.closest('.cin-nov__remove')) row.remove();
		else if (e.target.closest('.cin-nov__pick')) pick(row);
	});

	// Photo from the media library.
	function pick(row) {
		var frame = wp.media({ title: 'Elegí la foto de la novedad', button: { text: 'Usar esta foto' }, library: { type: 'image' }, multiple: false });
		frame.on('select', function () {
			var photo = frame.state().get('selection').first().toJSON();
			row.querySelector('[data-field="image"]').value = photo.id;
			var url = (photo.sizes && (photo.sizes.medium || photo.sizes.full) || photo).url;
			row.querySelector('.cin-nov__preview').style.backgroundImage = 'url("' + url + '")';
		});
		frame.open();
	}

	// Names get their index on submit, so the order on screen is the order saved.
	document.getElementById('cinnamon-novedades-form').addEventListener('submit', function () {
		list.querySelectorAll('.cin-nov').forEach(function (row, i) {
			row.querySelectorAll('[data-field]').forEach(function (field) {
				field.name = 'novedades[' + i + '][' + field.dataset.field + ']';
			});
		});
	});
})(window.jQuery);
