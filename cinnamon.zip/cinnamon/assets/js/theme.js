/* Cinnamon theme: scroll reveals, weight buttons, header search and the front-page carousel. */
(function () {
	'use strict';

	// Fade elements in the first time they scroll into view.
	var revealed = document.querySelectorAll('.reveal');
	if ('IntersectionObserver' in window && revealed.length) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				io.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -8% 0px' });
		revealed.forEach(function (el, i) {
			el.style.transitionDelay = (i % 3) * 70 + 'ms';
			io.observe(el);
		});
	} else {
		revealed.forEach(function (el) { el.classList.add('is-visible'); });
	}

	// Variation selects ("Peso: 100 g / 500 g / 1 kg") become a row of buttons.
	// The select stays in the form, so WooCommerce keeps working as usual.
	function setSelect(select, value) {
		select.value = value;
		if (window.jQuery) window.jQuery(select).trigger('change');
		else select.dispatchEvent(new Event('change', { bubbles: true }));
	}

	function buildButtons(wrap) {
		var select = wrap.querySelector('select');
		if (!select || wrap.classList.contains('has-buttons')) return;
		var options = Array.prototype.filter.call(select.options, function (o) { return o.value; });
		if (!options.length) return;

		var group = document.createElement('div');
		group.className = 'variation-buttons';
		group.setAttribute('role', 'radiogroup');
		var label = document.querySelector('label[for="' + select.id + '"]');
		if (label) group.setAttribute('aria-label', label.textContent.trim());

		options.forEach(function (option) {
			var button = document.createElement('button');
			button.type = 'button';
			button.textContent = option.textContent;
			button.dataset.value = option.value;
			button.setAttribute('role', 'radio');
			button.addEventListener('click', function () {
				setSelect(select, select.value === option.value ? '' : option.value);
			});
			group.appendChild(button);
		});

		function sync() {
			Array.prototype.forEach.call(group.children, function (b) {
				var on = b.dataset.value === select.value;
				b.setAttribute('aria-checked', on ? 'true' : 'false');
				b.tabIndex = on || (!select.value && b === group.firstChild) ? 0 : -1;
			});
		}
		select.addEventListener('change', sync);
		if (window.jQuery) window.jQuery(select).on('change', sync);

		wrap.appendChild(group);
		wrap.classList.add('has-buttons');
		select.setAttribute('tabindex', '-1');
		select.setAttribute('aria-hidden', 'true');
		sync();
	}

	// "¡Oferta!" badge of weight products: shown when the chosen weight is on
	// sale (labels per weight come from the theme's PHP in data-labels). The
	// percentage is part of the weight's price, next to it.
	function setDiscountBadge(scope, variationId) {
		var badge = scope && scope.querySelector('.badge-discount[data-labels]');
		if (!badge) return;
		var labels = JSON.parse(badge.dataset.labels || '{}');
		var label = variationId ? labels[variationId] || '' : badge.dataset.initial;
		badge.textContent = label;
		badge.hidden = !label;
	}

	// Product page: WooCommerce's variation form says which weight is chosen.
	if (window.jQuery) {
		window.jQuery(document.body)
			.on('found_variation', '.variations_form', function (e, variation) {
				setDiscountBadge(this.closest('.product'), variation.variation_id);
			})
			.on('reset_data', '.variations_form', function () {
				setDiscountBadge(this.closest('.product'), null);
			});
	}

	// Product cards: picking a weight updates the price, the discount badge and
	// points the "Agregar al carrito" button at that variation.
	document.addEventListener('click', function (e) {
		var option = e.target.closest('.lv-option');
		if (!option || option.disabled) return;
		var card = option.closest('.lv');
		card.querySelectorAll('.lv-option').forEach(function (b) {
			var on = b === option;
			b.setAttribute('aria-checked', on ? 'true' : 'false');
			b.tabIndex = on ? 0 : -1;
		});
		card.querySelector('.lv-price').innerHTML = option.dataset.price;

		var add = card.querySelector('.lv-add');
		var id = option.dataset.variationId;
		setDiscountBadge(card.closest('.product'), id);
		add.setAttribute('data-product_id', id);
		if (window.jQuery) window.jQuery(add).data('product_id', id); // WooCommerce reads jQuery's cached data.
		add.href = add.href.replace(/([?&]add-to-cart=)\d+/, '$1' + id);
		add.setAttribute('aria-label', add.getAttribute('aria-label').replace(/, [^,]+, al carrito$/, ', ' + option.textContent.trim() + ', al carrito'));
		add.classList.remove('added');
		var viewCart = card.querySelector('.added_to_cart');
		if (viewCart) viewCart.remove();
	});

	// Arrow keys move between weights, as in a native radio group.
	document.addEventListener('keydown', function (e) {
		var option = e.target.closest && e.target.closest('.lv-option');
		if (!option || ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].indexOf(e.key) < 0) return;
		var all = Array.prototype.filter.call(option.parentNode.children, function (b) { return !b.disabled; });
		var step = e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 1;
		var next = all[(all.indexOf(option) + step + all.length) % all.length];
		e.preventDefault();
		next.focus();
		next.click();
	});

	// Header search: the magnifier opens a bar under the header with product
	// suggestions from the Store API while typing.
	function initSearch() {
		var toggle = document.querySelector('.search-toggle');
		var panel = document.getElementById('site-search');
		if (!toggle || !panel) return;
		var form = panel.querySelector('form');
		var input = panel.querySelector('input[name="s"]');
		var list = panel.querySelector('.site-search__list');
		var status = panel.querySelector('.site-search__status');
		var api = panel.getAttribute('data-api');
		var timer = null;
		var controller = null;
		var active = -1;

		function setOpen(open) {
			panel.hidden = !open;
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) input.focus();
			else hideList();
		}
		function hideList() {
			list.hidden = true;
			list.innerHTML = '';
			input.setAttribute('aria-expanded', 'false');
			input.removeAttribute('aria-activedescendant');
			active = -1;
		}
		function searchUrl(q) {
			return form.action + '?s=' + encodeURIComponent(q) + '&post_type=product';
		}
		function decode(html) {
			var t = document.createElement('textarea');
			t.innerHTML = html;
			return t.value;
		}
		function option(id, href, inner) {
			var li = document.createElement('li');
			li.id = id;
			li.setAttribute('role', 'option');
			var a = document.createElement('a');
			a.href = href;
			a.tabIndex = -1;
			a.innerHTML = inner;
			li.appendChild(a);
			return li;
		}
		function render(q, products) {
			list.innerHTML = '';
			active = -1;
			products.forEach(function (p, i) {
				var img = p.images && p.images[0] ? (p.images[0].thumbnail || p.images[0].src) : '';
				// price_html is markup WooCommerce renders on this server; the name and image go in as text/attributes.
				var li = option('site-search-opt-' + i, p.permalink,
					'<span class="site-search__noimg"></span><span class="site-search__name"></span><span class="site-search__price">' + (p.price_html || '') + '</span>');
				li.querySelector('.site-search__name').textContent = decode(p.name);
				if (img) {
					var el = document.createElement('img');
					el.src = img; el.alt = ''; el.width = 48; el.height = 48; el.loading = 'lazy';
					li.querySelector('.site-search__noimg').replaceWith(el);
				}
				list.appendChild(li);
			});
			if (products.length) {
				var all = option('site-search-opt-all', searchUrl(q), '<span class="site-search__all"></span>');
				all.querySelector('.site-search__all').textContent = 'Ver todos los resultados para “' + q + '”';
				list.appendChild(all);
				status.textContent = products.length === 1 ? '1 sugerencia' : products.length + ' sugerencias';
			} else {
				var none = document.createElement('li');
				none.className = 'site-search__empty';
				none.textContent = 'No encontramos productos para “' + q + '”.';
				list.appendChild(none);
				status.textContent = 'Sin sugerencias';
			}
			list.hidden = false;
			input.setAttribute('aria-expanded', 'true');
		}
		function suggest() {
			var q = input.value.trim();
			if (q.length < 2) { hideList(); return; }
			if (controller) controller.abort();
			controller = 'AbortController' in window ? new AbortController() : null;
			fetch(api + (api.indexOf('?') < 0 ? '?' : '&') + 'per_page=6&search=' + encodeURIComponent(q), controller ? { signal: controller.signal } : {})
				.then(function (r) { return r.ok ? r.json() : []; })
				.then(function (products) { if (input.value.trim() === q) render(q, products); })
				.catch(function () {});
		}
		function move(step) {
			var items = list.querySelectorAll('[role="option"]');
			if (!items.length) return;
			if (active >= 0) items[active].classList.remove('is-active');
			active = (active + step + items.length) % items.length;
			items[active].classList.add('is-active');
			input.setAttribute('aria-activedescendant', items[active].id);
			items[active].scrollIntoView({ block: 'nearest' });
		}

		toggle.addEventListener('click', function () { setOpen(panel.hidden); });
		input.addEventListener('input', function () {
			clearTimeout(timer);
			timer = setTimeout(suggest, 250);
		});
		input.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
			else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
			else if (e.key === 'Enter' && active >= 0) {
				e.preventDefault();
				window.location.assign(list.querySelectorAll('[role="option"]')[active].querySelector('a').href);
			}
		});
		form.addEventListener('submit', function (e) {
			if (!input.value.trim()) { e.preventDefault(); input.focus(); }
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !panel.hidden) { setOpen(false); toggle.focus(); }
		});
		document.addEventListener('click', function (e) {
			if (!panel.hidden && !panel.contains(e.target) && !toggle.contains(e.target)) setOpen(false);
		});
	}

	// Front-page carousel: moves on every 5 s, pauses while hovered, focused or
	// touched, and never moves on its own with reduced motion. The track is a
	// scroll-snap row, so swiping works natively and without JS.
	function initCarousel() {
		var root = document.querySelector('.hero-carousel');
		if (!root) return;
		var track = root.querySelector('.hero-track');
		var slides = root.querySelectorAll('.hero-slide');
		var dots = root.querySelectorAll('.hero-dot');
		if (slides.length < 2) return;
		root.querySelector('.hero-controls').hidden = false;

		var still = window.matchMedia('(prefers-reduced-motion: reduce)');
		var current = 0, timer = null, hovered = false, focused = false, touched = false, settle;

		function mark(i) {
			current = i;
			slides.forEach(function (slide, n) {
				slide.setAttribute('aria-hidden', n === i ? 'false' : 'true');
				slide.querySelectorAll('a').forEach(function (a) { a.tabIndex = n === i ? 0 : -1; });
			});
			dots.forEach(function (dot, n) {
				if (n === i) dot.setAttribute('aria-current', 'true');
				else dot.removeAttribute('aria-current');
			});
		}
		function go(i) {
			i = (i + slides.length) % slides.length;
			track.scrollTo({ left: i * track.clientWidth, behavior: still.matches ? 'auto' : 'smooth' });
			mark(i);
		}
		function stop() {
			clearInterval(timer);
			timer = null;
			track.setAttribute('aria-live', 'polite');
		}
		function start() {
			stop();
			if (still.matches || hovered || focused || touched || document.hidden) return;
			timer = setInterval(function () { go(current + 1); }, 5000);
			track.setAttribute('aria-live', 'off');
		}

		root.querySelector('.hero-prev').addEventListener('click', function () { go(current - 1); start(); });
		root.querySelector('.hero-next').addEventListener('click', function () { go(current + 1); start(); });
		dots.forEach(function (dot, n) {
			dot.addEventListener('click', function () { go(n); start(); });
		});
		root.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') { e.preventDefault(); go(current - 1); }
			else if (e.key === 'ArrowRight') { e.preventDefault(); go(current + 1); }
		});

		root.addEventListener('mouseenter', function () { hovered = true; stop(); });
		root.addEventListener('mouseleave', function () { hovered = false; start(); });
		root.addEventListener('focusin', function () { focused = true; stop(); });
		root.addEventListener('focusout', function (e) {
			if (root.contains(e.relatedTarget)) return;
			focused = false;
			start();
		});
		// After a touch the customer is in control: no more automatic moves.
		root.addEventListener('touchstart', function () { touched = true; stop(); }, { passive: true });
		document.addEventListener('visibilitychange', start);
		if (still.addEventListener) still.addEventListener('change', start);

		// Keep the dots in sync with swipes, and the slide in place on resize.
		track.addEventListener('scroll', function () {
			clearTimeout(settle);
			settle = setTimeout(function () {
				var i = Math.round(track.scrollLeft / track.clientWidth);
				if (i !== current) mark(i);
			}, 100);
		}, { passive: true });
		window.addEventListener('resize', function () { track.scrollLeft = current * track.clientWidth; });

		mark(0);
		start();
	}

	// Same as cinnamon_avisos_countdown() in inc/avisos.php.
	function countdown(ms) {
		var s = Math.max(0, Math.floor(ms / 1000)), d = Math.floor(s / 86400), pad = function (n) { return String(n).padStart(2, '0'); };
		s %= 86400;
		return 'Termina en ' + (d ? d + ' d ' : '') + pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60);
	}

	// Promo bar: the page may come from a cache, so the browser decides which
	// notice is current (first one whose times include now) and re-checks every
	// second, which also moves the countdown.
	function initPromoBar() {
		var items = document.querySelectorAll('.promo-bar__item');
		if (!items.length) return;
		function update() {
			var now = Date.now(), shown = false;
			items.forEach(function (item) {
				var from = Number(item.dataset.from) || 0;
				var until = item.dataset.until ? Number(item.dataset.until) : Infinity;
				var current = !shown && from <= now && now < until;
				item.hidden = !current;
				shown = shown || current;
				var clock = current && item.querySelector('.promo-bar__countdown');
				if (clock) clock.textContent = countdown(until - now);
			});
		}
		update();
		setInterval(update, 1000);
	}

	function init() {
		document.querySelectorAll('.variation-select').forEach(buildButtons);
		initSearch();
		initCarousel();
		initPromoBar();
	}
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
	else init();
})();
