/* Apariencia > Franja de avisos: add, move and remove rows, mark words and preview each notice. */
(function () {
	'use strict';

	var list = document.getElementById('cinnamon-avisos-list');
	var template = document.getElementById('cinnamon-avisos-template');
	if (!list || !template) return;

	// Same rules as cinnamon_avisos_markup() in inc/avisos.php.
	function render(text) {
		var html = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
		return html
			.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
			.replace(/==(.+?)==/g, '<mark>$1</mark>')
			.replace(/(^|[^\p{L}\p{N}])_(.+?)_(?![\p{L}\p{N}])/gu, '$1<em>$2</em>');
	}

	// Same as cinnamon_avisos_classes() in inc/avisos.php.
	function classes(v) {
		var c = ['promo-bar__item', 'promo--' + v.style, 'promo--' + v.font];
		if (v.size === 'grande') c.push('promo--grande');
		if (v.motion !== 'ninguno') c.push('promo--' + v.motion);
		return c.join(' ');
	}

	function countdown(ms) {
		var s = Math.max(0, Math.floor(ms / 1000)), d = Math.floor(s / 86400), pad = function (n) { return String(n).padStart(2, '0'); };
		s %= 86400;
		return 'Termina en ' + (d ? d + ' d ' : '') + pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60);
	}

	function value(row, field) {
		var el = row.querySelector('[data-field="' + field + '"]');
		return el.type === 'checkbox' ? el.checked : el.value;
	}

	// The preview uses the browser's clock; close enough for a preview.
	function preview(row) {
		var v = {};
		['text', 'style', 'font', 'size', 'motion', 'until', 'countdown'].forEach(function (f) { v[f] = value(row, f); });
		var box = row.querySelector('.cin-aviso__preview');
		var inner = '<span class="promo-bar__text">' + (v.text ? render(v.text) : 'Escribí el texto del aviso') + '</span>';
		if (v.countdown && v.until) inner += '<span class="promo-bar__countdown">' + countdown(new Date(v.until) - Date.now()) + '</span>';
		box.innerHTML = '<p class="' + classes(v) + '"><span class="promo-bar__track">' + inner + '</span></p>';
	}

	function previewAll() { list.querySelectorAll('.cin-aviso').forEach(preview); }

	document.getElementById('cinnamon-avisos-add').addEventListener('click', function () {
		list.appendChild(template.content.cloneNode(true));
		var rows = list.querySelectorAll('.cin-aviso');
		preview(rows[rows.length - 1]);
		rows[rows.length - 1].querySelector('[data-field="text"]').focus();
	});

	list.addEventListener('click', function (e) {
		var row = e.target.closest('.cin-aviso');
		if (!row) return;
		var mark = e.target.closest('.cin-aviso__mark');
		if (mark) wrap(row, mark.dataset.mark);
		else if (e.target.closest('.cin-aviso__up') && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
		else if (e.target.closest('.cin-aviso__down') && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
		else if (e.target.closest('.cin-aviso__remove')) row.remove();
	});

	// Wraps the selected words (or inserts an empty pair at the cursor).
	function wrap(row, mark) {
		var input = row.querySelector('[data-field="text"]');
		var start = input.selectionStart, end = input.selectionEnd, text = input.value;
		input.value = text.slice(0, start) + mark + text.slice(start, end) + mark + text.slice(end);
		input.focus();
		input.setSelectionRange(start + mark.length, end + mark.length);
		preview(row);
	}

	list.addEventListener('input', function (e) { var row = e.target.closest('.cin-aviso'); if (row) preview(row); });
	list.addEventListener('change', function (e) { var row = e.target.closest('.cin-aviso'); if (row) preview(row); });
	previewAll();
	setInterval(function () {
		list.querySelectorAll('.cin-aviso').forEach(function (row) { if (value(row, 'countdown')) preview(row); });
	}, 1000);

	// Names get their index on submit, so the order on screen is the order saved.
	document.getElementById('cinnamon-avisos-form').addEventListener('submit', function () {
		list.querySelectorAll('.cin-aviso').forEach(function (row, i) {
			row.querySelectorAll('[data-field]').forEach(function (field) {
				field.name = 'avisos[' + i + '][' + field.dataset.field + ']';
			});
		});
	});
})();
