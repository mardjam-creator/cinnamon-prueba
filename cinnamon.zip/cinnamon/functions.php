<?php
/**
 * Cinnamon theme functions.
 *
 * @package cinnamon
 */

defined( 'ABSPATH' ) || exit;

define( 'CINNAMON_VERSION', '1.11.0' );

require_once get_theme_file_path( 'inc/info.php' );
require_once get_theme_file_path( 'inc/woocommerce.php' );
require_once get_theme_file_path( 'inc/novedades.php' );
require_once get_theme_file_path( 'inc/avisos.php' );

/**
 * Theme supports.
 */
function cinnamon_setup() {
	load_theme_textdomain( 'cinnamon', get_theme_file_path( 'languages' ) );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
}
add_action( 'after_setup_theme', 'cinnamon_setup' );

/**
 * Front-end styles and the small scroll-reveal script.
 */
function cinnamon_enqueue() {
	wp_enqueue_style( 'cinnamon', get_theme_file_uri( 'assets/css/theme.css' ), array(), CINNAMON_VERSION );
	wp_enqueue_style( 'cinnamon-promo-bar', get_theme_file_uri( 'assets/css/promo-bar.css' ), array(), CINNAMON_VERSION );
	wp_enqueue_script( 'cinnamon', get_theme_file_uri( 'assets/js/theme.js' ), array(), CINNAMON_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
}
add_action( 'wp_enqueue_scripts', 'cinnamon_enqueue' );

/**
 * Marks JS as available before paint, so reveal animations only hide
 * content when the script that shows it again will run.
 */
function cinnamon_js_class() {
	echo "<script>document.documentElement.classList.add('js')</script>\n";
}
add_action( 'wp_head', 'cinnamon_js_class', 1 );

/**
 * Pattern category.
 */
function cinnamon_pattern_category() {
	register_block_pattern_category( 'cinnamon', array( 'label' => __( 'Cinnamon', 'cinnamon' ) ) );
}
add_action( 'init', 'cinnamon_pattern_category' );

/**
 * Shortcode blocks inside patterns used by templates are expanded after the
 * template's own do_shortcode pass, so [products] would print as text.
 * Running shortcodes here covers that case; in post content nothing is left
 * for the later pass to do.
 *
 * @param string $content Block HTML.
 * @return string
 */
function cinnamon_render_shortcode_block( $content ) {
	return do_shortcode( shortcode_unautop( $content ) );
}
add_filter( 'render_block_core/shortcode', 'cinnamon_render_shortcode_block' );

/**
 * Floating WhatsApp button on every page.
 */
function cinnamon_whatsapp_float() {
	printf(
		'<a class="wa-float" href="%1$s" target="_blank" rel="noopener" aria-label="%2$s">%3$s</a>',
		esc_url( cinnamon_whatsapp_url( 'Hola Cinnamon, tengo una consulta' ) ),
		esc_attr__( 'Escribinos por WhatsApp', 'cinnamon' ),
		cinnamon_icon( 'whatsapp' ) // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG.
	);
}
add_action( 'wp_footer', 'cinnamon_whatsapp_float' );

/**
 * Store structured data on the home page. WooCommerce already prints
 * Product and BreadcrumbList data on shop pages.
 */
function cinnamon_store_jsonld() {
	if ( ! is_front_page() ) {
		return;
	}
	$info = cinnamon_info();
	$data = array(
		'@context'           => 'https://schema.org',
		'@type'              => 'Store',
		'@id'                => home_url( '/#store' ),
		'name'               => $info['legal_name'],
		'url'                => home_url( '/' ),
		'image'              => get_theme_file_uri( 'assets/images/logo.jpg' ),
		'telephone'          => '+598 2400 0542',
		'email'              => $info['email'],
		'address'            => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $info['address'],
			'addressLocality' => $info['city'],
			'addressCountry'  => 'UY',
		),
		'openingHours'       => 'Mo-Fr 10:00-19:00',
		'currenciesAccepted' => 'UYU',
		'sameAs'             => array( $info['instagram_url'] ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n";
}
add_action( 'wp_head', 'cinnamon_store_jsonld' );
