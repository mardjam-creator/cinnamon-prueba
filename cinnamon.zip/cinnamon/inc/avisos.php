<?php
/**
 * Promo bar above the free-shipping bar: notices that Cinnamon loads in
 * Apariencia > Franja de avisos (option cinnamon_avisos), each with a text,
 * an optional link, a Montevideo start and end time and its design (style,
 * font, size, motion, countdown). Only the first current notice shows;
 * theme.js re-checks the times in the browser so a cached page still shows
 * and hides it on time.
 *
 * @package cinnamon
 */

defined( 'ABSPATH' ) || exit;

/**
 * Design choices for a notice; the first of each is the default.
 *
 * @return array<string,array<string,string>>
 */
function cinnamon_avisos_options() {
	return array(
		'style'  => array(
			'canela'      => 'Canela',
			'cacao'       => 'Cacao',
			'arena'       => 'Arena',
			'black'       => 'Black Friday (negro y dorado)',
			'liquidacion' => 'Liquidación (rojo y amarillo)',
			'verde'       => 'Verde',
		),
		'font'   => array(
			'figtree'  => 'Figtree (la del sitio)',
			'fraunces' => 'Fraunces (la de los títulos)',
			'bebas'    => 'Bebas Neue (impacto)',
			'caveat'   => 'Caveat (manuscrita)',
		),
		'size'   => array(
			'normal' => 'Normal',
			'grande' => 'Grande',
		),
		'motion' => array(
			'ninguno'    => 'Sin movimiento',
			'marquesina' => 'Marquesina (pasa de lado a lado)',
			'brillo'     => 'Brillo',
		),
	);
}

/**
 * Saved notices, as typed in the admin screen.
 *
 * @return array<int,array{text:string,url:string,from:string,until:string,style?:string,font?:string,size?:string,motion?:string,countdown?:bool}>
 */
function cinnamon_avisos_saved() {
	$saved = get_option( 'cinnamon_avisos', array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * A design value of a notice, or the default when it is missing or unknown
 * (notices saved before story 6.7 have none).
 *
 * @param array  $item Notice.
 * @param string $key  style, font, size or motion.
 * @return string
 */
function cinnamon_avisos_choice( $item, $key ) {
	$choices = cinnamon_avisos_options()[ $key ];
	$value   = (string) ( $item[ $key ] ?? '' );
	return isset( $choices[ $value ] ) ? $value : (string) array_key_first( $choices );
}

/**
 * Timestamp of a "Y-m-dTH:i" time typed in Montevideo time, or null if empty or invalid.
 *
 * @param string $value Time from a datetime-local field.
 * @return int|null
 */
function cinnamon_avisos_time( $value ) {
	if ( '' === (string) $value ) {
		return null;
	}
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', (string) $value, wp_timezone() );
	return $date ? $date->getTimestamp() : null;
}

/**
 * Notice text as HTML: escaped, then **bold**, _italic_ and ==highlight==.
 * Same rules as render() in assets/js/avisos-admin.js.
 *
 * @param string $text Text as typed.
 * @return string
 */
function cinnamon_avisos_markup( $text ) {
	$html = esc_html( $text );
	$html = preg_replace( '/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $html );
	$html = preg_replace( '/==(.+?)==/u', '<mark>$1</mark>', $html );
	return preg_replace( '/(?<![\p{L}\p{N}])_(.+?)_(?![\p{L}\p{N}])/u', '<em>$1</em>', $html );
}

/**
 * Countdown text, "2 d 05:12:33" or "05:12:33". Same as countdown() in theme.js.
 *
 * @param int $seconds Seconds left.
 * @return string
 */
function cinnamon_avisos_countdown( $seconds ) {
	$seconds = max( 0, $seconds );
	$days    = intdiv( $seconds, 86400 );
	$clock   = gmdate( 'H:i:s', $seconds % 86400 );
	return 'Termina en ' . ( $days ? $days . ' d ' : '' ) . $clock;
}

/**
 * Notices that haven't ended yet, in screen order, with their times as
 * timestamps (0 = no start, PHP_INT_MAX = no end) and whether they are current.
 *
 * @return array<int,array>
 */
function cinnamon_avisos_upcoming() {
	$now     = time();
	$out     = array();
	$current = false;
	foreach ( cinnamon_avisos_saved() as $item ) {
		$from  = cinnamon_avisos_time( $item['from'] ?? '' ) ?? 0;
		$until = cinnamon_avisos_time( $item['until'] ?? '' ) ?? PHP_INT_MAX;
		if ( $until <= $now || '' === (string) ( $item['text'] ?? '' ) ) {
			continue;
		}
		$is_current = ! $current && $from <= $now;
		$current    = $current || $is_current;
		$out[]      = array(
			'text'      => (string) $item['text'],
			'url'       => (string) ( $item['url'] ?? '' ),
			'from'      => $from,
			'until'     => $until,
			'current'   => $is_current,
			'style'     => cinnamon_avisos_choice( $item, 'style' ),
			'font'      => cinnamon_avisos_choice( $item, 'font' ),
			'size'      => cinnamon_avisos_choice( $item, 'size' ),
			'motion'    => cinnamon_avisos_choice( $item, 'motion' ),
			'countdown' => ! empty( $item['countdown'] ) && PHP_INT_MAX !== $until,
		);
	}
	return $out;
}

/**
 * Classes for a notice's design. Same as classes() in assets/js/avisos-admin.js.
 *
 * @param array $item Notice with its design choices.
 * @return string
 */
function cinnamon_avisos_classes( $item ) {
	$classes = array( 'promo-bar__item', 'promo--' . $item['style'], 'promo--' . $item['font'] );
	if ( 'grande' === $item['size'] ) {
		$classes[] = 'promo--grande';
	}
	if ( 'ninguno' !== $item['motion'] ) {
		$classes[] = 'promo--' . $item['motion'];
	}
	return implode( ' ', $classes );
}

/**
 * Bar markup for the header: every notice that hasn't ended, only the
 * current one visible.
 *
 * @return string
 */
function cinnamon_avisos_bar() {
	$items = cinnamon_avisos_upcoming();
	if ( ! $items ) {
		return '';
	}
	$html = '';
	foreach ( $items as $item ) {
		$tag   = $item['url'] ? 'a' : 'p';
		$attrs = sprintf(
			' class="%s" data-from="%s" data-until="%s"%s%s',
			esc_attr( cinnamon_avisos_classes( $item ) ),
			esc_attr( (string) ( $item['from'] * 1000 ) ),
			esc_attr( PHP_INT_MAX === $item['until'] ? '' : (string) ( $item['until'] * 1000 ) ),
			$item['url'] ? ' href="' . esc_url( $item['url'] ) . '"' : '',
			$item['current'] ? '' : ' hidden'
		);
		$inner = '<span class="promo-bar__text">' . cinnamon_avisos_markup( $item['text'] ) . '</span>';
		if ( $item['countdown'] ) {
			$inner .= '<span class="promo-bar__countdown">' . esc_html( cinnamon_avisos_countdown( $item['until'] - time() ) ) . '</span>';
		}
		$html .= '<' . $tag . $attrs . '><span class="promo-bar__track">' . $inner . '</span></' . $tag . '>';
	}
	return '<div class="promo-bar" role="region" aria-label="Avisos">' . $html . '</div>';
}

/**
 * Admin screen: Apariencia > Franja de avisos.
 */
add_action(
	'admin_menu',
	function () {
		add_theme_page( 'Franja de avisos', 'Franja de avisos', 'manage_woocommerce', 'cinnamon-avisos', 'cinnamon_avisos_screen' );
	}
);

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'appearance_page_cinnamon-avisos' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'cinnamon-promo-bar', get_theme_file_uri( 'assets/css/promo-bar.css' ), array(), CINNAMON_VERSION );
		// On the store theme.json loads these two; the preview needs them too.
		$fonts = get_theme_file_uri( 'assets/fonts/' );
		wp_add_inline_style(
			'cinnamon-promo-bar',
			'@font-face{font-family:"Figtree";src:url(' . esc_url( $fonts . 'figtree-vf.woff2' ) . ') format("woff2");font-weight:300 900;font-display:swap}'
			. '@font-face{font-family:"Fraunces";src:url(' . esc_url( $fonts . 'fraunces-vf.woff2' ) . ') format("woff2");font-weight:100 900;font-display:swap}'
		);
		wp_enqueue_script( 'cinnamon-avisos', get_theme_file_uri( 'assets/js/avisos-admin.js' ), array(), CINNAMON_VERSION, true );
	}
);

/**
 * Reads the posted rows, in the order they were on screen.
 *
 * @param array $posted $_POST['avisos'].
 * @return array{0:array,1:string[]} Notices and errors.
 */
function cinnamon_avisos_read( $posted ) {
	$items  = array();
	$errors = array();
	foreach ( array_values( (array) $posted ) as $i => $row ) {
		$item = array(
			'text'  => sanitize_text_field( $row['text'] ?? '' ),
			'url'   => esc_url_raw( trim( (string) ( $row['url'] ?? '' ) ) ),
			'from'  => sanitize_text_field( $row['from'] ?? '' ),
			'until' => sanitize_text_field( $row['until'] ?? '' ),
		);
		if ( '' === $item['text'] && '' === $item['url'] && '' === $item['from'] && '' === $item['until'] ) {
			continue; // Empty row.
		}
		foreach ( array_keys( cinnamon_avisos_options() ) as $key ) {
			$item[ $key ] = cinnamon_avisos_choice( $row, $key );
		}
		$item['countdown'] = ! empty( $row['countdown'] );
		$n                 = $i + 1;
		if ( '' === $item['text'] ) {
			$errors[] = sprintf( 'Aviso %d: escribí el texto. No se guardó ningún cambio.', $n );
		}
		$from  = cinnamon_avisos_time( $item['from'] );
		$until = cinnamon_avisos_time( $item['until'] );
		if ( ( '' !== $item['from'] && null === $from ) || ( '' !== $item['until'] && null === $until ) ) {
			$errors[] = sprintf( 'Aviso %d: revisá las fechas. No se guardó ningún cambio.', $n );
		} elseif ( null !== $from && null !== $until && $until <= $from ) {
			$errors[] = sprintf( 'Aviso %d: "Hasta" tiene que ser después de "Desde". No se guardó ningún cambio.', $n );
		}
		if ( $item['countdown'] && '' === $item['until'] ) {
			$errors[] = sprintf( 'Aviso %d: la cuenta regresiva necesita una fecha "Hasta". No se guardó ningún cambio.', $n );
		}
		$items[] = $item;
	}
	return array( $items, $errors );
}

/**
 * Renders the screen and saves the notices.
 */
function cinnamon_avisos_screen() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$notice = '';
	$errors = array();
	$items  = cinnamon_avisos_saved();
	if ( isset( $_POST['cinnamon_avisos'] ) ) {
		check_admin_referer( 'cinnamon_avisos' );
		list( $posted, $errors ) = cinnamon_avisos_read( wp_unslash( $_POST['avisos'] ?? array() ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field.
		$items                   = $posted; // With errors nothing is saved and what was typed stays on screen.
		if ( ! $errors ) {
			update_option( 'cinnamon_avisos', $posted, false );
			$notice = 'Avisos guardados.';
		}
	}
	?>
	<div class="wrap">
		<h1>Franja de avisos</h1>
		<p>La franja va arriba de todo, sobre la de envío gratis, en todas las páginas menos Finalizar compra. Cada aviso se muestra desde la fecha y hora de "Desde" hasta la de "Hasta" (hora de Montevideo); sin "Desde" empieza ya y sin "Hasta" no termina. Se ve un aviso por vez: si dos se superponen, el primero de la lista. Sin avisos vigentes no hay franja. Con enlace, toda la franja lleva ahí.</p>
		<p>Para destacar palabras, seleccionalas y tocá <strong>Negrita</strong>, <em>Cursiva</em> o <strong>Resaltado</strong> (o escribí <code>**negrita**</code>, <code>_cursiva_</code>, <code>==resaltado==</code>). Debajo de cada aviso está la vista previa.</p>
		<?php if ( $notice ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
		<?php endif; ?>
		<?php foreach ( $errors as $error ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
		<?php endforeach; ?>
		<form method="post" id="cinnamon-avisos-form">
			<?php wp_nonce_field( 'cinnamon_avisos' ); ?>
			<div id="cinnamon-avisos-list">
				<?php
				foreach ( $items as $item ) {
					cinnamon_avisos_row( $item );
				}
				?>
			</div>
			<template id="cinnamon-avisos-template"><?php cinnamon_avisos_row( array() ); ?></template>
			<p><button type="button" class="button" id="cinnamon-avisos-add">+ Agregar aviso</button></p>
			<?php submit_button( 'Guardar avisos', 'primary', 'cinnamon_avisos' ); ?>
		</form>
	</div>
	<?php
}

/**
 * One notice row of the admin form. Field names get their index when the
 * form is sent (assets/js/avisos-admin.js), so the screen order is kept.
 *
 * @param array $item Notice.
 */
function cinnamon_avisos_row( $item ) {
	$until  = cinnamon_avisos_time( $item['until'] ?? '' );
	$ended  = null !== $until && $until <= time();
	$labels = array( 'style' => 'Estilo', 'font' => 'Letra', 'size' => 'Tamaño', 'motion' => 'Movimiento' );
	?>
	<div class="cin-aviso" style="display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:start;background:#fff;border:1px solid #c3c4c7;padding:1rem;margin:0 0 1rem;max-width:960px">
		<div style="display:grid;gap:.6rem;min-width:0">
			<div>
				<span>Texto</span>
				<div style="display:flex;gap:.25rem;margin:.25rem 0">
					<button type="button" class="button button-small cin-aviso__mark" data-mark="**" title="Negrita"><strong>Negrita</strong></button>
					<button type="button" class="button button-small cin-aviso__mark" data-mark="_" title="Cursiva"><em>Cursiva</em></button>
					<button type="button" class="button button-small cin-aviso__mark" data-mark="==" title="Resaltado">Resaltado</button>
				</div>
				<input type="text" class="widefat" data-field="text" aria-label="Texto" value="<?php echo esc_attr( $item['text'] ?? '' ); ?>" placeholder="==Cyber Monday== lunes 2 de noviembre: hasta **30% extra** en productos">
			</div>
			<label>Enlace (opcional) <input type="url" class="widefat" data-field="url" value="<?php echo esc_attr( $item['url'] ?? '' ); ?>" placeholder="https://…"></label>
			<div style="display:flex;gap:1rem;flex-wrap:wrap">
				<label>Desde <input type="datetime-local" data-field="from" value="<?php echo esc_attr( $item['from'] ?? '' ); ?>"></label>
				<label>Hasta <input type="datetime-local" data-field="until" value="<?php echo esc_attr( $item['until'] ?? '' ); ?>"></label>
				<?php if ( $ended ) : ?>
					<span style="align-self:center;color:#646970">Terminado: ya no se muestra.</span>
				<?php endif; ?>
			</div>
			<div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:end">
				<?php foreach ( cinnamon_avisos_options() as $key => $choices ) : ?>
					<label style="display:grid;gap:.15rem"><?php echo esc_html( $labels[ $key ] ); ?>
						<select data-field="<?php echo esc_attr( $key ); ?>">
							<?php foreach ( $choices as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( cinnamon_avisos_choice( $item, $key ), $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
				<?php endforeach; ?>
				<label style="padding-bottom:.35rem"><input type="checkbox" data-field="countdown" value="1" <?php checked( ! empty( $item['countdown'] ) ); ?>> Cuenta regresiva (necesita "Hasta")</label>
			</div>
			<div>
				<span style="color:#646970">Vista previa</span>
				<div class="promo-bar cin-aviso__preview" style="margin-top:.25rem;border-radius:4px;overflow:hidden"></div>
			</div>
		</div>
		<div style="display:grid;gap:.35rem">
			<button type="button" class="button cin-aviso__up" aria-label="Subir">↑</button>
			<button type="button" class="button cin-aviso__down" aria-label="Bajar">↓</button>
			<button type="button" class="button-link-delete cin-aviso__remove">Borrar</button>
		</div>
	</div>
	<?php
}
