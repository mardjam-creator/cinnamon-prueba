<?php
/**
 * WooCommerce presentation tweaks. Store rules (shipping, payments) live in
 * the Cinnamon setup plugin, not here.
 *
 * @package cinnamon
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

// Three products per row in the shop and in related products.
add_filter( 'loop_shop_columns', fn() => 3 );
add_filter( 'loop_shop_per_page', fn() => 24 );
add_filter(
	'woocommerce_output_related_products_args',
	function ( $args ) {
		$args['posts_per_page'] = 3;
		$args['columns']        = 3;
		return $args;
	}
);

// Prices: "$2.500" and "$281,25", without trailing ",00".
add_filter( 'woocommerce_price_trim_zeros', '__return_true' );

/**
 * Variable products show "Desde $115" instead of a "$115 – $920" range.
 *
 * @param string     $price   Price HTML.
 * @param WC_Product $product Product.
 * @return string
 */
function cinnamon_variable_price_html( $price, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	if ( $min === $max ) {
		return $price;
	}
	/* translators: %s: lowest price. */
	return '<span class="price-from">' . sprintf( esc_html__( 'Desde %s', 'cinnamon' ), wc_price( $min ) ) . '</span>';
}
add_filter( 'woocommerce_variable_price_html', 'cinnamon_variable_price_html', 10, 2 );

/**
 * Plainer button labels in the product grid.
 *
 * @param string     $text    Label.
 * @param WC_Product $product Product.
 * @return string
 */
function cinnamon_loop_button_text( $text, $product ) {
	if ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) {
		return __( 'Agregar al carrito', 'cinnamon' );
	}
	return $text;
}
add_filter( 'woocommerce_product_add_to_cart_text', 'cinnamon_loop_button_text', 10, 2 );

/**
 * Visible variations of a variable product, as the card's weight buttons list them.
 *
 * @param WC_Product $product Variable product.
 * @return array<int,array{id:int,label:string,price:string,in_stock:bool}>
 */
function cinnamon_loop_variations( $product ) {
	$options = array();
	foreach ( $product->get_children() as $child_id ) {
		$variation = wc_get_product( $child_id );
		if ( ! $variation || ! $variation->exists() || ! $variation->variation_is_visible() ) {
			continue;
		}
		$options[] = array(
			'id'       => $variation->get_id(),
			'label'    => wc_get_formatted_variation( $variation, true, false, false ),
			'price'    => $variation->get_price_html(),
			'in_stock' => $variation->is_in_stock() && $variation->is_purchasable(),
		);
	}
	return $options;
}

/**
 * The weight a card starts on: the product's default, or the first one in stock.
 *
 * @param WC_Product $product Variable product.
 * @param array      $options cinnamon_loop_variations().
 * @return int Index in $options.
 */
function cinnamon_loop_selected_index( $product, $options ) {
	$default = $product->get_default_attributes();
	foreach ( $options as $i => $option ) {
		$attrs = wc_get_product( $option['id'] )->get_variation_attributes( false );
		if ( $default && array_intersect_assoc( $default, $attrs ) === $default && $option['in_stock'] ) {
			return $i;
		}
	}
	$in_stock = wp_list_filter( $options, array( 'in_stock' => true ) );
	return $in_stock ? array_key_first( $in_stock ) : 0;
}

/**
 * Product cards for variable products: weight buttons, the chosen weight's
 * price and an add-to-cart button for that exact variation, so customers can
 * buy from the grid. Works with WooCommerce's AJAX add to cart: the theme
 * script swaps the variation ID on the button when a weight is picked.
 *
 * @param string     $html    Default button HTML.
 * @param WC_Product $product Product.
 * @return string
 */
function cinnamon_loop_variation_picker( $html, $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return $html;
	}

	$options = cinnamon_loop_variations( $product );
	if ( ! $options ) {
		return $html;
	}

	$selected = cinnamon_loop_selected_index( $product, $options );
	$current  = $options[ $selected ];
	$name    = $product->get_name();

	ob_start();
	?>
	<div class="lv">
		<span class="price lv-price" aria-live="polite"><?php echo wp_kses_post( $current['price'] ); ?></span>
		<div class="lv-options" role="radiogroup" aria-label="<?php echo esc_attr( sprintf( 'Peso de %s', $name ) ); ?>">
			<?php foreach ( $options as $i => $option ) : ?>
				<button type="button" class="lv-option" role="radio"
					aria-checked="<?php echo $i === $selected ? 'true' : 'false'; ?>"
					tabindex="<?php echo $i === $selected ? '0' : '-1'; ?>"
					data-variation-id="<?php echo esc_attr( $option['id'] ); ?>"
					data-price="<?php echo esc_attr( $option['price'] ); ?>"
					<?php disabled( ! $option['in_stock'] ); ?>><?php echo esc_html( $option['label'] ); ?></button>
			<?php endforeach; ?>
		</div>
		<a href="<?php echo esc_url( add_query_arg( 'add-to-cart', $current['id'], wc_get_cart_url() ) ); ?>"
			data-quantity="1"
			data-product_id="<?php echo esc_attr( $current['id'] ); ?>"
			data-product_sku=""
			class="button add_to_cart_button ajax_add_to_cart lv-add"
			aria-label="<?php echo esc_attr( sprintf( 'Agregar %s, %s, al carrito', $name, wp_strip_all_tags( $current['label'] ) ) ); ?>"
			rel="nofollow"><?php esc_html_e( 'Agregar al carrito', 'cinnamon' ); ?></a>
	</div>
	<?php
	return ob_get_clean();
}
add_filter( 'woocommerce_loop_add_to_cart_link', 'cinnamon_loop_variation_picker', 10, 2 );

// "Peso" options read better as buttons than as a select. Woo still needs the
// select, so the theme script builds the buttons and keeps the select in sync.
add_filter(
	'woocommerce_dropdown_variation_attribute_options_html',
	function ( $html ) {
		return '<div class="variation-select">' . $html . '</div>';
	}
);

/**
 * Whether a product belongs to "Sin Gluten" or any of its subcategories.
 *
 * @param WC_Product $product Product.
 * @return bool
 */
function cinnamon_is_gluten_free( $product ) {
	static $ids = null;
	if ( null === $ids ) {
		$root = get_term_by( 'slug', 'sin-gluten', 'product_cat' );
		$ids  = $root ? array_merge( array( (int) $root->term_id ), array_map( 'intval', get_term_children( $root->term_id, 'product_cat' ) ) ) : array();
	}
	return $ids && array_intersect( $ids, $product->get_category_ids() );
}

/**
 * Discount label of a product or variation: "-20%" when the sale price is a
 * whole percentage off the regular price, allowing half a peso for prices
 * rounded to whole pesos ($575 at 10 % off is $517,50, sold at $518);
 * "¡Oferta!" when the discount is an amount; '' when it isn't on sale.
 *
 * @param WC_Product $product Product or variation.
 * @return string
 */
function cinnamon_discount_label( $product ) {
	if ( ! $product->is_on_sale() ) {
		return '';
	}
	$regular = (float) $product->get_regular_price();
	$sale    = (float) $product->get_sale_price();
	if ( $regular > 0 && $sale < $regular ) {
		$percent = (int) round( ( $regular - $sale ) / $regular * 100 );
		if ( $percent >= 1 && abs( $sale - $regular * ( 100 - $percent ) / 100 ) <= 0.5 ) {
			return sprintf( '-%d%%', $percent );
		}
	}
	return __( '¡Oferta!', 'cinnamon' );
}

/**
 * The percentage goes next to the price ("$960 -20%"), for simple products
 * and for each weight (cards and the product page show the weight's price
 * HTML). Discounts by amount show no percentage; the image keeps "¡Oferta!".
 *
 * @param string     $html    Price HTML.
 * @param WC_Product $product Product or variation.
 * @return string
 */
function cinnamon_price_discount( $html, $product ) {
	if ( is_admin() || $product->is_type( 'variable' ) ) {
		return $html;
	}
	if ( ! preg_match( '/^-(\d+)%$/', cinnamon_discount_label( $product ), $m ) ) {
		return $html;
	}
	return $html . ' <span class="price-discount"><span aria-hidden="true">-' . $m[1] . '%</span><span class="screen-reader-text">' . esc_html( $m[1] . ' % de descuento' ) . '</span></span>';
}
add_filter( 'woocommerce_get_price_html', 'cinnamon_price_discount', 20, 2 );

/**
 * Product badges on the image: "Libre de gluten" for gluten-free products,
 * and "¡Oferta!" when the product, or the chosen weight, has a discount (the
 * percentage is next to the price). Weight products carry each weight's
 * badge so the theme script can switch it: cards start on the card's weight,
 * the product page shows "¡Oferta!" if any weight is on sale until one is chosen.
 */
function cinnamon_product_badge() {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$badges = '';
	if ( cinnamon_is_gluten_free( $product ) ) {
		$badges .= '<span class="onsale badge-gluten-free">' . esc_html__( 'Libre de gluten', 'cinnamon' ) . '</span>';
	}

	$sale  = __( '¡Oferta!', 'cinnamon' );
	$attrs = '';
	if ( $product->is_type( 'variable' ) ) {
		$options = cinnamon_loop_variations( $product );
		$labels  = array();
		foreach ( $options as $option ) {
			$labels[ $option['id'] ] = wc_get_product( $option['id'] )->is_on_sale() ? $sale : '';
		}
		$any   = array_filter( $labels ) ? $sale : '';
		$label = ! is_product() && $options ? $labels[ $options[ cinnamon_loop_selected_index( $product, $options ) ]['id'] ] : $any;
		$attrs = sprintf( ' data-labels="%s" data-initial="%s"', esc_attr( wp_json_encode( $labels ) ), esc_attr( $any ) );
	} else {
		$label = $product->is_on_sale() ? $sale : '';
	}
	if ( $label || $attrs ) {
		$discount = '<span class="onsale badge-discount"' . $attrs . ( $label ? '' : ' hidden' ) . '>' . esc_html( $label ) . '</span>';
		$badges  .= apply_filters( 'woocommerce_sale_flash', $discount, null, $product );
	}
	if ( $badges ) {
		echo '<div class="product-badges">' . $badges . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above.
	}
}

// Swap WooCommerce's sale badge for ours, in the grid and on the product page.
add_action(
	'wp',
	function () {
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
		add_action( 'woocommerce_before_shop_loop_item_title', 'cinnamon_product_badge', 10 );
		add_action( 'woocommerce_before_single_product_summary', 'cinnamon_product_badge', 10 );
	}
);

/**
 * After "No se encontraron productos…" (empty search or category): links to
 * the shop and the main categories, so the page is not a dead end.
 */
function cinnamon_no_results_links() {
	echo '<div class="cinnamon-no-results"><p>' . esc_html__( 'Probá con otra palabra o explorá las categorías.', 'cinnamon' ) . '</p><ul>';
	printf( '<li><a href="%s">%s</a></li>', esc_url( wc_get_page_permalink( 'shop' ) ), esc_html__( 'Ver toda la tienda', 'cinnamon' ) );
	foreach ( cinnamon_category_tree() as $cat ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $cat['url'] ), esc_html( $cat['name'] ) );
	}
	echo '</ul></div>';
}
add_action( 'woocommerce_no_products_found', 'cinnamon_no_results_links', 20 );

/**
 * Perks under the add-to-cart button on product pages.
 */
function cinnamon_product_perks() {
	$info = cinnamon_info();
	echo '<ul class="pdp-perks">';
	printf( '<li>%s %s</li>', cinnamon_icon( 'truck' ), esc_html( sprintf( 'Envío gratis en Montevideo desde %s', $info['free_from'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	printf( '<li>%s %s</li>', cinnamon_icon( 'store' ), esc_html( sprintf( 'Retiro sin costo en %s', $info['address'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	printf( '<li>%s <a href="%s" target="_blank" rel="noopener">%s</a></li>', cinnamon_icon( 'chat' ), esc_url( cinnamon_whatsapp_url( 'Hola Cinnamon, tengo una consulta sobre ' . get_the_title() ) ), esc_html( '¿Dudas? Escribinos por WhatsApp' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</ul>';
}
add_action( 'woocommerce_single_product_summary', 'cinnamon_product_perks', 35 );

// Breadcrumb in the shop's style.
add_filter(
	'woocommerce_breadcrumb_defaults',
	function ( $defaults ) {
		$defaults['delimiter']   = '<span class="sep" aria-hidden="true">/</span>';
		$defaults['wrap_before'] = '<nav class="woocommerce-breadcrumb" aria-label="' . esc_attr__( 'Ruta de navegación', 'cinnamon' ) . '">';
		$defaults['home']        = __( 'Inicio', 'cinnamon' );
		return $defaults;
	}
);

// WooCommerce adds its "Mi cuenta" block next to the menu on its own; the
// header already has an account icon between search and the cart.
add_filter(
	'hooked_block_types',
	function ( $hooked_blocks ) {
		return array_values( array_diff( $hooked_blocks, array( 'woocommerce/customer-account' ) ) );
	},
	20
);
