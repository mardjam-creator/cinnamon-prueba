<?php
/**
 * Front-page carousel content: news and new products that Cinnamon loads in
 * Apariencia > Novedades de la portada (option cinnamon_novedades). Each one
 * has a photo from the media library, a title, a short text, a link and an
 * optional product that gives the link and the price. Without any active
 * news, the front page shows one fixed photo.
 *
 * @package cinnamon
 */

defined( 'ABSPATH' ) || exit;

/**
 * Saved news, as typed in the admin screen.
 *
 * @return array<int,array{image:int,title:string,text:string,url:string,product:int,active:bool}>
 */
function cinnamon_novedades_saved() {
	$saved = get_option( 'cinnamon_novedades', array() );
	return is_array( $saved ) ? $saved : array();
}

/**
 * Slides ready for the carousel: active news whose photo (and product, when
 * one was chosen) still exist. Falls back to the fixed frutos secos photo.
 *
 * @return array<int,array{image:string,title:string,text:string,note:string,price:string,url:string}>
 */
function cinnamon_hero_slides() {
	$slides = array();
	foreach ( cinnamon_novedades_saved() as $item ) {
		if ( empty( $item['active'] ) ) {
			continue;
		}
		$image = wp_get_attachment_image_url( (int) $item['image'], 'large' );
		if ( ! $image ) {
			continue;
		}
		$product = null;
		if ( ! empty( $item['product'] ) && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( (int) $item['product'] );
			if ( ! $product || 'publish' !== $product->get_status() ) {
				continue; // The product was removed: hide this news rather than link nowhere.
			}
		}
		$slides[] = array(
			'image' => $image,
			'title' => (string) $item['title'],
			'text'  => (string) $item['text'],
			'note'  => '',
			'price' => $product ? $product->get_price_html() : '',
			'url'   => $item['url'] ? (string) $item['url'] : ( $product ? $product->get_permalink() : '' ),
		);
	}
	if ( $slides ) {
		return $slides;
	}
	return array(
		array(
			'image' => get_theme_file_uri( 'assets/images/portada-frutos-secos.jpg' ),
			'title' => 'Frutos Secos',
			'text'  => 'Descuentos desde 500 g',
			'note'  => 'y mejor precio por kilo',
			'price' => '',
			'url'   => cinnamon_category_url( 'frutos-secos' ),
		),
	);
}

/**
 * Admin screen: Apariencia > Novedades de la portada.
 */
add_action(
	'admin_menu',
	function () {
		add_theme_page( 'Novedades de la portada', 'Novedades de la portada', 'manage_woocommerce', 'cinnamon-novedades', 'cinnamon_novedades_screen' );
	}
);

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'appearance_page_cinnamon-novedades' !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'cinnamon-novedades', get_theme_file_uri( 'assets/js/novedades-admin.js' ), array( 'jquery' ), CINNAMON_VERSION, true );
	}
);

/**
 * Reads the posted rows, in the order they were on screen.
 *
 * @param array $posted $_POST['novedades'].
 * @return array{0:array,1:string[]} News and errors.
 */
function cinnamon_novedades_read( $posted ) {
	$items  = array();
	$errors = array();
	foreach ( array_values( (array) $posted ) as $i => $row ) {
		$item = array(
			'image'   => absint( $row['image'] ?? 0 ),
			'title'   => sanitize_text_field( $row['title'] ?? '' ),
			'text'    => sanitize_text_field( $row['text'] ?? '' ),
			'url'     => esc_url_raw( trim( (string) ( $row['url'] ?? '' ) ) ),
			'product' => absint( $row['product'] ?? 0 ),
			'active'  => ! empty( $row['active'] ),
		);
		if ( ! $item['image'] && '' === $item['title'] && '' === $item['text'] && '' === $item['url'] && ! $item['product'] ) {
			continue; // Empty row.
		}
		if ( $item['active'] && ! wp_get_attachment_image_url( $item['image'], 'thumbnail' ) ) {
			$errors[] = sprintf( 'Novedad %d: elegí una foto (o desactivala). No se guardó ningún cambio.', $i + 1 );
		}
		if ( $item['active'] && '' === $item['title'] ) {
			$errors[] = sprintf( 'Novedad %d: escribí un título (o desactivala). No se guardó ningún cambio.', $i + 1 );
		}
		$items[] = $item;
	}
	return array( $items, $errors );
}

/**
 * Renders the screen and saves the news.
 */
function cinnamon_novedades_screen() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$notice = '';
	$errors = array();
	$items  = cinnamon_novedades_saved();
	if ( isset( $_POST['cinnamon_novedades'] ) ) {
		check_admin_referer( 'cinnamon_novedades' );
		list( $posted, $errors ) = cinnamon_novedades_read( wp_unslash( $_POST['novedades'] ?? array() ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field.
		if ( $errors ) {
			$items = $posted; // Nothing saved; keep what was typed on screen.
		} else {
			update_option( 'cinnamon_novedades', $posted, false );
			$items  = $posted;
			$notice = $posted ? 'Novedades guardadas. La portada ya las muestra.' : 'No hay novedades: la portada muestra la imagen fija de frutos secos.';
		}
	}

	$products = function_exists( 'wc_get_products' ) ? wc_get_products( array( 'status' => 'publish', 'limit' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) : array();
	?>
	<div class="wrap">
		<h1>Novedades de la portada</h1>
		<p>Lo que cargues acá se muestra en el carrusel de la portada, en este orden, pasando cada 5 segundos. Usá fotos horizontales (4:3, de al menos 1200 × 900 px). Si elegís un producto y dejás el enlace vacío, la imagen lleva a ese producto y el cartel muestra su precio. Si no hay ninguna novedad activa, la portada muestra la foto de frutos secos.</p>
		<?php if ( $notice ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
		<?php endif; ?>
		<?php foreach ( $errors as $error ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
		<?php endforeach; ?>
		<form method="post" id="cinnamon-novedades-form">
			<?php wp_nonce_field( 'cinnamon_novedades' ); ?>
			<div id="cinnamon-novedades-list">
				<?php
				foreach ( $items as $item ) {
					cinnamon_novedades_row( $item, $products );
				}
				?>
			</div>
			<template id="cinnamon-novedades-template"><?php cinnamon_novedades_row( array( 'active' => true ), $products ); ?></template>
			<p><button type="button" class="button" id="cinnamon-novedades-add">+ Agregar novedad</button></p>
			<?php submit_button( 'Guardar novedades', 'primary', 'cinnamon_novedades' ); ?>
		</form>
	</div>
	<?php
}

/**
 * One news row of the admin form. Field names get their index when the form
 * is sent (assets/js/novedades-admin.js), so the screen order is kept.
 *
 * @param array        $item     News.
 * @param WC_Product[] $products Products to choose from.
 */
function cinnamon_novedades_row( $item, $products ) {
	$image = ! empty( $item['image'] ) ? wp_get_attachment_image_url( (int) $item['image'], 'medium' ) : '';
	?>
	<div class="cin-nov" style="display:grid;grid-template-columns:200px 1fr auto;gap:1rem;align-items:start;background:#fff;border:1px solid #c3c4c7;padding:1rem;margin:0 0 1rem;max-width:960px">
		<div>
			<div class="cin-nov__preview" style="aspect-ratio:4/3;background:#f0f0f1 center/cover no-repeat;border-radius:4px;<?php echo $image ? 'background-image:url(' . esc_url( $image ) . ')' : ''; ?>"></div>
			<input type="hidden" data-field="image" value="<?php echo esc_attr( (string) ( $item['image'] ?? '' ) ); ?>">
			<p><button type="button" class="button cin-nov__pick">Elegir foto</button></p>
		</div>
		<div style="display:grid;gap:.5rem">
			<label>Título <input type="text" class="widefat" data-field="title" value="<?php echo esc_attr( $item['title'] ?? '' ); ?>" placeholder="Nuevo: Mix de frutos rojos"></label>
			<label>Texto <input type="text" class="widefat" data-field="text" value="<?php echo esc_attr( $item['text'] ?? '' ); ?>" placeholder="Llegó en 250 g y 500 g"></label>
			<label>Producto (opcional)
				<select class="widefat" data-field="product">
					<option value="">Ninguno</option>
					<?php foreach ( $products as $product ) : ?>
						<option value="<?php echo esc_attr( (string) $product->get_id() ); ?>" <?php selected( (int) ( $item['product'] ?? 0 ), $product->get_id() ); ?>><?php echo esc_html( $product->get_name() ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>Enlace (opcional si elegiste un producto) <input type="url" class="widefat" data-field="url" value="<?php echo esc_attr( $item['url'] ?? '' ); ?>" placeholder="https://…"></label>
			<label><input type="checkbox" data-field="active" value="1" <?php checked( ! empty( $item['active'] ) ); ?>> Mostrar en la portada</label>
		</div>
		<div style="display:grid;gap:.35rem">
			<button type="button" class="button cin-nov__up" aria-label="Subir">↑</button>
			<button type="button" class="button cin-nov__down" aria-label="Bajar">↓</button>
			<button type="button" class="button-link-delete cin-nov__remove">Borrar</button>
		</div>
	</div>
	<?php
}
