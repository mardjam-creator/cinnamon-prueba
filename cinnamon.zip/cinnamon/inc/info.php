<?php
/**
 * Business details and small helpers used by patterns and templates.
 *
 * @package cinnamon
 */

defined( 'ABSPATH' ) || exit;

/**
 * Business details, in one place.
 *
 * @return array<string,string>
 */
function cinnamon_info() {
	return apply_filters(
		'cinnamon_info',
		array(
			'name'            => 'Cinnamon',
			'legal_name'      => 'Cinnamon Boutique Gourmet',
			'address'         => 'Dr. Pablo de María 1441',
			'city'            => 'Montevideo',
			'hours'           => 'Lunes a viernes de 10:00 a 19:00',
			'phone'           => '2400 0542',
			'phone_href'      => 'tel:+59824000542',
			'whatsapp'        => '096 181 666',
			'whatsapp_number' => '59896181666',
			'email'           => 'info@cinnamon.uy',
			'instagram'       => '@cinnamonbg.uy',
			'instagram_url'   => 'https://www.instagram.com/cinnamonbg.uy/',
			'maps_url'        => 'https://www.google.com/maps/search/?api=1&query=Dr.+Pablo+de+Mar%C3%ADa+1441%2C+Montevideo',
			'waze_url'        => 'https://waze.com/ul?q=Dr.%20Pablo%20de%20Mar%C3%ADa%201441%20Montevideo&navigate=yes',
			'free_from'       => '$2.500',
		)
	);
}

/**
 * Product category tree for the "Productos" menu, read from WooCommerce on
 * every load: top-level categories with their subcategories, in the shop's
 * order, without the default "Sin categorizar" category, and only categories
 * with published products (a parent stays when any child has products).
 *
 * @return array<int,array{name:string,url:string,children:array<int,array{name:string,url:string}>}>
 */
function cinnamon_category_tree() {
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return array();
	}
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	$order = static function ( $a, $b ) {
		return array( (int) get_term_meta( $a->term_id, 'order', true ), $a->name ) <=> array( (int) get_term_meta( $b->term_id, 'order', true ), $b->name );
	};
	usort( $terms, $order );

	$tree = array();
	foreach ( $terms as $term ) {
		if ( 0 !== (int) $term->parent ) {
			continue;
		}
		$children = array();
		foreach ( $terms as $child ) {
			if ( (int) $child->parent === (int) $term->term_id && $child->count > 0 ) {
				$children[] = array( 'name' => $child->name, 'url' => get_term_link( $child ) );
			}
		}
		if ( $term->count > 0 || $children ) {
			$tree[] = array( 'name' => $term->name, 'url' => get_term_link( $term ), 'children' => $children );
		}
	}
	return apply_filters( 'cinnamon_category_tree', $tree );
}

/**
 * WhatsApp link, optionally with a prefilled message.
 *
 * @param string $text Message.
 * @return string
 */
function cinnamon_whatsapp_url( $text = '' ) {
	$url = 'https://wa.me/' . cinnamon_info()['whatsapp_number'];
	return $text ? $url . '?text=' . rawurlencode( $text ) : $url;
}

/**
 * Link to a product category by slug, or to the shop when it doesn't exist yet.
 *
 * @param string $slug Category slug.
 * @return string
 */
function cinnamon_category_url( $slug ) {
	$term = get_term_by( 'slug', $slug, 'product_cat' );
	if ( $term && ! is_wp_error( $term ) ) {
		return get_term_link( $term );
	}
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

/**
 * Inline SVG icons. All decorative (aria-hidden).
 *
 * @param string $name Icon name.
 * @return string
 */
function cinnamon_icon( $name ) {
	$stroke = 'fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"';
	$icons  = array(
		'whatsapp'  => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3Z"/></svg>',
		'truck'     => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg>',
		'chat'      => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.8 7L4 20l1-4.6A8 8 0 1 1 21 12Z"/><path d="M8.5 11h7M8.5 14h4"/></svg>',
		'card'      => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/></svg>',
		'phone'     => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2Z"/></svg>',
		'mail'      => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>',
		'instagram' => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
		'store'     => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><path d="M4 10v10h16V10"/><path d="M3 10 5 4h14l2 6"/><path d="M9 20v-6h6v6"/></svg>',
		'search'    => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>',
		'user'      => '<svg viewBox="0 0 24 24" ' . $stroke . ' aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/></svg>',
	);
	return $icons[ $name ] ?? '';
}
