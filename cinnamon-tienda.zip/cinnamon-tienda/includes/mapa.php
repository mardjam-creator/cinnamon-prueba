<?php
/**
 * Delivery location picker for the checkout.
 *
 * A text field ("lat,lng") registered with WooCommerce's additional checkout
 * fields API stores the point with the order. The checkout script hides that
 * field and shows a map (Leaflet + OpenStreetMap) under the shipping address,
 * only when the customer chose home delivery.
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

const CINNAMON_MAP_FIELD = 'cinnamon/ubicacion';

/**
 * Parses "lat,lng" inside Uruguay's bounding box (with margin).
 *
 * @param string $value Raw value.
 * @return array{0:float,1:float}|null
 */
function cinnamon_tienda_parse_point( $value ) {
	if ( ! preg_match( '/^\s*(-?\d{1,2}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)\s*$/', (string) $value, $m ) ) {
		return null;
	}
	$lat = (float) $m[1];
	$lng = (float) $m[2];
	if ( $lat < -35.5 || $lat > -29.5 || $lng < -59 || $lng > -52.5 ) {
		return null;
	}
	return array( $lat, $lng );
}

add_action(
	'woocommerce_init',
	function () {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'                => CINNAMON_MAP_FIELD,
				'label'             => 'Ubicación en el mapa',
				'optionalLabel'     => 'Ubicación en el mapa (opcional)',
				'location'          => 'order',
				'type'              => 'text',
				'required'          => false,
				'attributes'        => array( 'autocomplete' => 'off' ),
				'sanitize_callback' => function ( $value ) {
					$point = cinnamon_tienda_parse_point( $value );
					return $point ? sprintf( '%.6f,%.6f', $point[0], $point[1] ) : '';
				},
				'validate_callback' => function ( $value ) {
					if ( '' !== (string) $value && ! cinnamon_tienda_parse_point( $value ) ) {
						return new WP_Error( 'cinnamon_invalid_location', 'La ubicación marcada en el mapa no es válida. Volvé a marcarla o dejala vacía.' );
					}
				},
			)
		);
	}
);

/**
 * Checkout scripts: Leaflet and the picker, on the checkout page only.
 */
add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
			return;
		}
		$base = plugin_dir_url( CINNAMON_TIENDA_DIR . 'cinnamon-tienda.php' ) . 'assets/';
		wp_enqueue_style( 'leaflet', $base . 'leaflet/leaflet.css', array(), '1.9.4' );
		wp_enqueue_script( 'leaflet', $base . 'leaflet/leaflet.js', array(), '1.9.4', true );
		wp_enqueue_style( 'cinnamon-mapa', $base . 'mapa/mapa.css', array( 'leaflet' ), CINNAMON_TIENDA_VERSION );
		wp_enqueue_script( 'cinnamon-mapa', $base . 'mapa/mapa.js', array( 'leaflet', 'wp-data' ), CINNAMON_TIENDA_VERSION, true );
		wp_localize_script(
			'cinnamon-mapa',
			'cinnamonMapa',
			array(
				'field'     => CINNAMON_MAP_FIELD,
				'center'    => array( -34.8941, -56.1525 ), // Montevideo.
				'iconsPath' => $base . 'leaflet/images/',
				// The point fills in department and city: WooCommerce's departments, and the
				// Ciudad de la Costa names that count as the same city (includes/agencia.php).
				'states'    => WC()->countries->get_states( 'UY' ),
				'costa'     => cinnamon_tienda_costa_cities(),
			)
		);
	}
);

/**
 * The chosen point for an order, or null.
 *
 * @param WC_Order $order Order.
 * @return array{0:float,1:float}|null
 */
function cinnamon_tienda_order_point( $order ) {
	return cinnamon_tienda_parse_point( $order->get_meta( '_wc_other/' . CINNAMON_MAP_FIELD ) );
}

/**
 * Map link for a point.
 *
 * @param array{0:float,1:float} $point Point.
 * @return string
 */
function cinnamon_tienda_map_url( $point ) {
	return sprintf( 'https://www.google.com/maps/search/?api=1&query=%.6f,%.6f', $point[0], $point[1] );
}

// Order screen in wp-admin: link under the shipping address.
add_action(
	'woocommerce_admin_order_data_after_shipping_address',
	function ( $order ) {
		$point = cinnamon_tienda_order_point( $order );
		if ( $point ) {
			printf(
				'<p><strong>Ubicación marcada por el cliente:</strong><br><a href="%s" target="_blank" rel="noopener">Ver en el mapa</a> (%s)</p>',
				esc_url( cinnamon_tienda_map_url( $point ) ),
				esc_html( sprintf( '%.5f, %.5f', $point[0], $point[1] ) )
			);
		}
	}
);

// New-order emails to the shop: same link, so whoever prepares the delivery has it.
add_action(
	'woocommerce_email_after_order_table',
	function ( $order, $sent_to_admin, $plain_text ) {
		$point = $sent_to_admin ? cinnamon_tienda_order_point( $order ) : null;
		if ( ! $point ) {
			return;
		}
		if ( $plain_text ) {
			echo "\nUbicación marcada por el cliente: " . esc_url_raw( cinnamon_tienda_map_url( $point ) ) . "\n";
			return;
		}
		printf( '<p><strong>Ubicación marcada por el cliente:</strong> <a href="%s">Ver en el mapa</a></p>', esc_url( cinnamon_tienda_map_url( $point ) ) );
	},
	10,
	3
);
