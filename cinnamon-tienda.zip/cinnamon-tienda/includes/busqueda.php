<?php
/**
 * Product search that ignores accents and case, on any database.
 *
 * WordPress compares search terms with LIKE, so whether "chia" finds "chía"
 * depends on the database collation. Each product keeps a normalized copy of
 * its searchable text (name, summary, description, SKU) in a meta field, and
 * product searches also match the normalized term against it. This covers the
 * search results page and the Store API used by the header suggestions.
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

const CINNAMON_SEARCH_META    = '_cinnamon_busqueda';
const CINNAMON_SEARCH_VERSION = 1; // Bump to rebuild every product's search text.

/**
 * Lowercase, accent-free, single-spaced text.
 *
 * @param string $text Text.
 * @return string
 */
function cinnamon_tienda_normalize( $text ) {
	$text = wp_strip_all_tags( strip_shortcodes( html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' ) ) );
	$text = remove_accents( mb_strtolower( $text, 'UTF-8' ) );
	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * Stores the normalized search text of a product.
 *
 * @param int $product_id Product ID.
 */
function cinnamon_tienda_index_product( $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product || $product->is_type( 'variation' ) ) {
		return;
	}
	$parts = array( $product->get_name(), $product->get_short_description(), $product->get_description(), $product->get_sku() );
	update_post_meta( $product->get_id(), CINNAMON_SEARCH_META, cinnamon_tienda_normalize( implode( ' ', $parts ) ) );
}

add_action(
	'woocommerce_after_product_object_save',
	function ( $product ) {
		cinnamon_tienda_index_product( $product->get_id() );
	}
);

/**
 * Indexes every product. Runs once per CINNAMON_SEARCH_VERSION and after the
 * "Productos" setup step.
 *
 * @return int Products indexed.
 */
function cinnamon_tienda_index_all_products() {
	$ids = get_posts(
		array(
			'post_type'      => 'product',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);
	foreach ( $ids as $id ) {
		cinnamon_tienda_index_product( $id );
	}
	update_option( 'cinnamon_busqueda_version', CINNAMON_SEARCH_VERSION, false );
	return count( $ids );
}

add_action(
	'admin_init',
	function () {
		if ( (int) get_option( 'cinnamon_busqueda_version' ) !== CINNAMON_SEARCH_VERSION && class_exists( 'WooCommerce' ) ) {
			cinnamon_tienda_index_all_products();
		}
	}
);

/**
 * Whether a query is a product search.
 *
 * @param WP_Query $query Query.
 * @return bool
 */
function cinnamon_tienda_is_product_search( $query ) {
	if ( ! $query->is_search() && '' === (string) $query->get( 's' ) ) {
		return false;
	}
	$types = (array) $query->get( 'post_type' );
	return in_array( 'product', $types, true );
}

/**
 * Rebuilds the search clause of product searches: each term must match the
 * title, summary or content as usual, or the normalized text.
 *
 * @param string   $search SQL search clause.
 * @param WP_Query $query  Query.
 * @return string
 */
function cinnamon_tienda_search_clause( $search, $query ) {
	global $wpdb;
	if ( '' === $search || ! cinnamon_tienda_is_product_search( $query ) ) {
		return $search;
	}
	$terms = (array) $query->get( 'search_terms' );
	if ( ! $terms ) {
		return $search;
	}
	$clauses = array();
	foreach ( $terms as $term ) {
		$term = (string) $term;
		if ( '' === $term || '-' === $term[0] ) {
			continue; // Exclusion terms keep WordPress's own handling below.
		}
		$like       = '%' . $wpdb->esc_like( $term ) . '%';
		$normalized = '%' . $wpdb->esc_like( cinnamon_tienda_normalize( $term ) ) . '%';
		$clauses[]  = $wpdb->prepare(
			"({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_excerpt LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR {$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value LIKE %s))",
			$like,
			$like,
			$like,
			CINNAMON_SEARCH_META,
			$normalized
		);
	}
	if ( ! $clauses ) {
		return $search;
	}
	return ' AND (' . implode( ' AND ', $clauses ) . ') ';
}
add_filter( 'posts_search', 'cinnamon_tienda_search_clause', 20, 2 );

/**
 * Suggestions for the header search: GET /wp-json/cinnamon/v1/buscar?search=chia
 *
 * The Store API products endpoint builds its own title/SKU clause and skips the
 * search above, so suggestions go through WP_Query here and always match the
 * results page. The response mirrors the Store API fields the theme reads.
 */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'cinnamon/v1',
			'/buscar',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'args'                => array(
					'search'   => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 6,
						'minimum' => 1,
						'maximum' => 12,
					),
				),
				'callback'            => 'cinnamon_tienda_search_suggestions',
			)
		);
	}
);

/**
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function cinnamon_tienda_search_suggestions( $request ) {
	$term = trim( (string) $request['search'] );
	if ( mb_strlen( $term ) < 2 ) {
		return rest_ensure_response( array() );
	}
	$hidden = get_term_by( 'slug', 'exclude-from-search', 'product_visibility' );
	$query  = new WP_Query(
		array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			's'              => $term,
			'posts_per_page' => (int) $request['per_page'],
			'no_found_rows'  => true,
			'tax_query'      => $hidden ? array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => array( $hidden->term_taxonomy_id ),
					'operator' => 'NOT IN',
				),
			) : array(),
		)
	);
	$items = array();
	foreach ( $query->posts as $post ) {
		$product = wc_get_product( $post );
		if ( ! $product ) {
			continue;
		}
		$image   = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_gallery_thumbnail' );
		$items[] = array(
			'id'         => $product->get_id(),
			'name'       => $product->get_name(),
			'permalink'  => $product->get_permalink(),
			'images'     => $image ? array( array( 'thumbnail' => $image ) ) : array(),
			'price_html' => $product->get_price_html(),
		);
	}
	return rest_ensure_response( $items );
}

/**
 * URL the theme's header search uses for suggestions.
 *
 * @return string
 */
function cinnamon_tienda_search_suggestions_url() {
	return rest_url( 'cinnamon/v1/buscar' );
}
