<?php
/**
 * Page content. Texts copied from the pages at cinnamon.uy (Sobre nosotros,
 * Envíos a domicilio, Política de privacidad).
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

/**
 * Paragraph blocks from plain strings.
 *
 * @param string[] $paragraphs Text.
 * @return string
 */
function cinnamon_tienda_paragraphs( array $paragraphs ) {
	$out = '';
	foreach ( $paragraphs as $p ) {
		$out .= "<!-- wp:paragraph -->\n<p>" . $p . "</p>\n<!-- /wp:paragraph -->\n\n";
	}
	return $out;
}

/**
 * Heading block.
 *
 * @param string $text Text.
 * @return string
 */
function cinnamon_tienda_heading( $text ) {
	return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . $text . "</h2>\n<!-- /wp:heading -->\n\n";
}

/**
 * Pages to create, keyed by slug.
 *
 * @return array<string,array{title:string,content:string,template?:string}>
 */
function cinnamon_tienda_pages() {
	$sobre = cinnamon_tienda_paragraphs(
		array(
			'Cinnamon Boutique Gourmet es una empresa familiar que fue fundada en abril del año 2018. Desde nuestros inicios la idea ha sido brindar una completa gama de productos que apunten al consumidor gourmet, además de satisfacer a distintos tipos de consumidores, como ser a quienes buscan una alimentación saludable, gluten free, sin azúcar, veganos y vegetarianos, entre otros. A su vez, siempre hemos buscado brindar una atención cálida que se base en un asesoramiento personal y profesional de nuestros clientes.',
			'En nuestra tienda encontrará una variada gama de productos de venta a granel los cuales se fraccionan en diversas presentaciones, entre ellos se destacan los frutos secos, los condimentos, las semillas, los cereales para el desayuno y las harinas. Además, contamos con numerosos productos envasados, dentro de los cuales podemos destacar los té importados, los aceites de oliva extra virgen, los alimentos gluten free, los alimentos orgánicos, entre otros.',
			'También se destaca en nuestra tienda nuestro espacio dedicado al café molido o en grano, contamos con nuestro sector “La Casa del Café”, donde ofrecemos distintas variedades de granos, los cuales pueden ser adquiridos en grano o molidos en el momento, para favorecer su frescura y calidad a la hora de degustar la bebida.',
			'Desde este sitio web podrá encontrar y adquirir cómodamente nuestros exquisitos productos, acceder a nuevas promociones y ofertas, pretendiendo así estar más cerca de nuestros clientes para brindarles cada vez un mejor servicio.',
			'Los invitamos a visitar nuestra casa donde nos distingue un ambiente familiar y donde podrán acceder a distintos alimentos de alta calidad y sabores.',
			'¡Los esperamos!',
		)
	);

	$tabla = '<!-- wp:table {"className":"shipping-table"} -->
<figure class="wp-block-table shipping-table"><table><thead><tr><th>Zona</th><th>Agencia</th><th>Costo</th><th>Gratis desde</th></tr></thead><tbody><tr><td>Montevideo y Ciudad de la Costa (incluye Aeropuerto de Carrasco, Altos y Mirador de la Tahona, Colinas, Cumbres y Lomas de Carrasco, Los Aromos, Zona América, Villa García, Villa Aeroparque y General Líber Seregni)</td><td>Dash Pack</td><td>$190</td><td>$2.500</td></tr><tr><td>Costa de Oro, Costa de Maldonado, Pando, Barros Blancos, Empalme Olmos y demás localidades de la cobertura de DePunta (fuera de Montevideo y Ciudad de la Costa)</td><td>DePunta</td><td>Según el peso del pedido (desde $240)</td><td>Según el peso (desde $3.500)</td></tr><tr><td>Interior del país</td><td>La Nave Cargo Postal</td><td>Según el peso del pedido (desde $285)</td><td>Según el peso (desde $4.000)</td></tr><tr><td>Fuera de Montevideo y Ciudad de la Costa, en compras desde $1.000</td><td>Agencia a elección de la Terminal Tres Cruces</td><td>Se paga al recibir</td><td>-</td></tr><tr><td>Retiro en el local (Dr. Pablo de María 1441), lunes a viernes de 10:00 a 19:00</td><td>-</td><td>Sin costo</td><td>-</td></tr></tbody></table><figcaption class="wp-element-caption">Dash Pack tiene el mismo costo y envío gratis para cualquier peso. DePunta y La Nave cobran según el peso del pedido (la suma del peso de los productos), como indican las tablas de abajo. Los pedidos de más de 50 kg solo pueden enviarse con Dash Pack o retirarse en el local.</figcaption></figure>
<!-- /wp:table -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Costos de DePunta y La Nave según el peso</h3>
<!-- /wp:heading -->

<!-- wp:shortcode -->
[cinnamon_tarifas_peso]
<!-- /wp:shortcode -->

';

	$envios = $tabla . cinnamon_tienda_heading( 'Información de entrega' ) . cinnamon_tienda_paragraphs(
		array(
			'Los productos adquiridos en el local, vía telefónica, vía WhatsApp o a través del Sitio Web estarán sujetos a las condiciones de entrega disponibles en el mismo.',
			'Todas las compras realizadas vía telefónica, whatsapp o en el Sitio Web, se pueden retirar en nuestro local de Pablo de María 1441, de lunes a viernes en el horario de 10:00 a 19:00 hs, sin costo alguno. Los pedidos realizados antes de las 15:00 hs, podrán retirarse el próximo día hábil (lun. a vie.) en cualquier horario, y los pedidos realizados luego de las 15:00 hs podrán retirarse el próximo día hábil luego de las 15:00 hs. En caso de faltantes de mercadería, el usuario tendrá la opción de elegir retrasar el tiempo de retiro del pedido hasta que la mercadería entre en stock, o acceder a la devolución del importe correspondiente a través del medio de pago con que realizó el pedido.',
			'Las entregas a domicilio para la zona comprendida por el departamento de Montevideo y Ciudad de la Costa (incluidos Aeropuerto de Carrasco, Altos y Mirador de la Tahona, Colinas, Cumbres y Lomas de Carrasco, Los Aromos, Zona América, Villa García, Villa Aeroparque y General Líber Seregni) se realizan con la agencia Dash Pack y tendrá un costo de $U 190 (pesos uruguayos ciento noventa) impuestos incluidos; salvo para compras iguales o mayores a $U 2.500 (pesos uruguayos dos mil quinientos) impuestos incluidos, donde el envío se realiza en forma gratuita, sin límite de peso.',
			'Las entregas a domicilio para la zona comprendida por Costa de Oro, Costa de Maldonado, Pando, Barros Blancos, Empalme Olmos y las demás localidades de la zona de cobertura de DePunta (<a href="https://www.depunta.com/zonas-cobertura">depunta.com/zonas-cobertura</a>), salvo Montevideo y Ciudad de la Costa, se realizan con la agencia DePunta y tienen un costo según el peso total del pedido, de acuerdo con la tabla de DePunta de esta página, impuestos incluidos; el envío se realiza en forma gratuita cuando la compra alcanza el monto que la tabla indica para ese peso.',
			'Para las entregas a domicilio en aquellas zonas del interior del país que no se incluyan en los párrafos anteriores, el usuario tendrá dos opciones para elegir: Utilizar el envío proporcionado por nuestra empresa para el Interior del país, que se canaliza con la agencia La Nave Cargo Postal (ex MirTrans), con un costo según el peso total del pedido, de acuerdo con la tabla de La Nave de esta página, impuestos incluidos, y en forma gratuita cuando la compra alcanza el monto que la tabla indica para ese peso; o bien, si desea el envío por otra agencia, puede elegir al finalizar la compra la opción "Agencia a elección" e indicar su agencia de preferencia, que debe ser una agencia de la Terminal Tres Cruces. Esta opción es válida para pedidos desde $1.000 y para direcciones fuera de Montevideo y Ciudad de la Costa; en pedidos menores sólo se puede enviar por Agencia La Nave Cargo Postal (ex MirTrans). El costo del envío por la agencia elegida queda a cargo del cliente y se paga al recibir el pedido.',
			'Para cualquiera de estas opciones, el tiempo estimado de entrega varía de un día a tres días hábiles posteriores al día que Cinnamon haya validado la orden de compra y el medio de pago utilizado. En cualquiera de los casos, Cinnamon no se responsabiliza por demoras que excedan los días estimados, cuando la responsabilidad corresponda a las empresas contratadas (Dash Pack, DePunta, La Nave). También, en caso de faltantes de mercadería, el usuario tendrá la opción de elegir retrasar el tiempo del envío hasta que la mercadería entre en stock, para lo cual, los días estimados de entrega se comenzarán a contar una vez que el cliente sea notificado que la mercadería faltante ya se encuentra disponible; o acceder a la devolución del importe correspondiente a través del medio de pago con que realizó el pedido.',
			'Ninguno de los envíos que se ofrecen en el sitio se realizan con un horario determinado, siempre el horario de entrega depende de la ruta de las agencias, en caso de necesitar la entrega en determinado horario se puede hacer la observación al realizar el pedido, y se tomaría en cuenta para el envío, sin embargo no es con seguridad que el paquete pueda llegar en esas condiciones. En el caso que las agencias no puedan realizar el envío, ya sea por el horario o por la zona de entrega, la casa tiene el derecho de anular el pedido haciendo la devolución correspondiente a través del mismo método de pago utilizado para abonar la compra, si por alguna razón el pedido salió en reparto, solo se devolvería el monto equivalente a los productos comprados, y en caso de ser con envío gratis, al monto total se le descontaría el monto equivalente al costo del envío para esa zona.',
			'Los pedidos de más de 50 kg solo pueden enviarse con Dash Pack, en su zona, o retirarse en el local; para otros destinos nos comunicaremos con el cliente para coordinar el envío.',
			'Si al recibir la mercadería el cliente percibe faltantes o mercadería que no se corresponde con lo adquirido, deberá comunicarlo en un plazo no mayor a las 24 horas, por el teléfono 24000542, vía whatsapp al 096181666 o vía e-mail a: <a href="mailto:info@cinnamon.uy">info@cinnamon.uy</a> para coordinar su restitución o cambio.',
		)
	);

	$privacidad = cinnamon_tienda_heading( 'Protección de datos personales' ) . cinnamon_tienda_paragraphs(
		array(
			'Esta política corresponde a la Privacidad de los Datos vertidos por el usuario en el Sitio web, expuesta en la Ley Nº 18.331 - Protección de Datos Personales y Acción de "Habeas Data" - Artículo 72 de la Constitución de la República. La información y datos que Ud. nos proporcione voluntariamente a través del Sitio Web se incluirán en una base de datos que quedará bajo la responsabilidad de Cinnamon, con el objetivo de proporcionarle un servicio personalizado y a la altura de sus necesidades, mejorando el canal de comunicación con el usuario. Sus datos también podrán utilizarse para elaborar estadísticas y estudios de mercado. Asimismo, el registro en el Sitio Web implicará su autorización para que se le envíe boletines, newsletters o correspondencia sobre las novedades institucionales, comerciales y promocionales de Cinnamon. Si no desea recibir más mensajes, podrá solicitar la cancelación del envío de los mismos en cualquier momento, simplemente siga las instrucciones que encontrara a pie de página al final de cualquier mensaje de correo electrónico.',
			'Cinnamon realizará el tratamiento de sus datos personales con absoluta reserva, adoptando para ello los recaudos técnicos y organizativos necesarios en lo que respecta a la custodia, almacenamiento, conservación y confidencialidad de la información con el fin de evitar su alteración, pérdida, tratamiento o acceso no autorizado de los mismos.',
			'Sus datos personales podrán ser compartidos con empresas contratadas por Cinnamon (ej. empresas de servicios logísticos) a fin de poder ofrecerle nuestros servicios y cumplir con las presentes condiciones de uso, para lo cual Ud. presta su expreso consentimiento y autorización.',
			'Ud. tiene la facultad de ejercer el derecho al acceso de sus datos personales de forma gratuita y solicitar su actualización, rectificación o supresión. A tal fin, deberá enviar un e-mail a <a href="mailto:info@cinnamon.uy">info@cinnamon.uy</a> o comunicarse telefónicamente al 24000542.',
		)
	);

	$contacto = cinnamon_tienda_paragraphs(
		array(
			'<strong>Cinnamon Boutique Gourmet</strong><br>Dr. Pablo de María 1441, Montevideo, Uruguay<br>Lunes a viernes de 10:00 a 19:00',
		)
	) . "<!-- wp:pattern {\"slug\":\"cinnamon/contacto\"} /-->\n";

	$ofertas = cinnamon_tienda_paragraphs( array( 'Productos con precio rebajado. Las ofertas cambian seguido: volvé a mirar o escribinos por WhatsApp.' ) )
		. "<!-- wp:shortcode -->\n[sale_products limit=\"24\" columns=\"3\"]\n<!-- /wp:shortcode -->\n";

	// Terms from Cinnamon (historia 6.8). Prices come from WooCommerce > Planes de suscripción.
	$lista       = static function ( array $items ) {
		$out = array();
		foreach ( $items as $item ) {
			$out[] = "<!-- wp:list-item -->\n<li>" . $item . "</li>\n<!-- /wp:list-item -->";
		}
		return "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . implode( "\n\n", $out ) . "</ul>\n<!-- /wp:list -->\n\n";
	};
	$suscripcion = cinnamon_tienda_paragraphs(
		array( 'Recibí todos los meses el café de especialidad de La Casa del Café, en grano o molido en el momento para tu forma de prepararlo. Se cobra automáticamente con Mercado Pago.' )
	) . cinnamon_tienda_heading( 'Cómo funciona' )
	. $lista(
		array(
			'<strong>Elegí tu café:</strong> Brasil, Colombia, Espresso, Brasil Premium o Colombia Premium.',
			'<strong>Cuánto:</strong> 500 g, 1 kg o 2 kg por mes.',
			'<strong>Cómo:</strong> en grano o molido en el momento para espresso, cafetera italiana, filtro o prensa francesa.',
			'<strong>Pago:</strong> te suscribís con Mercado Pago y se cobra automáticamente todos los meses. Podés cancelar cuando quieras desde tu cuenta de Mercado Pago o avisándonos por WhatsApp.',
		)
	)
	. cinnamon_tienda_heading( 'Envío' )
	. $lista(
		array(
			'<strong>Montevideo y Ciudad de la Costa:</strong> envío incluido en el precio, con Dash Pack.',
			'<strong>Interior:</strong> elegís una agencia de la Terminal Tres Cruces, La Nave Cargo Postal o DePunta (en las localidades donde llega), y pagás el envío al recibir.',
		)
	)
	. cinnamon_tienda_heading( 'Planes y precios' )
	. "<!-- wp:shortcode -->\n[cinnamon_suscripcion_precios]\n<!-- /wp:shortcode -->\n\n"
	. cinnamon_tienda_heading( 'Suscribite' )
	. "<!-- wp:shortcode -->\n[cinnamon_suscripcion]\n<!-- /wp:shortcode -->\n";

	return array(
		'inicio'                 => array( 'title' => 'Inicio', 'content' => '' ),
		'suscripcion-de-cafe'    => array( 'title' => 'Suscripción de café', 'content' => $suscripcion ),
		'sobre-nosotros'         => array( 'title' => 'Sobre nosotros', 'content' => $sobre ),
		'envios-a-domicilio'     => array( 'title' => 'Envíos a domicilio', 'content' => $envios ),
		'politica-de-privacidad' => array( 'title' => 'Política de privacidad', 'content' => $privacidad ),
		'contacto'               => array( 'title' => 'Contacto', 'content' => $contacto, 'template' => 'page-wide' ),
		'ofertas'                => array( 'title' => 'Ofertas', 'content' => $ofertas, 'template' => 'page-wide' ),
	);
}

/**
 * Product category tree, same as cinnamon.uy. Name => children.
 *
 * @return array<string,string[]>
 */
function cinnamon_tienda_categories() {
	return array(
		'Frutos Secos'              => array( 'Frutas Secas', 'Frutas Glaseadas', 'Snacks' ),
		'Condimentos'               => array( 'Condimentos Granel', 'Especieros y Molinillos' ),
		'Infusiones'                => array( 'Té e Infusiones', 'Café', 'Hierbas Medicinales' ),
		'Cereales y Granolas'       => array(),
		'Semillas y Granos'         => array(),
		'Harinas y Moliendas'       => array(),
		'Sin Gluten'                => array( 'Harinas y Premezclas', 'Galletas y Panificados', 'Chocolates sin gluten', 'Pasta sin gluten', 'Snacks sin gluten' ),
		'Sin Azúcar'                => array(),
		'Comestibles'               => array( 'Varios', 'Galletas y Panificados' ),
		'Chocolates Repostería'     => array(),
		'Aceites'                   => array(),
		'Bebidas Vegetales'         => array(),
		'Orgánicos'                 => array(),
		'Pasta'                     => array(),
		'Suplementos Nutricionales' => array(),
		'Productos Keto'            => array(),
		'Vinos Finos'               => array(),
		'Licores'                   => array(),
	);
}

/**
 * The six products from the earlier WooCommerce draft, with real prices.
 * Categories are name paths ("Parent > Child").
 *
 * @return array<int,array<string,mixed>>
 */
function cinnamon_tienda_sample_products() {
	return array(
		array(
			'name'        => 'Almendras peladas',
			'sku'         => 'ALM-PEL',
			'category'    => 'Frutos Secos',
			'image'       => 'almendras-peladas.jpg',
			'short'       => 'Almendras enteras y sin cáscara, listas para comer o cocinar. Llevando 500 g o 1 kg pagás menos por kilo.',
			'description' => '<p>Nuestras almendras peladas vienen enteras y sin cáscara. Las fraccionamos en el local en tres presentaciones, para que lleves la cantidad justa para tu casa.</p><p>Son fuente de grasas insaturadas, proteína vegetal, fibra, vitamina E y magnesio. Un puñado es un snack práctico que da saciedad entre comidas.</p><p>Sumalas a desayunos, ensaladas y granolas, tostalas para acompañar platos salados, o usalas para hacer leche de almendras y repostería.</p><p><strong>Ingredientes:</strong> 100 % almendras.<br><strong>Apto para:</strong> veganos y vegetarianos.<br><strong>Alérgenos:</strong> contiene frutos secos.<br><strong>Conservación:</strong> en envase hermético, en lugar fresco, seco y protegido de la luz. En verano, mejor en la heladera.</p>',
			'variations'  => array(
				array( '100 g', 115, null ),
				array( '500 g', 575, 518 ),
				array( '1 kg', 1150, 920 ),
			),
		),
		array(
			'name'        => 'Harina de almendras',
			'sku'         => 'HAR-ALM',
			'category'    => 'Harinas y Moliendas',
			'image'       => 'harina-de-almendras.jpg',
			'short'       => 'Almendras molidas finamente, ideales para repostería. Llevando 500 g o 1 kg pagás menos por kilo.',
			'description' => '<p>La harina de almendras se obtiene moliendo almendras hasta lograr una textura fina. Aporta humedad, un sabor suave y un tono dorado a tus preparaciones.</p><p>Es la base de macarons, bizcochuelos, galletas y tartas, y se usa mucho en recetas bajas en carbohidratos. Para empezar, reemplazá entre un cuarto y un tercio de la harina de trigo de tu receta.</p><p>También sirve para rebozar, espesar salsas o sumar a la avena y los yogures.</p><p><strong>Ingredientes:</strong> 100 % almendras molidas.<br><strong>Apto para:</strong> veganos y vegetarianos.<br><strong>Alérgenos:</strong> contiene frutos secos.<br><strong>Conservación:</strong> en envase hermético, en lugar fresco y seco. Una vez abierta, mejor en la heladera.</p>',
			'variations'  => array(
				array( '150 g', 180, null ),
				array( '500 g', 600, 540 ),
				array( '1 kg', 1200, 960 ),
			),
		),
		array(
			'name'        => 'Semillas de chía',
			'sku'         => 'SEM-CHIA',
			'category'    => 'Semillas y Granos',
			'image'       => 'semillas-de-chia.jpg',
			'short'       => 'Ideales para sumar a yogures, puddings, licuados o ensaladas.',
			'description' => '<p>Nuestras semillas de chía son la forma más sencilla y natural de enriquecer tu alimentación diaria. Tienen un sabor sutil que se adapta a cualquier preparación.</p><p>Son fuente de omega-3 y fibra soluble. Al hidratarse forman un gel que ayuda a la digestión y da saciedad.</p><p><strong>Ingredientes:</strong> 100 % semillas de chía (Salvia hispanica). Sin aditivos ni conservantes.<br><strong>Apto para:</strong> veganos y vegetarianos.<br><strong>Conservación:</strong> en lugar fresco, seco y protegido de la luz, en envase hermético.</p>',
			'variations'  => array(
				array( '250 g', 100, null ),
				array( '1 kg', 400, 340 ),
			),
		),
		array(
			'name'        => 'Cúrcuma en polvo',
			'sku'         => 'CON-CUR',
			'category'    => 'Condimentos > Condimentos Granel',
			'image'       => 'curcuma.jpg',
			'short'       => 'Cúrcuma molida de color intenso y sabor cálido, para dar color y aroma a tus comidas.',
			'description' => '<p>La cúrcuma es la raíz de la planta Curcuma longa, secada y molida. Tiene un color amarillo anaranjado intenso y un sabor cálido, apenas amargo.</p><p>Es la especia que le da color al curry. Usala en arroces, guisos, sopas, salteados de verduras, huevos revueltos o en la leche dorada (golden milk).</p><p>Un consejo: cocinala unos segundos en un poco de aceite antes de sumar el resto de los ingredientes, y agregale una pizca de pimienta negra. Así libera todo su aroma.</p><p><strong>Ingredientes:</strong> 100 % cúrcuma molida (Curcuma longa).<br><strong>Apto para:</strong> veganos y vegetarianos.<br><strong>Conservación:</strong> en frasco hermético, lejos de la luz y del calor, para que mantenga su color y aroma.</p>',
			'variations'  => array(
				array( '80 g', 100, null ),
				array( '250 g', 312.5, 281.25 ),
				array( '500 g', 625, 500 ),
			),
		),
		array(
			'name'        => 'Aceite de coco Prana extra virgen 500 ml',
			'sku'         => 'ACE-COCO-PRANA-500',
			'category'    => 'Aceites',
			'image'       => 'aceite-de-coco-prana.jpg',
			'short'       => 'Aceite de coco extra virgen y orgánico, prensado en frío. Frasco de 500 ml.',
			'description' => '<p>El aceite de coco Prana es extra virgen, prensado en frío y sin refinar ni blanquear. Se elabora en Sri Lanka y tiene certificación orgánica.</p><p>Es fuente de ácidos grasos de cadena media (MCT). Por debajo de unos 24 °C está sólido y por encima se vuelve líquido: es normal y no cambia su calidad.</p><p>Usalo para saltear y hornear, en repostería en lugar de la manteca, en licuados o untado en tostadas. Tiene un suave aroma a coco.</p><p><strong>Ingredientes:</strong> 100 % aceite de coco extra virgen orgánico.<br><strong>Origen:</strong> Sri Lanka.<br><strong>Apto para:</strong> veganos y vegetarianos.<br><strong>Conservación:</strong> en lugar fresco y seco, con el frasco bien cerrado.</p>',
			'price'       => 505,
		),
		array(
			'name'        => 'Pan multigrano sin gluten Jasmine 350 g',
			'sku'         => 'SG-PAN-JASMINE-350',
			'category'    => 'Sin Gluten > Galletas y Panificados',
			'image'       => 'pan-multigrano-sin-gluten.jpg',
			'short'       => 'Pan de molde multigrano sin gluten, con 6 granos integrales. Paquete de 350 g.',
			'description' => '<p>Pan de molde rebanado de la marca brasileña Jasmine, sin gluten y con 6 granos integrales. Tiene el sello Sin T.A.C.C. y es apto para vegetarianos.</p><p>Cada rebanada aporta 67 kcal. Ideal para tostadas, sándwiches y desayunos.</p><p><strong>Sin gluten:</strong> sí, con sello Sin T.A.C.C.<br><strong>Apto para:</strong> vegetarianos.<br><strong>Alérgenos:</strong> contiene derivados de soja. Puede contener huevo, maní, almendra, avellana, castaña de cajú, castaña de Pará, macadamia, nueces, pecán, pistacho y piñones.<br><strong>Conservación:</strong> en lugar seco y fresco, lejos del sol. Una vez abierto, guardalo en su envase y consumilo dentro de los 5 días.</p>',
			'price'       => 249,
		),
	);
}
