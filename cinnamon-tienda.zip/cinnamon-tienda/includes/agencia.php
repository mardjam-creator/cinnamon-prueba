<?php
/**
 * "Agencia a elección" shipping: for addresses outside Montevideo and Ciudad
 * de la Costa, on orders from $1.000. The customer names an agency at the
 * Terminal Tres Cruces and pays the shipping when it arrives, so the rate
 * costs $0 in the shop. The agency is an order field, shown and required only
 * with this rate.
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

const CINNAMON_AGENCY_METHOD = 'cinnamon_agencia';
const CINNAMON_AGENCY_FIELD  = 'cinnamon/agencia';
const CINNAMON_AGENCY_MIN    = 1000;

/**
 * Ciudad de la Costa and its neighbourhoods, as customers write them in the
 * city field (compared without case or accents).
 *
 * @return string[]
 */
function cinnamon_tienda_costa_cities() {
	return apply_filters(
		'cinnamon_tienda_costa_cities',
		array(
			'Ciudad de la Costa',
			'Barra de Carrasco',
			'Parque Carrasco',
			'Shangrilá',
			'San José de Carrasco',
			'San José de Carrasco Norte',
			'Lagomar',
			'Solymar',
			'Lomas de Solymar',
			'Colinas de Solymar',
			'Médanos de Solymar',
			'Montes de Solymar',
			'Parque de Solymar',
			'El Pinar',
			'Pinar Norte',
			// Nearby places Cinnamon serves with the Ciudad de la Costa Dash Pack rate (2026-10-29).
			'Aeropuerto Internacional de Carrasco',
			'Altos de la Tahona',
			'Colinas de Carrasco',
			'Cumbres de Carrasco',
			'Los Aromos',
			'Lomas de Carrasco',
			'Mirador de la Tahona',
			'Zona América',
			'Villa García',
			'Villa Aeroparque',
			// Added 2026-10-30, with the short forms customers write.
			'General Líber Seregni',
			'Gral. Líber Seregni',
			'Líber Seregni',
		)
	);
}

/**
 * Lowercase, no accents, single spaces.
 *
 * @param string $text Text.
 * @return string
 */
function cinnamon_tienda_normalize_place( $text ) {
	return trim( preg_replace( '/\s+/', ' ', remove_accents( mb_strtolower( (string) $text ) ) ) );
}

/**
 * Whether a shipping destination is in Ciudad de la Costa (Canelones).
 *
 * @param array $dest Package destination.
 * @return bool
 */
function cinnamon_tienda_is_costa( $dest ) {
	if ( 'UY' !== ( $dest['country'] ?? '' ) || 'UY-CA' !== ( $dest['state'] ?? '' ) ) {
		return false;
	}
	$city = cinnamon_tienda_normalize_place( $dest['city'] ?? '' );
	return in_array( $city, array_map( 'cinnamon_tienda_normalize_place', cinnamon_tienda_costa_cities() ), true );
}

/**
 * Whether the package goes somewhere "Agencia a elección" serves.
 *
 * @param array $package Shipping package.
 * @return bool
 */
function cinnamon_tienda_agency_available( $package ) {
	$dest = $package['destination'] ?? array();
	if ( 'UY' !== ( $dest['country'] ?? '' ) || 'UY-MO' === ( $dest['state'] ?? '' ) || cinnamon_tienda_is_costa( $dest ) ) {
		return false;
	}
	// Same total as the free shipping thresholds: products with taxes, after coupons.
	$total = 0;
	foreach ( $package['contents'] ?? array() as $item ) {
		$total += (float) $item['line_total'] + (float) $item['line_tax'];
	}
	return $total >= CINNAMON_AGENCY_MIN;
}

add_action(
	'woocommerce_shipping_init',
	function () {
		/**
		 * Shipping method added to the Canelones, Maldonado and Interior zones.
		 */
		class Cinnamon_Tienda_Agency_Shipping extends WC_Shipping_Method {

			/**
			 * @param int $instance_id Zone method instance.
			 */
			public function __construct( $instance_id = 0 ) {
				$this->id                 = CINNAMON_AGENCY_METHOD;
				$this->instance_id        = absint( $instance_id );
				$this->method_title       = 'Agencia a elección';
				$this->method_description = 'El cliente indica una agencia de la Terminal Tres Cruces y paga el envío al recibir. Solo fuera de Montevideo y Ciudad de la Costa, en compras desde $1.000.';
				$this->supports           = array( 'shipping-zones', 'instance-settings' );
				$this->instance_form_fields = array(
					'title' => array(
						'title'   => 'Nombre',
						'type'    => 'text',
						'default' => 'Agencia a elección',
					),
				);
				$this->init_settings();
				$this->title = $this->get_option( 'title', 'Agencia a elección' );
			}

			/**
			 * @param array $package Package.
			 * @return bool
			 */
			public function is_available( $package ) {
				return parent::is_available( $package ) && cinnamon_tienda_agency_available( $package );
			}

			/**
			 * @param array $package Package.
			 */
			public function calculate_shipping( $package = array() ) {
				$this->add_rate(
					array(
						'label'   => $this->title,
						'cost'    => 0,
						'package' => $package,
					)
				);
				// add_rate() takes no description; the checkout shows it under the label (WooCommerce 9.2+).
				$rate = $this->rates[ $this->get_rate_id() ] ?? null;
				if ( $rate && method_exists( $rate, 'set_description' ) ) {
					$rate->set_description( 'Elegís una agencia de la Terminal Tres Cruces y pagás el envío al recibir.' );
				}
			}
		}
	}
);

add_filter(
	'woocommerce_shipping_methods',
	function ( $methods ) {
		$methods[ CINNAMON_AGENCY_METHOD ] = 'Cinnamon_Tienda_Agency_Shipping';
		return $methods;
	}
);

/**
 * Ciudad de la Costa addresses get only the Dash Pack rate the setup saved
 * (cinnamon_costa_rate), plus pickup at the shop. Other Canelones rates
 * (DePunta, La Nave) don't deliver there, and that Dash Pack rate doesn't
 * deliver to the rest of Canelones. Until the customer types a city, nothing
 * is hidden.
 *
 * @param array<string,WC_Shipping_Rate> $rates   Rates.
 * @param array                          $package Package.
 * @return array
 */
function cinnamon_tienda_costa_rates( $rates, $package ) {
	$costa = (int) get_option( 'cinnamon_costa_rate' );
	$dest  = $package['destination'] ?? array();
	if ( ! $costa || 'UY-CA' !== ( $dest['state'] ?? '' ) || '' === trim( (string) ( $dest['city'] ?? '' ) ) ) {
		return $rates;
	}
	if ( ! cinnamon_tienda_is_costa( $dest ) ) {
		return array_filter( $rates, fn( $rate ) => (int) $rate->get_instance_id() !== $costa );
	}
	$kept = array_filter(
		$rates,
		fn( $rate ) => (int) $rate->get_instance_id() === $costa || in_array( $rate->get_method_id(), array( 'pickup_location', 'local_pickup' ), true )
	);
	// If that rate was removed by hand in WooCommerce, keep the zone's rates rather than none.
	return array_filter( $kept, fn( $rate ) => (int) $rate->get_instance_id() === $costa ) ? $kept : $rates;
}
add_filter( 'woocommerce_package_rates', 'cinnamon_tienda_costa_rates', 30, 2 );

// The rate costs $0 because it is paid on delivery: hide the "Gratis" the
// cart and checkout blocks print for it; its description says how it's paid.
add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! function_exists( 'is_checkout' ) || ! ( is_checkout() || is_cart() ) ) {
			return;
		}
		wp_register_style( 'cinnamon-agencia', false, array(), CINNAMON_TIENDA_VERSION );
		wp_enqueue_style( 'cinnamon-agencia' );
		$rate = 'input[value^="' . CINNAMON_AGENCY_METHOD . ':"]';
		wp_add_inline_style(
			'cinnamon-agencia',
			'.wc-block-components-radio-control__option:has(' . $rate . ') .wc-block-components-radio-control__secondary-label{display:none}'
			// Totals: "Se paga al recibir" instead of "Gratis" while this rate is chosen.
			. 'body:has(' . $rate . ':checked) .wc-block-components-totals-item:has(.wc-block-components-totals-shipping__via) .wc-block-components-totals-item__value{font-size:0}'
			. 'body:has(' . $rate . ':checked) .wc-block-components-totals-item:has(.wc-block-components-totals-shipping__via) .wc-block-components-totals-item__value::after{content:"Se paga al recibir";font-size:.875rem;font-weight:400;text-transform:none}'
		);
	}
);

add_action(
	'woocommerce_init',
	function () {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		// Selected rates look like "cinnamon_agencia:12".
		$chosen = array(
			'type'       => 'object',
			'properties' => array(
				'cart' => array(
					'properties' => array(
						'shipping_rates' => array( 'contains' => array( 'pattern' => '^' . CINNAMON_AGENCY_METHOD . ':' ) ),
					),
				),
			),
		);
		$not_chosen = array(
			'type'       => 'object',
			'properties' => array(
				'cart' => array(
					'properties' => array(
						'shipping_rates' => array( 'not' => array( 'contains' => array( 'pattern' => '^' . CINNAMON_AGENCY_METHOD . ':' ) ) ),
					),
				),
			),
		);
		woocommerce_register_additional_checkout_field(
			array(
				'id'                => CINNAMON_AGENCY_FIELD,
				'label'             => 'Nombre de la agencia',
				'location'          => 'order',
				'type'              => 'text',
				'required'          => $chosen,
				'hidden'            => $not_chosen,
				'attributes'        => array( 'autocomplete' => 'off' ),
				'sanitize_callback' => fn( $value ) => sanitize_text_field( $value ),
			)
		);
	}
);
