<?php
/**
 * Setup steps. Each one can run again safely: it updates what already exists.
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

/**
 * Runs the given steps in a fixed order and returns a report.
 *
 * @param string[] $steps Step keys.
 * @return string[]
 */
function cinnamon_tienda_run( array $steps ) {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return array( 'WooCommerce no está activo. Instalalo y activalo antes de configurar la tienda.' );
	}
	$report = array();
	$done   = (array) get_option( 'cinnamon_tienda_done', array() );
	foreach ( array_keys( cinnamon_tienda_steps() ) as $step ) {
		if ( ! in_array( $step, $steps, true ) ) {
			continue;
		}
		$fn = 'cinnamon_tienda_step_' . $step;
		try {
			$report = array_merge( $report, (array) $fn() );
			$done[ $step ] = time();
		} catch ( Throwable $e ) {
			$report[] = sprintf( 'Error en "%s": %s', $step, $e->getMessage() );
		}
	}
	update_option( 'cinnamon_tienda_done', $done, false );
	return $report;
}

/**
 * Site language es_AR plus WordPress, WooCommerce and theme translations.
 * WooCommerce ships no es_UY translation; es_AR is rioplatense Spanish too.
 *
 * @return string[]
 */
function cinnamon_tienda_step_idioma() {
	require_once ABSPATH . 'wp-admin/includes/translation-install.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';

	$locale = 'es_AR';
	if ( ! wp_download_language_pack( $locale ) ) {
		return array( 'Idioma: no se pudo descargar Español (Argentina). Elegilo a mano en Ajustes > Generales > Idioma del sitio y después andá a Escritorio > Actualizaciones > Actualizar traducciones.' );
	}
	update_option( 'WPLANG', $locale );
	switch_to_locale( $locale );

	// Ask wordpress.org which plugin and theme translations exist for the new locale.
	delete_site_transient( 'update_plugins' );
	delete_site_transient( 'update_themes' );
	wp_update_plugins();
	wp_update_themes();
	$updates = wp_get_translation_updates();
	$count   = 0;
	if ( $updates ) {
		$upgrader = new Language_Pack_Upgrader( new Automatic_Upgrader_Skin() );
		$results  = $upgrader->bulk_upgrade( $updates );
		$count    = count( array_filter( (array) $results, fn( $r ) => true === $r || ( is_array( $r ) && ! is_wp_error( $r ) ) ) );
	}
	return array( sprintf( 'Idioma: Español (Argentina), con %d traducciones de plugins y temas instaladas.', $count ) );
}

/**
 * Store settings, timezone and permalinks.
 *
 * @return string[]
 */
function cinnamon_tienda_step_ajustes() {
	$options = array(
		'blogname'                               => 'Cinnamon',
		'blogdescription'                        => 'Boutique Gourmet',
		'timezone_string'                        => 'America/Montevideo',
		'date_format'                            => 'd/m/Y',
		'time_format'                            => 'H:i',
		'start_of_week'                          => 1,
		'woocommerce_currency'                   => 'UYU',
		'woocommerce_currency_pos'               => 'left',
		'woocommerce_price_thousand_sep'         => '.',
		'woocommerce_price_decimal_sep'          => ',',
		'woocommerce_price_num_decimals'         => 2,
		'woocommerce_default_country'            => 'UY:UY-MO',
		'woocommerce_store_address'              => 'Dr. Pablo de María 1441',
		'woocommerce_store_city'                 => 'Montevideo',
		'woocommerce_allowed_countries'          => 'specific',
		'woocommerce_specific_allowed_countries' => array( 'UY' ),
		'woocommerce_ship_to_countries'          => '',
		'woocommerce_calc_taxes'                 => 'no',
		'woocommerce_prices_include_tax'         => 'yes',
		'woocommerce_weight_unit'                => 'kg',
		'woocommerce_dimension_unit'             => 'cm',
		'woocommerce_enable_guest_checkout'      => 'yes',
		'woocommerce_checkout_phone_field'       => 'required',
		'woocommerce_enable_reviews'             => 'no',
		'woocommerce_email_from_name'            => 'Cinnamon Boutique Gourmet',
		'woocommerce_email_from_address'         => 'info@cinnamon.uy',
	);
	foreach ( $options as $name => $value ) {
		update_option( $name, $value );
	}

	update_option( 'permalink_structure', '/%postname%/' );
	update_option(
		'woocommerce_permalinks',
		array(
			'product_base'           => 'producto',
			'category_base'          => 'categoria',
			'tag_base'               => 'etiqueta',
			'attribute_base'         => '',
			'use_verbose_page_rules' => false,
		)
	);
	// Rewrite rules are rebuilt on the next request with the new bases.
	delete_option( 'rewrite_rules' );

	return array( 'Ajustes: moneda UYU ($), Uruguay, Montevideo, sin impuestos aparte, enlaces /producto/ y /categoria/.' );
}

/**
 * Product category tree.
 *
 * @return string[]
 */
function cinnamon_tienda_step_categorias() {
	$count = 0;
	$order = 0;
	foreach ( cinnamon_tienda_categories() as $parent_name => $children ) {
		$parent_id = cinnamon_tienda_ensure_term( $parent_name, 0, ++$order );
		++$count;
		$child_order = 0;
		foreach ( $children as $child_name ) {
			cinnamon_tienda_ensure_term( $child_name, $parent_id, ++$child_order );
			++$count;
		}
	}
	return array( sprintf( 'Categorías: %d listas (principales y subcategorías).', $count ) );
}

/**
 * Finds or creates a product category under a parent.
 *
 * @param string $name      Name.
 * @param int    $parent_id Parent term ID.
 * @param int    $order     Menu order.
 * @return int Term ID.
 */
function cinnamon_tienda_ensure_term( $name, $parent_id, $order ) {
	$existing = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'name'       => $name,
			'parent'     => $parent_id,
			'hide_empty' => false,
			'fields'     => 'ids',
		)
	);
	if ( $existing ) {
		$term_id = (int) $existing[0];
	} else {
		$slug = sanitize_title( $name );
		$used = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $used && (int) $used->parent !== (int) $parent_id && $parent_id ) {
			// Same name under another parent ("Galletas y Panificados"): suffix the parent.
			$slug .= '-' . get_term( $parent_id, 'product_cat' )->slug;
		}
		$term = wp_insert_term( $name, 'product_cat', array( 'parent' => $parent_id, 'slug' => $slug ) );
		if ( is_wp_error( $term ) ) {
			throw new RuntimeException( $name . ': ' . $term->get_error_message() );
		}
		$term_id = (int) $term['term_id'];
	}
	update_term_meta( $term_id, 'order', $order );
	return $term_id;
}

/**
 * Category ID from a name path like "Sin Gluten > Galletas y Panificados".
 *
 * @param string $path Path.
 * @return int
 */
function cinnamon_tienda_term_from_path( $path ) {
	$parent = 0;
	foreach ( array_map( 'trim', explode( '>', $path ) ) as $name ) {
		$ids = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'name'       => $name,
				'parent'     => $parent,
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);
		if ( ! $ids ) {
			return 0;
		}
		$parent = (int) $ids[0];
	}
	return $parent;
}

/**
 * Pages, front page and WooCommerce page names.
 *
 * @return string[]
 */
function cinnamon_tienda_step_paginas() {
	$report = array();
	foreach ( cinnamon_tienda_pages() as $slug => $page ) {
		$existing = get_page_by_path( $slug );
		$data     = array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $page['title'],
			'post_name'    => $slug,
			'post_content' => $page['content'],
		);
		if ( $existing ) {
			$data['ID'] = $existing->ID;
			$id         = wp_update_post( wp_slash( $data ), true );
		} else {
			$id = wp_insert_post( wp_slash( $data ), true );
		}
		if ( is_wp_error( $id ) ) {
			$report[] = 'Página ' . $page['title'] . ': ' . $id->get_error_message();
			continue;
		}
		update_post_meta( $id, '_wp_page_template', $page['template'] ?? '' );
		$ids[ $slug ] = $id;
	}

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['inicio'] ?? 0 );
	update_option( 'wp_page_for_privacy_policy', $ids['politica-de-privacidad'] ?? 0 );

	// WooCommerce pages, in Spanish.
	if ( ! wc_get_page_id( 'shop' ) || wc_get_page_id( 'shop' ) < 1 ) {
		WC_Install::create_pages();
	}
	$woo = array(
		'shop'      => array( 'Tienda', 'tienda' ),
		'cart'      => array( 'Carrito', 'carrito' ),
		'checkout'  => array( 'Finalizar compra', 'finalizar-compra' ),
		'myaccount' => array( 'Mi cuenta', 'mi-cuenta' ),
	);
	foreach ( $woo as $key => list( $title, $slug ) ) {
		$id = wc_get_page_id( $key );
		if ( $id > 0 ) {
			wp_update_post( array( 'ID' => $id, 'post_title' => $title, 'post_name' => $slug ) );
		}
	}

	$report[] = sprintf( 'Páginas: %d creadas o actualizadas. Inicio es la portada; Tienda, Carrito, Finalizar compra y Mi cuenta quedaron en español.', count( $ids ?? array() ) );
	return $report;
}

/**
 * Shipping zones, as described on cinnamon.uy/envios-a-domicilio.
 *
 * @return string[]
 */
function cinnamon_tienda_step_envios() {
	$dash  = array( 'Envío a domicilio (Dash Pack)', 190, 2500 );
	$nave  = array( 'Envío al interior (La Nave Cargo Postal)', 325, 5000 );
	$costa = array( 'Ciudad de la Costa (Dash Pack)', 190, 2500 );

	$zones = array(
		array(
			'name'      => 'Montevideo',
			'locations' => array( array( 'code' => 'UY:UY-MO', 'type' => 'state' ) ),
			'rates'     => array( $dash ),
		),
		array(
			'name'      => 'Canelones',
			'locations' => array( array( 'code' => 'UY:UY-CA', 'type' => 'state' ) ),
			'agencia'   => true,
			'rates'     => array(
				$costa,
				array( 'Pando, Barros Blancos, Empalme Olmos y Costa de Oro (DePunta)', 240, 3500 ),
				$nave,
			),
		),
		array(
			'name'      => 'Maldonado',
			'locations' => array( array( 'code' => 'UY:UY-MA', 'type' => 'state' ) ),
			'agencia'   => true,
			'rates'     => array(
				array( 'Costa de Maldonado (DePunta)', 240, 3500 ),
				$nave,
			),
		),
		array(
			'name'      => 'Interior del país',
			'locations' => array( array( 'code' => 'UY', 'type' => 'country' ) ),
			'agencia'   => true,
			'rates'     => array( $nave ),
		),
	);

	// Recreate the zones so the run can repeat without duplicates.
	$names = wp_list_pluck( $zones, 'name' );
	foreach ( WC_Shipping_Zones::get_zones() as $zone ) {
		if ( in_array( $zone['zone_name'], $names, true ) ) {
			( new WC_Shipping_Zone( $zone['id'] ) )->delete();
		}
	}

	$thresholds = array();
	$bar        = array();
	$depunta    = array();
	$lanave     = array();
	foreach ( $zones as $order => $def ) {
		$zone = new WC_Shipping_Zone();
		$zone->set_zone_name( $def['name'] );
		$zone->set_zone_order( $order );
		$zone->set_locations( $def['locations'] );
		$zone->save();
		foreach ( $def['rates'] as list( $title, $cost, $free_from ) ) {
			$instance_id = $zone->add_shipping_method( 'flat_rate' );
			$method      = WC_Shipping_Zones::get_shipping_method( $instance_id );
			update_option(
				$method->get_instance_option_key(),
				array(
					'title'      => $title,
					'tax_status' => 'none',
					'cost'       => (string) $cost,
				)
			);
			$thresholds[ $instance_id ] = $free_from;
			// The only home delivery for Ciudad de la Costa addresses (includes/agencia.php).
			if ( $costa[0] === $title ) {
				update_option( 'cinnamon_costa_rate', $instance_id );
			}
			// DePunta rates only show inside its coverage (includes/depunta.php).
			if ( false !== strpos( $title, '(DePunta)' ) ) {
				$depunta[] = $instance_id;
			}
			// DePunta and La Nave charge by weight (includes/peso.php).
			if ( $nave[0] === $title ) {
				$lanave[] = $instance_id;
			}
			// Dash Pack rates get the free shipping bar in the checkout (includes/envio-gratis.php).
			if ( in_array( $title, array( $dash[0], $costa[0] ), true ) ) {
				$bar[] = $instance_id;
			}
		}
		// Customer-chosen agency, paid on delivery (includes/agencia.php).
		if ( ! empty( $def['agencia'] ) ) {
			$zone->add_shipping_method( CINNAMON_AGENCY_METHOD );
		}
	}
	update_option( 'cinnamon_free_shipping_from', $thresholds );
	update_option( 'cinnamon_free_shipping_bar', $bar );
	update_option( 'cinnamon_depunta_rates', $depunta );
	update_option( 'cinnamon_lanave_rates', $lanave );

	// Pickup at the shop, shown at checkout as "Retiro en el local".
	update_option(
		'woocommerce_pickup_location_settings',
		array(
			'enabled'    => 'yes',
			'title'      => 'Retiro en el local',
			'tax_status' => 'none',
			'cost'       => '',
		)
	);
	update_option(
		'pickup_location_pickup_locations',
		array(
			array(
				'name'    => 'Cinnamon, Dr. Pablo de María 1441',
				'address' => array(
					'address_1' => 'Dr. Pablo de María 1441',
					'city'      => 'Montevideo',
					'state'     => 'UY-MO',
					'postcode'  => '',
					'country'   => 'UY',
				),
				'details' => 'Lunes a viernes de 10:00 a 19:00. Pedidos hechos antes de las 15:00 se retiran desde el próximo día hábil; después de las 15:00, desde el próximo día hábil a partir de las 15:00.',
				'enabled' => true,
			),
		)
	);

	return array( 'Envíos: 4 zonas (Montevideo, Canelones, Maldonado, Interior) con Dash Pack, DePunta, La Nave y agencia a elección, envío gratis por monto y retiro sin costo en el local.' );
}

/**
 * Payment methods.
 *
 * @return string[]
 */
function cinnamon_tienda_step_pagos() {
	$bacs = (array) get_option( 'woocommerce_bacs_settings', array() );
	update_option(
		'woocommerce_bacs_settings',
		array_merge(
			$bacs,
			array(
				'enabled'      => 'yes',
				'title'        => 'Transferencia bancaria',
				'description'  => 'Hacé la transferencia con los datos de la cuenta que te mostramos al confirmar el pedido. Usá el número de pedido como referencia.',
				'instructions' => 'Preparamos tu pedido cuando se acredita la transferencia. Si tenés dudas, escribinos al WhatsApp 096 181 666.',
			)
		)
	);
	foreach ( array( 'cheque', 'cod' ) as $gateway ) {
		$settings            = (array) get_option( "woocommerce_{$gateway}_settings", array() );
		$settings['enabled'] = 'no';
		update_option( "woocommerce_{$gateway}_settings", $settings );
	}
	$has_accounts = (bool) array_filter( (array) get_option( 'woocommerce_bacs_accounts', array() ) );
	return array(
		'Pagos: transferencia bancaria activa.' . ( $has_accounts ? '' : ' Falta cargar la cuenta en WooCommerce > Ajustes > Pagos > Transferencia bancaria.' ),
	);
}

/**
 * Installs and activates the official Mercado Pago plugin from wordpress.org.
 * Credentials are entered afterwards in its own screen, which validates them.
 *
 * @return string[]
 */
function cinnamon_tienda_step_mercadopago() {
	$slug = 'woocommerce-mercadopago';
	$file = $slug . '/woocommerce-mercadopago.php';

	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	if ( ! file_exists( WP_PLUGIN_DIR . '/' . $file ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$api = plugins_api( 'plugin_information', array( 'slug' => $slug, 'fields' => array( 'sections' => false ) ) );
		if ( is_wp_error( $api ) ) {
			return array( 'Mercado Pago: no se pudo consultar wordpress.org (' . $api->get_error_message() . '). Instalalo a mano desde Plugins > Añadir nuevo.' );
		}
		$result = ( new Plugin_Upgrader( new Automatic_Upgrader_Skin() ) )->install( $api->download_link );
		if ( true !== $result ) {
			return array( 'Mercado Pago: no se pudo instalar. Instalalo a mano desde Plugins > Añadir nuevo, buscando "Mercado Pago payments for WooCommerce".' );
		}
	}
	if ( ! is_plugin_active( $file ) ) {
		$activated = activate_plugin( $file );
		if ( is_wp_error( $activated ) ) {
			return array( 'Mercado Pago: instalado pero no se pudo activar (' . $activated->get_error_message() . ').' );
		}
	}
	return array( 'Mercado Pago: plugin oficial instalado y activo. Falta cargar las credenciales en WooCommerce > Mercado Pago.' );
}

/**
 * Sample products with images bundled in the plugin.
 *
 * @return string[]
 */
function cinnamon_tienda_step_productos() {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$created = 0;
	$updated = 0;
	foreach ( cinnamon_tienda_sample_products() as $menu_order => $def ) {
		$id      = wc_get_product_id_by_sku( $def['sku'] );
		$product = $id ? wc_get_product( $id ) : ( isset( $def['variations'] ) ? new WC_Product_Variable() : new WC_Product_Simple() );
		$id ? ++$updated : ++$created;

		$product->set_name( $def['name'] );
		$product->set_sku( $def['sku'] );
		$product->set_status( 'publish' );
		$product->set_featured( true );
		$product->set_menu_order( $menu_order );
		$product->set_short_description( $def['short'] );
		$product->set_description( $def['description'] ?? '' );
		$product->set_category_ids( array_filter( array( cinnamon_tienda_term_from_path( $def['category'] ) ) ) );
		// Import the photo. Replace it when the bundled file changed, but only if the
		// current photo is one this plugin imported: a photo the shop uploaded stays.
		$source   = CINNAMON_TIENDA_DIR . 'assets/productos/' . $def['image'];
		$hash     = file_exists( $source ) ? md5_file( $source ) : '';
		$old_id   = $product->get_image_id();
		$old_hash = $old_id ? get_post_meta( $old_id, '_cinnamon_source_md5', true ) : '';
		$ours     = $old_id && (
			$old_hash
			|| get_post_meta( $old_id, '_cinnamon_imported', true )
			// Imported by plugin 1.0, before the marker existed: same file name.
			|| 0 === strpos( basename( (string) get_attached_file( $old_id ) ), pathinfo( $def['image'], PATHINFO_FILENAME ) )
		);
		if ( $hash && ( ! $old_id || ( $ours && $old_hash !== $hash ) ) ) {
			$new_id = cinnamon_tienda_import_image( $def['image'], $def['name'] );
			if ( $new_id ) {
				update_post_meta( $new_id, '_cinnamon_source_md5', $hash );
				$product->set_image_id( $new_id );
				if ( $ours ) {
					wp_delete_attachment( $old_id, true );
				}
			}
		}

		if ( isset( $def['price'] ) ) {
			$product->set_regular_price( (string) $def['price'] );
			$product->save();
			continue;
		}

		$labels    = array_column( $def['variations'], 0 );
		$attribute = new WC_Product_Attribute();
		$attribute->set_name( 'Peso' );
		$attribute->set_options( $labels );
		$attribute->set_visible( true );
		$attribute->set_variation( true );
		$product->set_attributes( array( $attribute ) );
		$product->set_default_attributes( array( 'peso' => $labels[0] ) );
		$product_id = $product->save();

		$existing = array();
		foreach ( $product->get_children() as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child ) {
				$existing[ $child->get_attribute( 'peso' ) ] = $child;
			}
		}
		foreach ( $def['variations'] as $position => list( $label, $regular, $sale ) ) {
			$variation = $existing[ $label ] ?? new WC_Product_Variation();
			$variation->set_parent_id( $product_id );
			$variation->set_attributes( array( 'peso' => $label ) );
			$variation->set_regular_price( (string) $regular );
			$variation->set_sale_price( null === $sale ? '' : (string) $sale );
			$variation->set_menu_order( $position );
			$variation->set_status( 'publish' );
			$variation->save();
		}
		WC_Product_Variable::sync( $product_id );
	}
	$indexed = cinnamon_tienda_index_all_products();
	return array( sprintf( 'Productos: %d creados y %d actualizados, marcados como destacados para la portada. Búsqueda sin tildes preparada para %d productos.', $created, $updated, $indexed ) );
}

/**
 * Copies a bundled image into the media library.
 *
 * @param string $file  File name in assets/productos.
 * @param string $title Image title / alt text.
 * @return int Attachment ID, or 0.
 */
function cinnamon_tienda_import_image( $file, $title ) {
	$source = CINNAMON_TIENDA_DIR . 'assets/productos/' . $file;
	if ( ! file_exists( $source ) ) {
		return 0;
	}
	$tmp = wp_tempnam( $file );
	copy( $source, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0, $title );
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return 0;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $title );
	update_post_meta( $id, '_cinnamon_imported', 1 );
	return (int) $id;
}

/**
 * Removes WordPress sample content.
 *
 * @return string[]
 */
function cinnamon_tienda_step_limpiar() {
	$removed = 0;
	foreach ( array( 'hello-world', 'hola-mundo' ) as $slug ) {
		$post = get_page_by_path( $slug, OBJECT, 'post' );
		if ( $post && wp_delete_post( $post->ID, true ) ) {
			++$removed;
		}
	}
	foreach ( array( 'sample-page', 'pagina-ejemplo' ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page && wp_delete_post( $page->ID, true ) ) {
			++$removed;
		}
	}
	return array( sprintf( 'Contenido de ejemplo: %d elementos borrados.', $removed ) );
}
