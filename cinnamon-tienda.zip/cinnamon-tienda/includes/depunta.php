<?php
/**
 * DePunta only inside its coverage: its rates (Canelones and Maldonado, saved
 * by the setup in cinnamon_depunta_rates) show only when the city the
 * customer typed is one of DePunta's localities. Never in Montevideo or
 * Ciudad de la Costa, which have Dash Pack (includes/agencia.php).
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

/**
 * DePunta's localities, from https://www.depunta.com/zonas-cobertura
 * (2026-10-29), without the " - Canelones" suffix and without Montevideo,
 * the city of Canelones (not covered, per Cinnamon) and an internal code.
 * Ciudad de la Costa's neighbourhoods are listed by DePunta but never get
 * its rates: those addresses only get Dash Pack. The Carrasco and La Tahona
 * places Cinnamon serves with Dash Pack (Zona América, Lomas de Carrasco…)
 * were taken out on 2026-10-29 and live in cinnamon_tienda_costa_cities().
 *
 * @return string[]
 */
function cinnamon_tienda_depunta_cities() {
	return apply_filters(
		'cinnamon_tienda_depunta_cities',
		array(
			'Abra De Perdomo', 'Altos De La Laguna',
			'Araminda', 'Arenas De Jose Ignacio', 'Argentino', 'Atlántida', 'Balneario Argentino',
			'Balneario Buenos Aires', 'Balneario Solis', 'Barra Carrasco', 'Barra Del Sauce', 'Barra De Portezuelo',
			'Barros Blancos', 'Bella Vista', 'Bello Horizonte', 'Biarritz', 'Brazo Oriental', 'Buenos Aires',
			'Canteras De Marelli', 'Carmel', 'Cerro Pelado', 'Cerros Azules', 'Chihuahua', 'City Golf',
			'Ciudad De La Costa', 'Colonia Nicolich', 'Costa Azul',
			'Costas De Jose Ignacio', 'Cuchilla Alta', 'Eden Rock', 'El Bosque',
			'El Bosque De Solymar', 'El Chorro', 'El Pinar', 'El Quijote', 'El Tesoro', 'Empalme Nicolich',
			'Empalme Olmos', 'Estación Atlántida', 'Estación La Floresta', 'Faro Jose Ignacio',
			'Faro Jose Ignacio Norte', 'Fortín de Santa Rosa', 'Gerona', 'Gregorio Aznarez', 'Guardia Vieja',
			'Guazuvira Nuevo', 'Guazú Virá', 'Haras Del Lago', 'Jaureguiberry', 'Jose Ignacio', 'La Barra',
			'La Capuera', 'La Chinchilla', 'La Falda', 'La Floresta', 'Lago Jardin Del Bosque', 'Lagomar',
			'Laguna Blanca', 'Laguna Del Sauce', 'La Juanita', 'La Montañesa', 'Las Cumbres', 'Las Flores',
			'Las Flores - Estacion', 'La Sonrisa', 'Las Toscas', 'Las Vegas', 'La Tuna',
			'Los Corchos', 'Los Talas', 'Los Titanes', 'Maldonado',
			'Manantiales', 'Marindia', 'Montes De Solymar', 'Médanos de Solymar',
			'Neptunia', 'Nueva Carrara', 'Ocean Park', 'Pajas Blancas', 'Pan de Azucar', 'Pando',
			'Parque Carrasco', 'Parque del Plata', 'Parque De Solymar', 'Parque Miramar', 'Paso Carrasco',
			'Paso De Las Toscas', 'Pinamar', 'Pinar', 'Pinares - Las Delicias', 'Pinares De Solymar', 'Pine Park',
			'Piriapolis', 'Playa Grande', 'Playa Hermosa', 'Playa Verde', 'Portezuelo', 'Pueblo Solis',
			'Punta Ballena', 'Punta Colorada', 'Punta Del Este', 'Punta Fria', 'Punta Negra',
			'Puntas De Pan de Azucar', 'Rincon Del Indio', 'Rincón del Pinar', 'Ruta 5', 'Ruta 37 Y 9', 'Salinas',
			'San Carlos', 'San Francisco', 'San José de Carrasco', 'San Juan Del Este', 'San Luis',
			'San Rafael El Placer', 'Santa Ana', 'Santa Lucía del Este', 'Santa Monica', 'San Vicente',
			'Sauce De Portezuelo', 'Shangrilá', 'Solanas', 'Solis', 'Solymar',
			'Villa Argentina', 'Villa Delia',
		)
	);
}

/**
 * Whether DePunta delivers to the city the customer typed. Accepts DePunta's
 * own "Atlántida - Canelones" form too.
 *
 * @param string $city City.
 * @return bool
 */
function cinnamon_tienda_depunta_covers( $city ) {
	$city = preg_replace( '/\s*-\s*canelones$/', '', cinnamon_tienda_normalize_place( $city ) );
	return '' !== $city && in_array( $city, array_map( 'cinnamon_tienda_normalize_place', cinnamon_tienda_depunta_cities() ), true );
}

/**
 * Removes the DePunta rates outside its coverage, and always in Ciudad de la
 * Costa. Without the setup's list of DePunta rates, nothing changes.
 *
 * @param array<string,WC_Shipping_Rate> $rates   Rates.
 * @param array                          $package Package.
 * @return array
 */
function cinnamon_tienda_depunta_rates( $rates, $package ) {
	$ids = array_map( 'intval', (array) get_option( 'cinnamon_depunta_rates', array() ) );
	if ( ! $ids ) {
		return $rates;
	}
	$dest = $package['destination'] ?? array();
	if ( cinnamon_tienda_depunta_covers( $dest['city'] ?? '' ) && ! cinnamon_tienda_is_costa( $dest ) ) {
		return $rates;
	}
	return array_filter( $rates, fn( $rate ) => ! in_array( (int) $rate->get_instance_id(), $ids, true ) );
}
add_filter( 'woocommerce_package_rates', 'cinnamon_tienda_depunta_rates', 30, 2 );
