<?php
/**
 * Free shipping bar in the checkout order summary: how much is left for free
 * Dash Pack delivery, "+1" buttons for the products already in the cart, and
 * a notice once the order qualifies. Only for the Dash Pack rates the setup
 * saved (cinnamon_free_shipping_bar); the minimum is the same one the free
 * shipping rule uses (cinnamon_free_shipping_from).
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
			return;
		}
		$thresholds = (array) get_option( 'cinnamon_free_shipping_from', array() );
		$minimums   = array();
		foreach ( (array) get_option( 'cinnamon_free_shipping_bar', array() ) as $instance_id ) {
			if ( isset( $thresholds[ $instance_id ] ) ) {
				$minimums[ (int) $instance_id ] = (float) $thresholds[ $instance_id ];
			}
		}
		if ( ! $minimums ) {
			return;
		}
		$base = plugin_dir_url( CINNAMON_TIENDA_DIR . 'cinnamon-tienda.php' ) . 'assets/envio-gratis/';
		wp_enqueue_style( 'cinnamon-envio-gratis', $base . 'envio-gratis.css', array(), CINNAMON_TIENDA_VERSION );
		wp_enqueue_script( 'cinnamon-envio-gratis', $base . 'envio-gratis.js', array( 'wc-blocks-checkout', 'wp-plugins', 'wp-element', 'wp-data' ), CINNAMON_TIENDA_VERSION, true );
		wp_localize_script(
			'cinnamon-envio-gratis',
			'cinnamonEnvioGratis',
			array(
				'minimums' => $minimums,
				'carrier'  => 'Dash Pack',
			)
		);
	}
);
