<?php
/**
 * Monthly subscription of a single product (historia 6.9), switched on per
 * product in its "Suscripción" tab. Each subscribable presentation has a
 * fixed monthly price; the monthly amount for each way of receiving it is
 * that price plus the shipping the store would charge for it (same zones,
 * weight tables, free shipping and agency rules as the checkout, asked to
 * WooCommerce itself). Cinnamon creates one Mercado Pago plan per distinct
 * amount and pastes its link; a way of receiving whose amount has no link
 * is not offered, so a stale link never charges a wrong amount.
 *
 * Requests, mails and link checks are shared with the coffee subscription
 * (includes/suscripcion.php).
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

/**
 * Subscription settings of a product: enabled flag and, per presentation
 * (variation ID, or the product ID for a simple product), price and links by amount.
 *
 * @param int $product_id Product.
 * @return array{enabled:bool,items:array<int,array{price:float,links:array<string,string>}>}
 */
function cinnamon_psub_settings( $product_id ) {
	$items = get_post_meta( $product_id, '_cin_sub_items', true );
	return array(
		'enabled' => 'yes' === get_post_meta( $product_id, '_cin_sub_enabled', true ),
		'items'   => is_array( $items ) ? $items : array(),
	);
}

/**
 * Presentations of a product: ID => label ("1 kg"), or the product itself if simple.
 *
 * @param WC_Product $product Product.
 * @return array<int,string>
 */
function cinnamon_psub_presentations( $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return array( $product->get_id() => $product->get_name() );
	}
	$out = array();
	foreach ( $product->get_children() as $id ) {
		$variation = wc_get_product( $id );
		if ( $variation ) {
			$out[ $id ] = implode( ' · ', array_filter( $variation->get_variation_attributes( false ) ) );
		}
	}
	return $out;
}

/**
 * Amount key used to store links: whole pesos, "1090".
 *
 * @param float $amount Amount.
 * @return string
 */
function cinnamon_psub_key( $amount ) {
	return (string) (int) round( (float) $amount );
}

/**
 * Ways to receive a presentation at an address, with the monthly amount.
 * Asks WooCommerce for the rates of a one-item package priced at the
 * subscription price, so every shipping rule of the store applies.
 *
 * @param WC_Product $item  Variation or simple product.
 * @param float      $price Monthly subscription price.
 * @param string     $state State code (UY-MO…).
 * @param string     $city  City.
 * @return array<string,array{label:string,shipping:float,amount:float,note:string}> Keyed by kind.
 */
function cinnamon_psub_options( $item, $price, $state, $city ) {
	$package = array(
		'contents'        => array(
			'cinnamon-sub' => array(
				'key'               => 'cinnamon-sub',
				'product_id'        => $item->get_parent_id() ? $item->get_parent_id() : $item->get_id(),
				'variation_id'      => $item->get_parent_id() ? $item->get_id() : 0,
				'quantity'          => 1,
				'data'              => $item,
				'line_total'        => (float) $price,
				'line_tax'          => 0,
				'line_subtotal'     => (float) $price,
				'line_subtotal_tax' => 0,
			),
		),
		'contents_cost'   => (float) $price,
		'applied_coupons' => array(),
		'user'            => array( 'ID' => 0 ),
		'destination'     => array(
			'country'   => 'UY',
			'state'     => $state,
			'postcode'  => '',
			'city'      => $city,
			'address'   => '',
			'address_1' => '',
			'address_2' => '',
		),
		'cart_subtotal'   => (float) $price,
	);
	$bar     = array_map( 'intval', (array) get_option( 'cinnamon_free_shipping_bar', array() ) );
	$depunta = array_map( 'intval', (array) get_option( 'cinnamon_depunta_rates', array() ) );
	$lanave  = array_map( 'intval', (array) get_option( 'cinnamon_lanave_rates', array() ) );
	$labels  = array(
		'dashpack' => 'Envío a domicilio (Dash Pack)',
		'depunta'  => 'DePunta',
		'lanave'   => 'La Nave Cargo Postal',
		'agencia'  => 'Agencia a elección de Tres Cruces',
	);
	// Same steps as WC_Shipping::calculate_shipping_for_package(), without its
	// session cache (there is no customer session in wp-admin).
	$rates = array();
	foreach ( WC()->shipping()->load_shipping_methods( $package ) as $method ) {
		if ( ! $method->supports( 'shipping-zones' ) || $method->get_instance_id() ) {
			$rates += $method->get_rates_for_package( $package );
		}
	}
	$rates = apply_filters( 'woocommerce_package_rates', $rates, $package );
	$out   = array();
	foreach ( $rates as $rate ) {
		$instance = (int) $rate->get_instance_id();
		if ( CINNAMON_AGENCY_METHOD === $rate->get_method_id() ) {
			$kind = 'agencia';
		} elseif ( in_array( $instance, $bar, true ) ) {
			$kind = 'dashpack';
		} elseif ( in_array( $instance, $depunta, true ) ) {
			$kind = 'depunta';
		} elseif ( in_array( $instance, $lanave, true ) ) {
			$kind = 'lanave';
		} else {
			continue; // Pickup is added below; any other rate is not part of subscriptions.
		}
		$shipping     = 'agencia' === $kind ? 0.0 : (float) $rate->get_cost();
		$out[ $kind ] = array(
			'label'    => $labels[ $kind ],
			'shipping' => $shipping,
			'amount'   => (float) $price + $shipping,
			'note'     => 'agencia' === $kind ? 'el envío lo pagás al recibir' : ( $shipping > 0 ? 'incluye ' . cinnamon_sub_money( $shipping ) . ' de envío' : 'envío sin cargo' ),
		);
	}
	$out['retiro'] = array(
		'label'    => 'Retiro en el local',
		'shipping' => 0.0,
		'amount'   => (float) $price,
		'note'     => 'Dr. Pablo de María 1441',
	);
	return $out;
}

/**
 * Amounts Cinnamon has to create in Mercado Pago for a presentation: every
 * way of receiving it, over sample addresses of each zone.
 *
 * @param WC_Product $item  Variation or simple product.
 * @param float      $price Monthly price.
 * @return array<string,string[]> Amount key => ways of receiving ("Dash Pack", …).
 */
function cinnamon_psub_amounts( $item, $price ) {
	$places  = array( array( 'UY-MO', 'Montevideo' ), array( 'UY-CA', 'Solymar' ), array( 'UY-CA', 'Atlántida' ), array( 'UY-MA', 'Piriápolis' ), array( 'UY-PA', 'Paysandú' ) );
	$amounts = array();
	foreach ( $places as list( $state, $city ) ) {
		foreach ( cinnamon_psub_options( $item, $price, $state, $city ) as $option ) {
			$amounts[ cinnamon_psub_key( $option['amount'] ) ][ $option['label'] ] = $option['label'];
		}
	}
	ksort( $amounts, SORT_NUMERIC );
	return array_map( 'array_values', $amounts );
}

/*
 * Product edit screen: "Suscripción" tab.
 */
add_filter(
	'woocommerce_product_data_tabs',
	function ( $tabs ) {
		$tabs['cinnamon_sub'] = array(
			'label'    => 'Suscripción',
			'target'   => 'cinnamon_sub_data',
			'class'    => array(),
			'priority' => 75,
		);
		return $tabs;
	}
);

add_action(
	'woocommerce_product_data_panels',
	function () {
		global $post;
		$product = wc_get_product( $post->ID );
		if ( ! $product ) {
			return;
		}
		$settings = cinnamon_psub_settings( $post->ID );
		wp_nonce_field( 'cinnamon_psub', 'cinnamon_psub_nonce' );
		?>
		<div id="cinnamon_sub_data" class="panel woocommerce_options_panel" style="padding:0 12px 12px">
			<p class="form-field">
				<label for="cinnamon_sub_enabled">Suscripción mensual</label>
				<input type="checkbox" id="cinnamon_sub_enabled" name="cinnamon_sub_enabled" value="yes" <?php checked( $settings['enabled'] ); ?>>
				<span class="description">Ofrecer la suscripción en la página de este producto.</span>
			</p>
			<p>Marcá las presentaciones con suscripción y su precio por mes. Después de guardar, abajo de cada una aparecen los montos a crear en Mercado Pago (precio + envío según la forma de envío, con las tarifas actuales): creá un plan mensual por monto (Suscripciones &gt; Crear plan) y pegá su link. Una forma de envío sin link no se ofrece.</p>
			<?php foreach ( cinnamon_psub_presentations( $product ) as $id => $label ) : ?>
				<?php
				$item  = $settings['items'][ $id ] ?? array();
				$on    = isset( $settings['items'][ $id ] );
				$price = $item['price'] ?? '';
				$links = (array) ( $item['links'] ?? array() );
				$base  = 'cinnamon_sub_items[' . $id . ']';
				?>
				<div class="cin-psub" style="border-top:1px solid #eee;padding:10px 0">
					<p style="margin:0 0 6px">
						<label style="float:none;width:auto;margin:0 1em 0 0;display:inline"><input type="checkbox" style="float:none;margin:0 .3em 0 0" name="<?php echo esc_attr( $base . '[on]' ); ?>" value="1" <?php checked( $on ); ?>> <strong><?php echo esc_html( $label ); ?></strong></label>
						&nbsp; Precio por mes: $ <input type="text" style="width:7em;float:none" name="<?php echo esc_attr( $base . '[price]' ); ?>" value="<?php echo esc_attr( '' === $price ? '' : (string) (float) $price ); ?>" aria-label="<?php echo esc_attr( 'Precio por mes de ' . $label ); ?>">
					</p>
					<?php
					$variation = wc_get_product( $id );
					if ( $on && $variation && (float) $price > 0 ) :
						$amounts = cinnamon_psub_amounts( $variation, (float) $price );
						?>
						<table class="widefat striped cin-psub-amounts" style="max-width:900px">
							<thead><tr><th style="width:8em">Monto por mes</th><th>Formas de envío</th><th>Link de Mercado Pago</th></tr></thead>
							<tbody>
								<?php foreach ( $amounts as $key => $ways ) : ?>
									<tr>
										<td><strong><?php echo esc_html( cinnamon_sub_money( (float) $key ) ); ?></strong></td>
										<td><?php echo esc_html( implode( ', ', $ways ) ); ?></td>
										<td><input type="url" style="width:100%" name="<?php echo esc_attr( $base . '[links][' . $key . ']' ); ?>" value="<?php echo esc_attr( $links[ $key ] ?? '' ); ?>" aria-label="<?php echo esc_attr( 'Link para ' . cinnamon_sub_money( (float) $key ) ); ?>" placeholder="https://www.mercadopago.com.uy/subscriptions/checkout?preapproval_plan_id=…"></td>
									</tr>
								<?php endforeach; ?>
								<?php foreach ( array_diff_key( array_filter( $links ), $amounts ) as $key => $url ) : ?>
									<tr class="cin-psub-stale" style="background:#fcf0f1">
										<td><s><?php echo esc_html( cinnamon_sub_money( (float) $key ) ); ?></s></td>
										<td>Desactualizado: ninguna forma de envío cuesta este monto con las tarifas actuales. Creá el plan con el monto nuevo y borrá este link.</td>
										<td><input type="url" style="width:100%" name="<?php echo esc_attr( $base . '[links][' . $key . ']' ); ?>" value="<?php echo esc_attr( $url ); ?>"></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
);

add_action(
	'woocommerce_process_product_meta',
	function ( $product_id ) {
		if ( ! isset( $_POST['cinnamon_psub_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cinnamon_psub_nonce'] ), 'cinnamon_psub' ) ) {
			return;
		}
		update_post_meta( $product_id, '_cin_sub_enabled', empty( $_POST['cinnamon_sub_enabled'] ) ? 'no' : 'yes' );
		$items  = array();
		$errors = array();
		foreach ( (array) wp_unslash( $_POST['cinnamon_sub_items'] ?? array() ) as $id => $row ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field.
			if ( empty( $row['on'] ) ) {
				continue;
			}
			$price = (float) str_replace( ',', '.', str_replace( array( '$', ' ', '.' ), '', (string) ( $row['price'] ?? '' ) ) );
			if ( $price <= 0 ) {
				$errors[] = 'Suscripción: escribí el precio por mes de cada presentación marcada.';
				continue;
			}
			$links = array();
			foreach ( (array) ( $row['links'] ?? array() ) as $key => $url ) {
				$url = esc_url_raw( trim( (string) $url ) );
				if ( '' === $url ) {
					continue;
				}
				if ( ! cinnamon_sub_is_mp_url( $url ) ) {
					$errors[] = sprintf( 'Suscripción: el link de %s no es de Mercado Pago; no se guardó.', cinnamon_sub_money( (float) $key ) );
					continue;
				}
				$links[ cinnamon_psub_key( (float) $key ) ] = $url;
			}
			$items[ (int) $id ] = array(
				'price' => $price,
				'links' => $links,
			);
		}
		update_post_meta( $product_id, '_cin_sub_items', $items );
		if ( $errors ) {
			set_transient( 'cinnamon_psub_errors_' . get_current_user_id(), array_unique( $errors ), 60 );
		}
	}
);

add_action(
	'admin_notices',
	function () {
		$errors = get_transient( 'cinnamon_psub_errors_' . get_current_user_id() );
		if ( $errors ) {
			delete_transient( 'cinnamon_psub_errors_' . get_current_user_id() );
			foreach ( (array) $errors as $error ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
			}
		}
	}
);

/**
 * Subscribable presentations of a product with a price, only if the subscription is on.
 *
 * @param WC_Product $product Product.
 * @return array<int,array{label:string,price:float,links:array<string,string>}>
 */
function cinnamon_psub_offer( $product ) {
	$settings = cinnamon_psub_settings( $product->get_id() );
	if ( ! $settings['enabled'] ) {
		return array();
	}
	$out = array();
	foreach ( cinnamon_psub_presentations( $product ) as $id => $label ) {
		$item = $settings['items'][ $id ] ?? null;
		if ( $item && (float) $item['price'] > 0 && array_filter( (array) $item['links'] ) ) {
			$out[ $id ] = array(
				'label' => $label,
				'price' => (float) $item['price'],
				'links' => (array) $item['links'],
			);
		}
	}
	return $out;
}

/**
 * Ways of receiving offered to a customer: those whose amount has a link.
 *
 * @param WC_Product $product Product.
 * @param int        $id      Presentation.
 * @param string     $state   State code.
 * @param string     $city    City.
 * @return array<string,array> Kind => option with its link.
 */
function cinnamon_psub_offered( $product, $id, $state, $city ) {
	$offer = cinnamon_psub_offer( $product )[ $id ] ?? null;
	$item  = wc_get_product( $id );
	if ( ! $offer || ! $item ) {
		return array();
	}
	$out = array();
	foreach ( cinnamon_psub_options( $item, $offer['price'], $state, $city ) as $kind => $option ) {
		$link = $offer['links'][ cinnamon_psub_key( $option['amount'] ) ] ?? '';
		if ( $link ) {
			$out[ $kind ] = $option + array( 'link' => $link );
		}
	}
	return $out;
}

/*
 * Product page block, after the add to cart form.
 */
add_action(
	'woocommerce_single_product_summary',
	function () {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}
		$offer = cinnamon_psub_offer( $product );
		if ( ! $offer ) {
			return;
		}
		$base = plugin_dir_url( CINNAMON_TIENDA_DIR . 'cinnamon-tienda.php' ) . 'assets/suscripcion/';
		wp_enqueue_style( 'cinnamon-suscripcion', $base . 'suscripcion.css', array(), CINNAMON_TIENDA_VERSION );
		wp_enqueue_script( 'cinnamon-suscripcion-producto', $base . 'suscripcion-producto.js', array(), CINNAMON_TIENDA_VERSION, true );
		wp_localize_script(
			'cinnamon-suscripcion-producto',
			'cinnamonSuscripcionProducto',
			array(
				'ajax'    => admin_url( 'admin-ajax.php' ),
				'product' => $product->get_id(),
			)
		);
		$error  = cinnamon_sub_errors()[ sanitize_key( $_GET['sus_error'] ?? '' ) ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification -- display only.
		$typed  = isset( $_GET['sus_datos'] ) ? (array) get_transient( 'cinnamon_sub_' . sanitize_key( $_GET['sus_datos'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification -- display only.
		$v      = static fn( $key, $default = '' ) => (string) ( $typed[ $key ] ?? $default );
		$first  = (string) array_key_first( $offer );
		$states = WC()->countries ? WC()->countries->get_states( 'UY' ) : array();
		$field  = static function ( $name, $label, $type = 'text', $attrs = '' ) use ( $v ) {
			return '<p class="sub-field"><label for="psub-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><input id="psub-' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v( $name ) ) . '" ' . $attrs . '></p>';
		};
		?>
		<details class="psub" id="suscripcion"<?php echo $error ? ' open' : ''; ?>>
			<summary class="psub__summary">
				<span class="psub__title">Suscribite y recibilo todos los meses</span>
				<span class="psub__from">
					<?php
					$prices = array_column( $offer, 'price' );
					echo esc_html( ( count( $offer ) > 1 ? 'Desde ' : '' ) . cinnamon_sub_money( min( $prices ) ) . ' por mes' . ( 1 === count( $offer ) ? ' (' . reset( $offer )['label'] . ')' : '' ) . ', más el envío según tu zona' );
					?>
				</span>
			</summary>
			<form class="sub-form psub__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php if ( $error ) : ?>
					<p class="sub-error" role="alert"><?php echo esc_html( $error ); ?></p>
				<?php endif; ?>
				<?php
				$labels = array();
				foreach ( $offer as $id => $item ) {
					$labels[ $id ] = $item['label'] . ' · ' . cinnamon_sub_money( $item['price'] ) . ' por mes';
				}
				echo cinnamon_sub_radios( 'presentacion', 'Presentación', $labels, $v( 'presentacion', $first ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
				?>
				<fieldset class="sub-data"><legend>Tus datos</legend>
					<?php
					echo $field( 'nombre', 'Nombre y apellido', 'text', 'required autocomplete="name"' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
					echo $field( 'email', 'Email (el mismo que usás en Mercado Pago)', 'email', 'required autocomplete="email"' ); // phpcs:ignore WordPress.Security.EscapeOutput
					echo $field( 'telefono', 'Teléfono', 'tel', 'required autocomplete="tel"' ); // phpcs:ignore WordPress.Security.EscapeOutput
					?>
					<p class="sub-field"><label for="psub-departamento">Departamento</label>
						<select id="psub-departamento" name="departamento" required>
							<option value="">Elegí…</option>
							<?php foreach ( $states as $code => $state ) : ?>
								<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $v( 'departamento' ), $code ); ?>><?php echo esc_html( $state ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<?php
					echo $field( 'ciudad', 'Ciudad o barrio', 'text', 'required autocomplete="address-level2"' ); // phpcs:ignore WordPress.Security.EscapeOutput
					echo $field( 'direccion', 'Dirección', 'text', 'required autocomplete="street-address"' ); // phpcs:ignore WordPress.Security.EscapeOutput
					?>
				</fieldset>
				<fieldset class="sub-group psub__ways" data-group="forma">
					<legend>Cómo lo recibís</legend>
					<p class="psub__hint">Completá departamento y ciudad para ver las formas de envío y el total por mes.</p>
				</fieldset>
				<?php echo $field( 'agencia', 'Nombre de la agencia de Tres Cruces' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<p class="sub-field psub__notes"><label for="psub-notas">Notas (opcional)</label><textarea id="psub-notas" name="notas" rows="2"><?php echo esc_textarea( $v( 'notas' ) ); ?></textarea></p>
				<p class="sub-hp" aria-hidden="true"><label>No completar <input type="text" name="sitio_web" tabindex="-1" autocomplete="off"></label></p>
				<input type="hidden" name="action" value="cinnamon_suscripcion_producto">
				<input type="hidden" name="producto" value="<?php echo esc_attr( (string) $product->get_id() ); ?>">
				<input type="hidden" name="forma_elegida" value="<?php echo esc_attr( $v( 'forma' ) ); ?>">
				<?php wp_nonce_field( 'cinnamon_suscripcion_producto' ); ?>
				<p class="sub-price" aria-live="polite"></p>
				<button type="submit" class="wp-element-button sub-send">Suscribirme con Mercado Pago</button>
				<p class="sub-note">Te llevamos a Mercado Pago para cargar tu tarjeta. Se cobra automáticamente todos los meses y podés cancelar cuando quieras desde tu cuenta de Mercado Pago o avisándonos por WhatsApp. La compra común de este producto sigue igual, con el botón de arriba.</p>
			</form>
		</details>
		<?php
	},
	32
);

/*
 * Ways of receiving for an address (the product block asks while the customer types).
 */
add_action( 'wp_ajax_cinnamon_psub_options', 'cinnamon_psub_ajax' );
add_action( 'wp_ajax_nopriv_cinnamon_psub_options', 'cinnamon_psub_ajax' );

/**
 * Answers the ways of receiving, with amounts, for a presentation and address.
 */
function cinnamon_psub_ajax() {
	$product = wc_get_product( absint( $_GET['producto'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification -- public, read-only.
	$id      = absint( $_GET['presentacion'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
	$state   = sanitize_text_field( wp_unslash( $_GET['departamento'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$city    = sanitize_text_field( wp_unslash( $_GET['ciudad'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $product ) {
		wp_send_json_error();
	}
	$ways = array();
	foreach ( cinnamon_psub_offered( $product, $id, $state, $city ) as $kind => $option ) {
		$ways[] = array(
			'kind'   => $kind,
			'label'  => $option['label'],
			'amount' => cinnamon_sub_money( $option['amount'] ),
			'note'   => $option['note'],
		);
	}
	wp_send_json_success( $ways );
}

/*
 * Form handler.
 */
add_action( 'admin_post_cinnamon_suscripcion_producto', 'cinnamon_psub_submit' );
add_action( 'admin_post_nopriv_cinnamon_suscripcion_producto', 'cinnamon_psub_submit' );

/**
 * Validates, stores the request, emails and sends the customer to Mercado Pago.
 */
function cinnamon_psub_submit() {
	$product = wc_get_product( absint( $_POST['producto'] ?? 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification -- checked below.
	$back    = $product ? $product->get_permalink() : home_url( '/' );
	if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'cinnamon_suscripcion_producto' ) ) {
		wp_safe_redirect( add_query_arg( 'sus_error', 'vencido', $back ) . '#suscripcion' );
		exit;
	}
	if ( ! empty( $_POST['sitio_web'] ) ) { // Honeypot.
		wp_safe_redirect( $back );
		exit;
	}
	$in = array();
	foreach ( array( 'presentacion', 'forma', 'nombre', 'telefono', 'departamento', 'ciudad', 'direccion', 'agencia' ) as $key ) {
		$in[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );
	}
	$in['email'] = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$in['notas'] = sanitize_textarea_field( wp_unslash( $_POST['notas'] ?? '' ) );

	$states  = WC()->countries ? WC()->countries->get_states( 'UY' ) : array();
	$offer   = $product ? cinnamon_psub_offer( $product ) : array();
	$id      = (int) $in['presentacion'];
	$offered = $product ? cinnamon_psub_offered( $product, $id, $in['departamento'], $in['ciudad'] ) : array();
	$option  = $offered[ $in['forma'] ] ?? null;
	$error   = '';
	if ( '' === $in['nombre'] || ! is_email( $in['email'] ) || '' === $in['telefono'] || ! isset( $states[ $in['departamento'] ] ) || '' === $in['ciudad'] || '' === $in['direccion'] ) {
		$error = 'datos';
	} elseif ( ! isset( $offer[ $id ] ) || ! $option ) {
		$error = 'envio';
	} elseif ( 'agencia' === $in['forma'] && '' === $in['agencia'] ) {
		$error = 'agencia';
	}
	if ( $error ) {
		$key = strtolower( wp_generate_password( 12, false ) );
		set_transient( 'cinnamon_sub_' . $key, $in, HOUR_IN_SECONDS );
		wp_safe_redirect( add_query_arg( array( 'sus_error' => $error, 'sus_datos' => $key ), $back ) . '#suscripcion' );
		exit;
	}

	$data = array(
		'plan'      => $product->get_name() . ' · ' . $offer[ $id ]['label'],
		'zona'      => $states[ $in['departamento'] ],
		'precio'    => cinnamon_sub_money( $option['amount'] ) . ' (' . $option['note'] . ')',
		'molienda'  => '',
		'envio'     => $option['label'] . ( 'agencia' === $in['forma'] ? ': ' . $in['agencia'] . ', se paga al recibir' : '' ),
		'nombre'    => $in['nombre'],
		'email'     => $in['email'],
		'telefono'  => $in['telefono'],
		'direccion' => $in['direccion'] . ', ' . $in['ciudad'] . ', ' . $states[ $in['departamento'] ],
		'notas'     => $in['notas'],
		'link'      => $option['link'],
	);
	cinnamon_sub_store_request( $data );
	// The link was checked to be Mercado Pago's when the product was saved.
	wp_redirect( $data['link'] ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
	exit;
}
