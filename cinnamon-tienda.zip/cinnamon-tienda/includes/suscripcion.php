<?php
/**
 * Coffee subscription (historia 6.8). Cinnamon creates one monthly
 * subscription plan per coffee, size and zone in its Mercado Pago panel and
 * pastes each link in WooCommerce > Planes de suscripción. The page
 * "Suscripción de café" ([cinnamon_suscripcion]) lets the customer choose,
 * stores the request (WooCommerce > Suscripciones de café), emails the store
 * and the customer, and sends the customer to the plan's Mercado Pago link,
 * where the card is entered and charged every month. Without any link the
 * form asks by WhatsApp instead.
 *
 * Zones: "mvd" = Montevideo and Ciudad de la Costa (shipping included),
 * "int" = rest of the country (shipping paid on delivery: a Tres Cruces
 * agency, La Nave, or DePunta where it delivers).
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

const CINNAMON_SUB_TYPE = 'cin_suscripcion';

/**
 * Plans as Cinnamon sent them on 31/10/2026 (monthly prices, no links yet).
 *
 * @return array<int,array{plan:string,size:string,mvd_price:float,mvd_url:string,int_price:float,int_url:string}>
 */
function cinnamon_sub_default_plans() {
	$prices = array(
		'Brasil'           => array( array( 900, 720 ), array( 1500, 1400 ), array( 2800, 2640 ) ),
		'Colombia'         => array( array( 900, 720 ), array( 1500, 1400 ), array( 2800, 2640 ) ),
		'Espresso'         => array( array( 940, 760 ), array( 1580, 1480 ), array( 2960, 2800 ) ),
		'Brasil Premium'   => array( array( 1050, 870 ), array( 1650, 1550 ), array( 3100, 2940 ) ),
		'Colombia Premium' => array( array( 1050, 870 ), array( 1650, 1550 ), array( 3100, 2940 ) ),
	);
	$plans = array();
	foreach ( $prices as $plan => $by_size ) {
		foreach ( array( '500 g', '1 kg', '2 kg' ) as $i => $size ) {
			$plans[] = array(
				'plan'      => $plan,
				'size'      => $size,
				'mvd_price' => (float) $by_size[ $i ][0],
				'mvd_url'   => '',
				'int_price' => (float) $by_size[ $i ][1],
				'int_url'   => '',
			);
		}
	}
	return $plans;
}

/**
 * Current plans: the saved table, or the defaults until it is saved.
 *
 * @return array<int,array>
 */
function cinnamon_sub_plans() {
	$saved = get_option( 'cinnamon_suscripcion_planes', null );
	return is_array( $saved ) ? $saved : cinnamon_sub_default_plans();
}

/**
 * Whether any plan has a Mercado Pago link (otherwise the page asks by WhatsApp).
 *
 * @return bool
 */
function cinnamon_sub_has_links() {
	foreach ( cinnamon_sub_plans() as $row ) {
		if ( $row['mvd_url'] || $row['int_url'] ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether a link is a Mercado Pago one (mercadopago.com.uy, mercadopago.com, mpago.la…).
 *
 * @param string $url URL.
 * @return bool
 */
function cinnamon_sub_is_mp_url( $url ) {
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	return 'https' === wp_parse_url( $url, PHP_URL_SCHEME )
		&& (bool) preg_match( '/(^|\.)(mercadopago\.com(\.[a-z]{2})?|mpago\.(la|li))$/', $host );
}

/**
 * Zone of an address: "mvd" (Montevideo or Ciudad de la Costa) or "int".
 *
 * @param string $state WooCommerce state code (UY-MO…).
 * @param string $city  City as typed.
 * @return string
 */
function cinnamon_sub_zone( $state, $city ) {
	if ( 'UY-MO' === $state || cinnamon_tienda_is_costa( array( 'country' => 'UY', 'state' => $state, 'city' => $city ) ) ) {
		return 'mvd';
	}
	return 'int';
}

/**
 * Price as the store shows it: "$1.500".
 *
 * @param float $amount Amount.
 * @return string
 */
function cinnamon_sub_money( $amount ) {
	return '$' . number_format( (float) $amount, 0, ',', '.' );
}

/**
 * WhatsApp link to the store (the theme's helper when available).
 *
 * @param string $text Message.
 * @return string
 */
function cinnamon_sub_whatsapp( $text = '' ) {
	if ( function_exists( 'cinnamon_whatsapp_url' ) ) {
		return cinnamon_whatsapp_url( $text );
	}
	return 'https://wa.me/59896181666' . ( $text ? '?text=' . rawurlencode( $text ) : '' );
}

/**
 * Form errors by code, so the page never shows text taken from the URL.
 *
 * @return array<string,string>
 */
function cinnamon_sub_errors() {
	return array(
		'vencido' => 'La página estuvo abierta mucho tiempo. Volvé a intentarlo.',
		'plan'    => 'Ese plan no está disponible para tu zona. Elegí otro.',
		'datos'   => 'Completá nombre, un email válido, teléfono, departamento, ciudad y dirección.',
		'envio'   => 'Elegí cómo te llega el envío.',
		'agencia' => 'Escribí el nombre de la agencia de Tres Cruces.',
		'depunta' => 'DePunta no llega a tu ciudad. Elegí una agencia de Tres Cruces o La Nave.',
	);
}

/**
 * Grind options.
 *
 * @return array<string,string>
 */
function cinnamon_sub_grinds() {
	return array(
		'espresso'          => 'Espresso',
		'cafetera italiana' => 'Cafetera italiana',
		'filtro'            => 'Filtro',
		'prensa francesa'   => 'Prensa francesa',
	);
}

/**
 * Ways to receive it in the interior, all paid on delivery.
 *
 * @return array<string,string>
 */
function cinnamon_sub_carriers() {
	return array(
		'tres-cruces' => 'Agencia de la Terminal Tres Cruces',
		'la-nave'     => 'La Nave Cargo Postal',
		'depunta'     => 'DePunta',
	);
}

/**
 * Request statuses.
 *
 * @return array<string,string>
 */
function cinnamon_sub_statuses() {
	return array(
		'pendiente' => 'Pendiente de pago',
		'activa'    => 'Activa',
		'cancelada' => 'Cancelada',
	);
}

/*
 * Requests: a private post type listed under WooCommerce.
 */
add_action(
	'init',
	function () {
		register_post_type(
			CINNAMON_SUB_TYPE,
			array(
				'labels'          => array(
					'name'          => 'Suscripciones',
					'singular_name' => 'Suscripción',
					'edit_item'     => 'Suscripción',
					'search_items'  => 'Buscar suscripciones',
					'not_found'     => 'Todavía no hay solicitudes de suscripción.',
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'woocommerce',
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'capabilities'    => array(
					'create_posts'       => 'do_not_allow',
					'edit_post'          => 'manage_woocommerce',
					'edit_posts'         => 'manage_woocommerce',
					'edit_others_posts'  => 'manage_woocommerce',
					'delete_post'        => 'manage_woocommerce',
					'delete_posts'       => 'manage_woocommerce',
					'publish_posts'      => 'manage_woocommerce',
					'read_post'          => 'manage_woocommerce',
					'read_private_posts' => 'manage_woocommerce',
				),
				'map_meta_cap'    => false,
			)
		);
	}
);

/**
 * Request fields shown in the list and the detail box, in this order.
 *
 * @return array<string,string>
 */
function cinnamon_sub_fields() {
	return array(
		'plan'     => 'Plan o producto',
		'zona'     => 'Zona',
		'precio'   => 'Precio por mes',
		'molienda' => 'Molienda',
		'envio'    => 'Envío',
		'nombre'   => 'Nombre',
		'email'    => 'Email',
		'telefono' => 'Teléfono',
		'direccion' => 'Dirección',
		'notas'    => 'Notas',
		'link'     => 'Link de Mercado Pago',
	);
}

add_filter(
	'manage_' . CINNAMON_SUB_TYPE . '_posts_columns',
	function () {
		return array(
			'cb'     => '<input type="checkbox">',
			'title'  => 'Cliente',
			'plan'   => 'Plan',
			'zona'   => 'Zona y envío',
			'email'  => 'Email y teléfono',
			'estado' => 'Estado',
			'date'   => 'Fecha',
		);
	}
);

add_action(
	'manage_' . CINNAMON_SUB_TYPE . '_posts_custom_column',
	function ( $column, $post_id ) {
		$meta = static fn( $key ) => (string) get_post_meta( $post_id, '_sub_' . $key, true );
		switch ( $column ) {
			case 'plan':
				echo esc_html( implode( ' · ', array_filter( array( $meta( 'plan' ), $meta( 'molienda' ) ) ) ) );
				break;
			case 'zona':
				echo esc_html( $meta( 'zona' ) . ' · ' . $meta( 'envio' ) );
				break;
			case 'email':
				echo esc_html( $meta( 'email' ) . ' · ' . $meta( 'telefono' ) );
				break;
			case 'estado':
				echo esc_html( cinnamon_sub_statuses()[ $meta( 'estado' ) ] ?? '' );
				break;
		}
	},
	10,
	2
);

add_action(
	'add_meta_boxes_' . CINNAMON_SUB_TYPE,
	function () {
		add_meta_box(
			'cinnamon-sub-datos',
			'Datos de la suscripción',
			function ( $post ) {
				wp_nonce_field( 'cinnamon_sub_estado', 'cinnamon_sub_nonce' );
				$estado = (string) get_post_meta( $post->ID, '_sub_estado', true );
				echo '<table class="form-table" role="presentation">';
				foreach ( cinnamon_sub_fields() as $key => $label ) {
					$value = (string) get_post_meta( $post->ID, '_sub_' . $key, true );
					$value = 'link' === $key && $value ? '<a href="' . esc_url( $value ) . '" target="_blank" rel="noopener">' . esc_html( $value ) . '</a>' : nl2br( esc_html( $value ) );
					echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . $value . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above.
				}
				echo '<tr><th scope="row"><label for="cinnamon-sub-estado">Estado</label></th><td><select id="cinnamon-sub-estado" name="cinnamon_sub_estado">';
				foreach ( cinnamon_sub_statuses() as $value => $label ) {
					echo '<option value="' . esc_attr( $value ) . '"' . selected( $estado, $value, false ) . '>' . esc_html( $label ) . '</option>';
				}
				echo '</select><p class="description">Marcala como Activa cuando veas la suscripción en tu panel de Mercado Pago (buscala por el email), y como Cancelada si se da de baja.</p></td></tr></table>';
			},
			CINNAMON_SUB_TYPE,
			'normal',
			'high'
		);
	}
);

add_action(
	'save_post_' . CINNAMON_SUB_TYPE,
	function ( $post_id ) {
		if ( ! isset( $_POST['cinnamon_sub_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cinnamon_sub_nonce'] ), 'cinnamon_sub_estado' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$estado = sanitize_key( $_POST['cinnamon_sub_estado'] ?? '' );
		if ( isset( cinnamon_sub_statuses()[ $estado ] ) ) {
			update_post_meta( $post_id, '_sub_estado', $estado );
		}
	}
);

/*
 * Admin screen: WooCommerce > Planes de suscripción.
 */
add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'woocommerce', 'Planes de suscripción', 'Planes de suscripción', 'manage_woocommerce', 'cinnamon-planes', 'cinnamon_sub_plans_screen' );
	},
	60
);

/**
 * Reads the posted table. Rows without a plan name are dropped.
 *
 * @param array $posted $_POST['planes'].
 * @return array{0:array,1:string[]} Plans and errors.
 */
function cinnamon_sub_plans_read( $posted ) {
	$num    = static function ( $value ) {
		$value = str_replace( array( '$', ' ', '.' ), '', (string) $value ); // "$1.500" → 1500.
		return '' === $value ? '' : str_replace( ',', '.', $value );
	};
	$rows   = array();
	$errors = array();
	foreach ( array_values( (array) $posted ) as $i => $row ) {
		$plan = sanitize_text_field( $row['plan'] ?? '' );
		if ( '' === $plan ) {
			continue;
		}
		$item = array(
			'plan'      => $plan,
			'size'      => sanitize_text_field( $row['size'] ?? '' ),
			'mvd_price' => $num( $row['mvd_price'] ?? '' ),
			'mvd_url'   => esc_url_raw( trim( (string) ( $row['mvd_url'] ?? '' ) ) ),
			'int_price' => $num( $row['int_price'] ?? '' ),
			'int_url'   => esc_url_raw( trim( (string) ( $row['int_url'] ?? '' ) ) ),
			'order'     => (int) ( $row['order'] ?? ( $i + 1 ) ),
		);
		$n = sprintf( 'Fila %d (%s %s)', $i + 1, $plan, $item['size'] );
		if ( '' === $item['size'] ) {
			$errors[] = $n . ': escribí la cantidad.';
		}
		foreach ( array( 'mvd' => 'Montevideo y Ciudad de la Costa', 'int' => 'Interior' ) as $zone => $label ) {
			$price = $item[ $zone . '_price' ];
			if ( ! is_numeric( $price ) || (float) $price <= 0 ) {
				$errors[] = sprintf( '%s: revisá el precio de %s.', $n, $label );
			}
			$item[ $zone . '_price' ] = (float) $price;
			if ( $item[ $zone . '_url' ] && ! cinnamon_sub_is_mp_url( $item[ $zone . '_url' ] ) ) {
				$errors[] = sprintf( '%s: el link de %s no es de Mercado Pago.', $n, $label );
			}
		}
		$rows[] = $item;
	}
	usort( $rows, fn( $a, $b ) => $a['order'] <=> $b['order'] );
	foreach ( $rows as &$row ) {
		unset( $row['order'] );
	}
	unset( $row );
	return array( $rows, $errors );
}

/**
 * Renders the screen and saves the plans.
 */
function cinnamon_sub_plans_screen() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$notice = '';
	$errors = array();
	$rows   = cinnamon_sub_plans();
	if ( isset( $_POST['cinnamon_planes'] ) ) {
		check_admin_referer( 'cinnamon_planes' );
		list( $posted, $errors ) = cinnamon_sub_plans_read( wp_unslash( $_POST['planes'] ?? array() ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field.
		$rows                    = $posted; // With errors nothing is saved and what was typed stays on screen.
		if ( ! $errors ) {
			update_option( 'cinnamon_suscripcion_planes', $posted, false );
			$notice = cinnamon_sub_has_links() ? 'Planes guardados. La página de suscripción ya los ofrece.' : 'Planes guardados. Como todavía no hay links, la página de suscripción sigue pidiendo por WhatsApp.';
		} else {
			$errors[] = 'No se guardó ningún cambio; corregilo y volvé a guardar.';
		}
	}
	$rows = array_merge( $rows, array_fill( 0, 3, array() ) ); // Blank rows to add plans.
	?>
	<div class="wrap">
		<h1>Planes de suscripción</h1>
		<p>Cada fila es un plan mensual de café. Para cada zona, creá en tu panel de Mercado Pago un plan de suscripción mensual con el mismo precio (Suscripciones &gt; Crear plan) y pegá acá su link. Un plan sin link en una zona no se ofrece en esa zona; si ningún plan tiene link, la página pide la suscripción por WhatsApp.</p>
		<p><strong>Montevideo y Ciudad de la Costa:</strong> envío incluido. <strong>Interior:</strong> el cliente paga el envío al recibir (agencia de Tres Cruces, La Nave o DePunta). Para sumar un plan completá una fila vacía; para quitarlo, borrá su nombre. "Orden" define cómo se listan.</p>
		<?php if ( $notice ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
		<?php endif; ?>
		<?php foreach ( $errors as $error ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
		<?php endforeach; ?>
		<form method="post">
			<?php wp_nonce_field( 'cinnamon_planes' ); ?>
			<table class="widefat striped" style="max-width:1400px">
				<thead>
					<tr>
						<th style="width:4em">Orden</th><th>Plan</th><th style="width:6em">Cantidad</th>
						<th style="width:7em">Precio Mvd y Costa</th><th>Link Mvd y Costa</th>
						<th style="width:7em">Precio Interior</th><th>Link Interior</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $i => $row ) : ?>
						<?php $name = static fn( $field ) => 'planes[' . $i . '][' . $field . ']'; ?>
						<tr>
							<td><input type="number" class="small-text" name="<?php echo esc_attr( $name( 'order' ) ); ?>" value="<?php echo esc_attr( (string) ( $i + 1 ) ); ?>" aria-label="Orden"></td>
							<td><input type="text" class="regular-text" style="width:100%" name="<?php echo esc_attr( $name( 'plan' ) ); ?>" value="<?php echo esc_attr( $row['plan'] ?? '' ); ?>" aria-label="Plan" placeholder="Plan nuevo"></td>
							<td><input type="text" style="width:100%" name="<?php echo esc_attr( $name( 'size' ) ); ?>" value="<?php echo esc_attr( $row['size'] ?? '' ); ?>" aria-label="Cantidad" placeholder="500 g"></td>
							<?php foreach ( array( 'mvd', 'int' ) as $zone ) : ?>
								<?php $price = $row[ $zone . '_price' ] ?? ''; ?>
								<td><input type="text" style="width:100%" name="<?php echo esc_attr( $name( $zone . '_price' ) ); ?>" value="<?php echo esc_attr( is_numeric( $price ) ? (string) (float) $price : (string) $price ); ?>" aria-label="Precio <?php echo 'mvd' === $zone ? 'Montevideo y Ciudad de la Costa' : 'Interior'; ?>"></td>
								<td><input type="url" style="width:100%" name="<?php echo esc_attr( $name( $zone . '_url' ) ); ?>" value="<?php echo esc_attr( $row[ $zone . '_url' ] ?? '' ); ?>" aria-label="Link <?php echo 'mvd' === $zone ? 'Montevideo y Ciudad de la Costa' : 'Interior'; ?>" placeholder="https://www.mercadopago.com.uy/subscriptions/checkout?preapproval_plan_id=…"></td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button( 'Guardar planes', 'primary', 'cinnamon_planes' ); ?>
		</form>
	</div>
	<?php
}

/*
 * Page form: [cinnamon_suscripcion] and the plan prices [cinnamon_suscripcion_precios],
 * one plan after another with its sizes explained (no table).
 */
add_shortcode(
	'cinnamon_suscripcion_precios',
	function () {
		$by_plan = array();
		foreach ( cinnamon_sub_plans() as $row ) {
			$by_plan[ $row['plan'] ][] = $row;
		}
		$out = '<div class="sub-prices">';
		foreach ( $by_plan as $plan => $rows ) {
			$out .= '<section class="sub-plan"><h3 class="sub-plan__name">Plan ' . esc_html( $plan ) . '</h3><ul class="sub-plan__sizes">';
			foreach ( $rows as $row ) {
				$out .= '<li><strong>' . esc_html( $row['size'] ) . ' por mes:</strong> '
					. esc_html( cinnamon_sub_money( $row['mvd_price'] ) ) . ' en Montevideo y Ciudad de la Costa, con el envío incluido. '
					. 'En el Interior, ' . esc_html( cinnamon_sub_money( $row['int_price'] ) ) . ' y el envío lo pagás al recibir.</li>';
			}
			$out .= '</ul></section>';
		}
		return $out . '</div>';
	}
);

add_shortcode( 'cinnamon_suscripcion', 'cinnamon_sub_form' );

/**
 * Radio group with the chip look of the theme (.sub-group / .sub-option).
 *
 * @param string               $name    Field name.
 * @param string               $legend  Legend.
 * @param array<string,string> $options Value => label.
 * @param string               $checked Checked value.
 * @return string
 */
function cinnamon_sub_radios( $name, $legend, $options, $checked ) {
	$html = '<fieldset class="sub-group" data-group="' . esc_attr( $name ) . '"><legend>' . esc_html( $legend ) . '</legend>';
	foreach ( $options as $value => $label ) {
		$html .= sprintf(
			'<label class="sub-option"><input type="radio" name="%1$s" value="%2$s"%3$s required> <span>%4$s</span></label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $value, $checked, false ),
			esc_html( $label )
		);
	}
	return $html . '</fieldset>';
}

/**
 * The subscription form. With Mercado Pago links it collects the shipping
 * data and posts to admin-post.php; without links it builds a WhatsApp message.
 *
 * @return string
 */
function cinnamon_sub_form() {
	$plans  = cinnamon_sub_plans();
	$names  = array_values( array_unique( array_column( $plans, 'plan' ) ) );
	$sizes  = array_values( array_unique( array_column( $plans, 'size' ) ) );
	$links  = cinnamon_sub_has_links();
	$error  = cinnamon_sub_errors()[ sanitize_key( $_GET['sus_error'] ?? '' ) ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification -- display only.
	$typed  = array();
	if ( isset( $_GET['sus_datos'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- display only.
		$typed = (array) get_transient( 'cinnamon_sub_' . sanitize_key( $_GET['sus_datos'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	$v      = static fn( $key, $default = '' ) => (string) ( $typed[ $key ] ?? $default );
	$base   = plugin_dir_url( CINNAMON_TIENDA_DIR . 'cinnamon-tienda.php' ) . 'assets/suscripcion/';
	wp_enqueue_style( 'cinnamon-suscripcion', $base . 'suscripcion.css', array(), CINNAMON_TIENDA_VERSION );
	wp_enqueue_script( 'cinnamon-suscripcion', $base . 'suscripcion.js', array(), CINNAMON_TIENDA_VERSION, true );
	wp_localize_script(
		'cinnamon-suscripcion',
		'cinnamonSuscripcion',
		array(
			'plans'   => array_map(
				fn( $row ) => array(
					'plan' => $row['plan'],
					'size' => $row['size'],
					'mvd'  => (float) $row['mvd_price'],
					'int'  => (float) $row['int_price'],
					'ok'   => array(
						'mvd' => '' !== $row['mvd_url'],
						'int' => '' !== $row['int_url'],
					),
				),
				$plans
			),
			'costa'   => array_map( 'cinnamon_tienda_normalize_place', cinnamon_tienda_costa_cities() ),
			'depunta' => array_map( 'cinnamon_tienda_normalize_place', cinnamon_tienda_depunta_cities() ),
			'links'   => $links,
		)
	);

	$grind_value = $v( 'molienda', 'en grano' );
	$html        = '<form class="sub-form" id="suscripcion" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"'
		. ' data-mode="' . ( $links ? 'mp' : 'whatsapp' ) . '" data-wa="' . esc_url( cinnamon_sub_whatsapp() ) . '" data-intro="Hola Cinnamon, quiero suscribirme al café de especialidad">';
	$html .= '<p class="sub-intro">' . ( $links
		? 'Elegí tu plan, completá tus datos y te llevamos a Mercado Pago para cargar la tarjeta. Te confirmamos por mail la fecha del primer envío.'
		: 'Elegí tu plan y mandanos el pedido por WhatsApp. Te contestamos con los pasos para empezar.' ) . '</p>';
	if ( $error ) {
		$html .= '<p class="sub-error" role="alert">' . esc_html( $error ) . '</p>';
	}
	$html .= cinnamon_sub_radios( 'plan', 'Elegí tu café', array_combine( $names, $names ), $v( 'plan', $names[0] ?? '' ) );
	$html .= cinnamon_sub_radios( 'size', 'Cuánto por mes', array_combine( $sizes, $sizes ), $v( 'size', $sizes[1] ?? ( $sizes[0] ?? '' ) ) );
	$html .= cinnamon_sub_radios( 'presentacion', 'Cómo lo querés', array( 'en grano' => 'En grano', 'molido' => 'Molido en el momento' ), 'en grano' === $grind_value ? 'en grano' : 'molido' );
	$html .= '<p class="sub-grind"' . ( 'en grano' === $grind_value ? ' hidden' : '' ) . '><label for="sub-molienda">Molido para</label><select id="sub-molienda" name="molienda">';
	foreach ( cinnamon_sub_grinds() as $value => $label ) {
		$html .= '<option value="' . esc_attr( $value ) . '"' . selected( $grind_value, 'molido para ' . $value, false ) . '>' . esc_html( $label ) . '</option>';
	}
	$html .= '</select></p>';

	if ( $links ) {
		$field = static function ( $name, $label, $type = 'text', $attrs = '' ) use ( $v ) {
			return '<p class="sub-field"><label for="sub-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><input id="sub-' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v( $name ) ) . '" ' . $attrs . '></p>';
		};
		$states = WC()->countries ? WC()->countries->get_states( 'UY' ) : array();
		$html  .= '<fieldset class="sub-data"><legend>Tus datos para el envío</legend>';
		$html  .= $field( 'nombre', 'Nombre y apellido', 'text', 'required autocomplete="name"' );
		$html  .= $field( 'email', 'Email (el mismo que usás en Mercado Pago)', 'email', 'required autocomplete="email"' );
		$html  .= $field( 'telefono', 'Teléfono', 'tel', 'required autocomplete="tel"' );
		$html  .= '<p class="sub-field"><label for="sub-departamento">Departamento</label><select id="sub-departamento" name="departamento" required><option value="">Elegí…</option>';
		foreach ( $states as $code => $state ) {
			$html .= '<option value="' . esc_attr( $code ) . '"' . selected( $v( 'departamento' ), $code, false ) . '>' . esc_html( $state ) . '</option>';
		}
		$html .= '</select></p>';
		$html .= $field( 'ciudad', 'Ciudad o barrio', 'text', 'required autocomplete="address-level2"' );
		$html .= $field( 'direccion', 'Dirección', 'text', 'required autocomplete="street-address"' );
		$html .= '<div class="sub-interior" hidden>';
		$html .= cinnamon_sub_radios( 'envio', 'Cómo te llega (el envío se paga al recibir)', cinnamon_sub_carriers(), $v( 'envio' ) );
		$html .= $field( 'agencia', 'Nombre de la agencia de Tres Cruces' );
		$html .= '</div>';
		$html .= '<p class="sub-field"><label for="sub-notas">Notas (opcional)</label><textarea id="sub-notas" name="notas" rows="2">' . esc_textarea( $v( 'notas' ) ) . '</textarea></p>';
		$html .= '</fieldset>';
		$html .= '<p class="sub-hp" aria-hidden="true"><label>No completar <input type="text" name="sitio_web" tabindex="-1" autocomplete="off"></label></p>';
		$html .= '<input type="hidden" name="action" value="cinnamon_suscripcion">' . wp_nonce_field( 'cinnamon_suscripcion', '_wpnonce', true, false );
		$html .= '<p class="sub-price" aria-live="polite"></p>';
		$html .= '<button type="submit" class="wp-element-button sub-send">Suscribirme con Mercado Pago</button>';
		$html .= '<p class="sub-note">Te llevamos a Mercado Pago para cargar tu tarjeta. Se cobra automáticamente todos los meses y podés cancelar cuando quieras desde tu cuenta de Mercado Pago.</p>';
	} else {
		$html .= '<p class="sub-price" aria-live="polite"></p>';
		$html .= '<a class="btn-wa sub-send" href="' . esc_url( cinnamon_sub_whatsapp( 'Hola Cinnamon, quiero suscribirme al café de especialidad.' ) ) . '" target="_blank" rel="noopener">' . ( function_exists( 'cinnamon_icon' ) ? cinnamon_icon( 'whatsapp' ) : '' ) . ' Anotarme por WhatsApp</a>';
	}
	return $html . '</form>';
}

/*
 * Form handler: validates, stores the request, emails, redirects to Mercado Pago.
 */
add_action( 'admin_post_cinnamon_suscripcion', 'cinnamon_sub_submit' );
add_action( 'admin_post_nopriv_cinnamon_suscripcion', 'cinnamon_sub_submit' );

/**
 * Handles the form.
 */
function cinnamon_sub_submit() {
	$page = get_page_by_path( 'suscripcion-de-cafe' );
	$back = $page ? get_permalink( $page ) : home_url( '/' );
	if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'cinnamon_suscripcion' ) ) {
		wp_safe_redirect( add_query_arg( 'sus_error', 'vencido', $back ) . '#suscripcion' );
		exit;
	}
	if ( ! empty( $_POST['sitio_web'] ) ) { // Honeypot: robots fill every field.
		wp_safe_redirect( $back );
		exit;
	}
	$in = array();
	foreach ( array( 'plan', 'size', 'presentacion', 'molienda', 'nombre', 'telefono', 'departamento', 'ciudad', 'direccion', 'envio', 'agencia' ) as $key ) {
		$in[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );
	}
	$in['email'] = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$in['notas'] = sanitize_textarea_field( wp_unslash( $_POST['notas'] ?? '' ) );

	$zone   = cinnamon_sub_zone( $in['departamento'], $in['ciudad'] );
	$row    = null;
	foreach ( cinnamon_sub_plans() as $candidate ) {
		if ( $candidate['plan'] === $in['plan'] && $candidate['size'] === $in['size'] ) {
			$row = $candidate;
		}
	}
	$states = WC()->countries ? WC()->countries->get_states( 'UY' ) : array();
	$grind  = 'molido' === $in['presentacion'] && isset( cinnamon_sub_grinds()[ $in['molienda'] ] ) ? 'molido para ' . $in['molienda'] : 'en grano';
	$error  = '';
	if ( ! $row || ! $row[ $zone . '_url' ] ) {
		$error = 'plan';
	} elseif ( '' === $in['nombre'] || ! is_email( $in['email'] ) || '' === $in['telefono'] || ! isset( $states[ $in['departamento'] ] ) || '' === $in['ciudad'] || '' === $in['direccion'] ) {
		$error = 'datos';
	} elseif ( 'int' === $zone && ! isset( cinnamon_sub_carriers()[ $in['envio'] ] ) ) {
		$error = 'envio';
	} elseif ( 'int' === $zone && 'tres-cruces' === $in['envio'] && '' === $in['agencia'] ) {
		$error = 'agencia';
	} elseif ( 'int' === $zone && 'depunta' === $in['envio'] && ! cinnamon_tienda_depunta_covers( $in['ciudad'] ) ) {
		$error = 'depunta';
	}
	if ( $error ) {
		$key = wp_generate_password( 12, false );
		set_transient( 'cinnamon_sub_' . strtolower( $key ), array_merge( $in, array( 'molienda' => $grind ) ), HOUR_IN_SECONDS );
		wp_safe_redirect( add_query_arg( array( 'sus_error' => $error, 'sus_datos' => strtolower( $key ) ), $back ) . '#suscripcion' );
		exit;
	}

	$data = array(
		'plan'      => $row['plan'] . ' · ' . $row['size'],
		'zona'      => 'mvd' === $zone ? 'Montevideo y Ciudad de la Costa' : 'Interior',
		'precio'    => cinnamon_sub_money( $row[ $zone . '_price' ] ) . ( 'mvd' === $zone ? ' (envío incluido)' : ' (más el envío, al recibir)' ),
		'molienda'  => ucfirst( $grind ),
		'envio'     => 'mvd' === $zone ? 'Dash Pack, incluido' : cinnamon_sub_carriers()[ $in['envio'] ] . ( 'tres-cruces' === $in['envio'] ? ': ' . $in['agencia'] : '' ) . ', se paga al recibir',
		'nombre'    => $in['nombre'],
		'email'     => $in['email'],
		'telefono'  => $in['telefono'],
		'direccion' => $in['direccion'] . ', ' . $in['ciudad'] . ', ' . $states[ $in['departamento'] ],
		'notas'     => $in['notas'],
		'link'      => $row[ $zone . '_url' ],
	);
	cinnamon_sub_store_request( $data );

	// The link was checked to be Mercado Pago's when the table was saved.
	wp_redirect( $data['link'] ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
	exit;
}

/**
 * Stores a subscription request (coffee or product) and emails the store
 * and the customer. Shared with includes/suscripcion-producto.php.
 *
 * @param array<string,string> $data Values for cinnamon_sub_fields().
 */
function cinnamon_sub_store_request( $data ) {
	$id = wp_insert_post(
		array(
			'post_type'   => CINNAMON_SUB_TYPE,
			'post_status' => 'publish',
			'post_title'  => $data['nombre'],
		)
	);
	if ( $id && ! is_wp_error( $id ) ) {
		foreach ( $data as $key => $value ) {
			update_post_meta( $id, '_sub_' . $key, $value );
		}
		update_post_meta( $id, '_sub_estado', 'pendiente' );
	}

	$lines = '';
	foreach ( cinnamon_sub_fields() as $key => $label ) {
		if ( '' !== ( $data[ $key ] ?? '' ) && 'link' !== $key ) {
			$lines .= $label . ': ' . $data[ $key ] . "\n";
		}
	}
	$store = get_option( 'woocommerce_email_from_address' ) ? get_option( 'woocommerce_email_from_address' ) : get_option( 'admin_email' );
	wp_mail(
		$store,
		'Nueva suscripción: ' . $data['plan'] . ' (' . $data['nombre'] . ')',
		"Hay una nueva solicitud de suscripción. El cliente fue a Mercado Pago a cargar su tarjeta; cuando veas la suscripción en tu panel de Mercado Pago, marcala como Activa en WooCommerce > Suscripciones.\n\n" . $lines,
		array( 'Reply-To: ' . $data['email'] )
	);
	wp_mail(
		$data['email'],
		'Tu suscripción en Cinnamon',
		'¡Gracias, ' . $data['nombre'] . "! Recibimos tu suscripción. Para activarla, cargá tu tarjeta en Mercado Pago (si no terminaste, usá este link):\n" . $data['link'] . "\n\nSe cobra automáticamente todos los meses y podés cancelar cuando quieras desde tu cuenta de Mercado Pago.\n\n" . $lines . "\nCualquier duda, escribinos por WhatsApp: " . cinnamon_sub_whatsapp()
	);
}
