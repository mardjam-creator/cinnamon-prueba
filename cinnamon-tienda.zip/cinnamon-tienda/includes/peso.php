<?php
/**
 * DePunta and La Nave charge by the order's weight: each weight tier has a
 * cost and the order amount from which shipping is free. The tables are
 * edited in WooCommerce > Tarifas por peso (option cinnamon_weight_tables),
 * and the shipping policy shows them with [cinnamon_tarifas_peso].
 *
 * Orders over the largest tier only get Dash Pack (in its zone) and pickup.
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

/**
 * Carriers that charge by weight: key => name and the option with their rate
 * instances, saved by the setup's "Envíos" step.
 *
 * @return array<string,array{name:string,option:string}>
 */
function cinnamon_tienda_weight_carriers() {
	return array(
		'depunta' => array( 'name' => 'DePunta', 'option' => 'cinnamon_depunta_rates' ),
		'lanave'  => array( 'name' => 'La Nave Cargo Postal', 'option' => 'cinnamon_lanave_rates' ),
	);
}

/**
 * Starting tables, as Cinnamon passed them on 2026-10-30. Each row: up to kg,
 * cost, free from (null: never free).
 *
 * @return array<string,array<int,array{0:float,1:float,2:?float}>>
 */
function cinnamon_tienda_weight_defaults() {
	return array(
		'depunta' => array(
			array( 2, 240, 3500 ), array( 5, 250, 3500 ), array( 10, 300, 4000 ), array( 15, 345, 5000 ),
			array( 20, 430, 6000 ), array( 25, 500, 7000 ), array( 30, 580, 8000 ), array( 35, 680, 9500 ),
			array( 40, 780, 11000 ), array( 45, 875, 12500 ), array( 50, 980, 14000 ),
		),
		'lanave'  => array(
			array( 5, 285, 4000 ), array( 10, 335, 5000 ), array( 15, 380, 5500 ), array( 20, 440, 6000 ),
			array( 25, 500, 7000 ), array( 30, 575, 8000 ), array( 35, 660, 9500 ), array( 40, 760, 11000 ),
			array( 45, 875, 12500 ), array( 50, 1000, 14000 ),
		),
	);
}

/**
 * The tables in use: the ones saved in wp-admin, or the starting ones.
 *
 * @return array<string,array<int,array{0:float,1:float,2:?float}>>
 */
function cinnamon_tienda_weight_tables() {
	$saved = get_option( 'cinnamon_weight_tables' );
	return apply_filters( 'cinnamon_tienda_weight_tables', is_array( $saved ) ? $saved : cinnamon_tienda_weight_defaults() );
}

/**
 * Kilos written in a text: "500 g", "1 kg", "1,5 kg", "500 ml" (as grams).
 * Takes the last amount, so "Pan 7 cereales 350 g" is 0.35.
 *
 * @param string $text Text.
 * @return float
 */
function cinnamon_tienda_parse_weight( $text ) {
	if ( ! preg_match_all( '/(\d+(?:[.,]\d+)?)\s*(kg|kilos?|g|gr|grs|gramos|l|lt|lts|litros?|ml|cc)\b/iu', (string) $text, $m, PREG_SET_ORDER ) ) {
		return 0.0;
	}
	$last   = end( $m );
	$amount = (float) str_replace( ',', '.', $last[1] );
	return in_array( strtolower( $last[2] ), array( 'kg', 'kilo', 'kilos', 'l', 'lt', 'lts', 'litro', 'litros' ), true ) ? $amount : $amount / 1000;
}

/**
 * Weight of one unit, in kg: the weight loaded in WooCommerce; else the
 * presentation ("500 g"); else the parent product's weight; else the name.
 *
 * @param WC_Product $product Product or variation.
 * @return float
 */
function cinnamon_tienda_item_weight( $product ) {
	$own = (float) $product->get_weight( 'edit' );
	if ( $own > 0 ) {
		return (float) wc_get_weight( $own, 'kg' );
	}
	if ( $product->is_type( 'variation' ) ) {
		$kg = cinnamon_tienda_parse_weight( wc_get_formatted_variation( $product, true, false, false ) );
		if ( $kg > 0 ) {
			return $kg;
		}
		$parent = wc_get_product( $product->get_parent_id() );
		if ( $parent && (float) $parent->get_weight() > 0 ) {
			return (float) wc_get_weight( (float) $parent->get_weight(), 'kg' );
		}
	}
	return cinnamon_tienda_parse_weight( $product->get_name() );
}

/**
 * Weight of a shipping package, in kg (no packaging).
 *
 * @param array $package Package.
 * @return float
 */
function cinnamon_tienda_package_weight( $package ) {
	$kg = 0.0;
	foreach ( $package['contents'] ?? array() as $item ) {
		if ( ! empty( $item['data'] ) && $item['data'] instanceof WC_Product ) {
			$kg += cinnamon_tienda_item_weight( $item['data'] ) * (float) $item['quantity'];
		}
	}
	return $kg;
}

/**
 * Prices DePunta and La Nave by weight, with free shipping from the tier's
 * amount (same amount the other free shipping rules measure: products with
 * taxes, after coupons). Over the largest tier, removes them and the
 * customer-chosen agency: Dash Pack and pickup remain.
 *
 * @param array<string,WC_Shipping_Rate> $rates   Rates.
 * @param array                          $package Package.
 * @return array
 */
function cinnamon_tienda_weight_rates( $rates, $package ) {
	$tables = cinnamon_tienda_weight_tables();
	$ids    = array();
	foreach ( cinnamon_tienda_weight_carriers() as $key => $carrier ) {
		foreach ( (array) get_option( $carrier['option'], array() ) as $id ) {
			$ids[ (int) $id ] = $key;
		}
	}
	if ( ! $ids ) {
		return $rates;
	}

	$weight = cinnamon_tienda_package_weight( $package );
	$total  = 0;
	foreach ( $package['contents'] ?? array() as $item ) {
		$total += (float) $item['line_total'] + (float) $item['line_tax'];
	}
	$limit = 0;
	foreach ( $tables as $rows ) {
		foreach ( $rows as $row ) {
			$limit = max( $limit, (float) $row[0] );
		}
	}

	foreach ( $rates as $key => $rate ) {
		$carrier = $ids[ (int) $rate->get_instance_id() ] ?? null;
		if ( null === $carrier ) {
			if ( defined( 'CINNAMON_AGENCY_METHOD' ) && CINNAMON_AGENCY_METHOD === $rate->get_method_id() && $weight > $limit ) {
				unset( $rates[ $key ] );
			}
			continue;
		}
		$tier = null;
		foreach ( $tables[ $carrier ] ?? array() as $row ) {
			if ( $weight <= (float) $row[0] ) {
				$tier = $row;
				break;
			}
		}
		if ( ! $tier ) {
			unset( $rates[ $key ] );
			continue;
		}
		$free = null !== $tier[2] && '' !== $tier[2] && $total >= (float) $tier[2];
		$rate->set_cost( $free ? 0 : (float) $tier[1] );
		$rate->set_taxes( array() );
	}
	return $rates;
}
add_filter( 'woocommerce_package_rates', 'cinnamon_tienda_weight_rates', 25, 2 );

/**
 * "$3.500" as the shop writes prices.
 *
 * @param float $amount Amount.
 * @return string
 */
function cinnamon_tienda_weight_money( $amount ) {
	return wp_strip_all_tags( wc_price( $amount, array( 'decimals' => 0 ) ) );
}

/**
 * [cinnamon_tarifas_peso]: the tables in use, for the shipping policy page.
 *
 * @return string
 */
function cinnamon_tienda_weight_shortcode() {
	$tables = cinnamon_tienda_weight_tables();
	$html   = '';
	foreach ( cinnamon_tienda_weight_carriers() as $key => $carrier ) {
		if ( empty( $tables[ $key ] ) ) {
			continue;
		}
		$html .= '<figure class="wp-block-table shipping-table"><table><thead><tr><th>' . esc_html( $carrier['name'] ) . '</th><th>Costo</th><th>Envío gratis desde</th></tr></thead><tbody>';
		foreach ( $tables[ $key ] as $row ) {
			$html .= sprintf(
				'<tr><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( 'Hasta ' . wc_format_localized_decimal( (float) $row[0] ) . ' kg' ),
				esc_html( cinnamon_tienda_weight_money( (float) $row[1] ) ),
				esc_html( null === $row[2] || '' === $row[2] ? '-' : cinnamon_tienda_weight_money( (float) $row[2] ) )
			);
		}
		$html .= '</tbody></table></figure>';
	}
	return $html;
}
add_shortcode( 'cinnamon_tarifas_peso', 'cinnamon_tienda_weight_shortcode' );

/**
 * Admin screen: WooCommerce > Tarifas por peso.
 */
add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'woocommerce', 'Tarifas por peso', 'Tarifas por peso', 'manage_woocommerce', 'cinnamon-tarifas-peso', 'cinnamon_tienda_weight_screen' );
	},
	60
);

/**
 * Reads the posted tables. Rows left blank are dropped; rows with wrong
 * values are dropped and reported.
 *
 * @param array $posted $_POST['tablas'].
 * @return array{0:array,1:string[]} Tables and errors.
 */
function cinnamon_tienda_weight_read( $posted ) {
	$num    = static function ( $value ) {
		$value = trim( str_replace( array( '$', ' ' ), '', (string) $value ) );
		return '' === $value ? '' : str_replace( ',', '.', $value );
	};
	$tables = array();
	$errors = array();
	foreach ( cinnamon_tienda_weight_carriers() as $key => $carrier ) {
		$rows = array();
		foreach ( (array) ( $posted[ $key ] ?? array() ) as $i => $row ) {
			$upto = $num( $row['hasta'] ?? '' );
			$cost = $num( $row['costo'] ?? '' );
			$free = $num( $row['gratis'] ?? '' );
			if ( '' === $upto && '' === $cost && '' === $free ) {
				continue;
			}
			if ( ! is_numeric( $upto ) || (float) $upto <= 0 || ! is_numeric( $cost ) || (float) $cost < 0 || ( '' !== $free && ( ! is_numeric( $free ) || (float) $free < 0 ) ) ) {
				$errors[] = sprintf( '%s, fila %d: revisá los números (peso mayor que 0, costo y monto sin letras). No se guardó ningún cambio; corregilo y volvé a guardar.', $carrier['name'], $i + 1 );
				continue;
			}
			$rows[] = array( (float) $upto, (float) $cost, '' === $free ? null : (float) $free );
		}
		usort( $rows, fn( $a, $b ) => $a[0] <=> $b[0] );
		$tables[ $key ] = $rows;
	}
	return array( $tables, $errors );
}

/**
 * Renders the screen and saves the tables.
 */
function cinnamon_tienda_weight_screen() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$notice = '';
	$errors = array();
	$posted = null; // What was typed, shown again when it can't be saved.
	if ( isset( $_POST['cinnamon_tarifas'] ) || isset( $_POST['cinnamon_tarifas_reset'] ) ) {
		check_admin_referer( 'cinnamon_tarifas' );
		if ( isset( $_POST['cinnamon_tarifas_reset'] ) ) {
			delete_option( 'cinnamon_weight_tables' );
			$notice = 'Se restablecieron las tablas iniciales.';
		} else {
			$raw                      = wp_unslash( $_POST['tablas'] ?? array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- numbers validated in cinnamon_tienda_weight_read(); shown escaped.
			list( $tables, $errors ) = cinnamon_tienda_weight_read( $raw );
			if ( $errors ) {
				// Nothing is saved, so a mistake never drops a tier; the typed values stay on screen.
				$posted = $raw;
			} else {
				update_option( 'cinnamon_weight_tables', $tables, false );
				$notice = 'Tablas guardadas. El checkout y la política de envíos ya usan los valores nuevos.';
			}
		}
	}
	$tables = cinnamon_tienda_weight_tables();
	?>
	<div class="wrap">
		<h1>Tarifas por peso</h1>
		<p>DePunta y La Nave cobran según el peso del pedido. Cada fila es un tramo: el pedido usa la primera fila cuyo "Hasta" alcanza su peso. Si el monto de la compra llega a "Gratis desde", el envío es gratis; dejalo vacío si ese tramo nunca es gratis. Para sumar un tramo, completá una fila vacía; para quitarlo, borrá sus tres valores.</p>
		<p>Los pedidos que pesan más que el último tramo solo pueden elegir Dash Pack (en su zona) o retiro en el local. El peso de cada artículo es el cargado en el producto; si no tiene, se toma de la presentación o del nombre ("500 g", "1 kg").</p>
		<?php if ( $notice ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $notice ); ?></p></div>
		<?php endif; ?>
		<?php foreach ( $errors as $error ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
		<?php endforeach; ?>
		<form method="post">
			<?php wp_nonce_field( 'cinnamon_tarifas' ); ?>
			<?php foreach ( cinnamon_tienda_weight_carriers() as $key => $carrier ) : ?>
				<h2><?php echo esc_html( $carrier['name'] ); ?></h2>
				<table class="widefat striped" style="max-width:640px">
					<thead><tr><th>Hasta (kg)</th><th>Costo ($)</th><th>Gratis desde ($)</th></tr></thead>
					<tbody>
					<?php
					$rows = array_values( $tables[ $key ] ?? array() );
					if ( null !== $posted ) {
						$rows = array_map( fn( $r ) => array( $r['hasta'] ?? '', $r['costo'] ?? '', $r['gratis'] ?? '' ), array_values( (array) ( $posted[ $key ] ?? array() ) ) );
						$rows = array_values( array_filter( $rows, fn( $r ) => implode( '', $r ) !== '' ) );
					}
					for ( $i = 0; $i < count( $rows ) + 3; $i++ ) :
						$row = $rows[ $i ] ?? array( '', '', '' );
						?>
						<tr>
							<?php foreach ( array( 'hasta', 'costo', 'gratis' ) as $col => $field ) : ?>
								<td><input type="text" inputmode="decimal" class="small-text" style="width:8em" name="<?php echo esc_attr( "tablas[$key][$i][$field]" ); ?>" value="<?php echo esc_attr( null === $row[ $col ] ? '' : (string) $row[ $col ] ); ?>" aria-label="<?php echo esc_attr( $carrier['name'] . ', fila ' . ( $i + 1 ) . ', ' . array( 'hasta kg', 'costo', 'gratis desde' )[ $col ] ); ?>"></td>
							<?php endforeach; ?>
						</tr>
					<?php endfor; ?>
					</tbody>
				</table>
			<?php endforeach; ?>
			<p class="submit">
				<?php submit_button( 'Guardar tablas', 'primary', 'cinnamon_tarifas', false ); ?>
				<?php submit_button( 'Restablecer las tablas iniciales', 'secondary', 'cinnamon_tarifas_reset', false, array( 'onclick' => "return confirm('¿Volver a las tablas iniciales? Se pierden los cambios.');" ) ); ?>
			</p>
		</form>
	</div>
	<?php
}
