/* Delivery location picker under the shipping address in the block checkout. */
(function () {
	'use strict';

	var cfg = window.cinnamonMapa;
	if (!cfg || !window.L || !window.wp || !wp.data) return;

	var STORE = 'wc/store/checkout';
	var ui = null; // Built once; React may drop it from the DOM and we put it back.

	function currentValue() {
		var fields = wp.data.select(STORE).getAdditionalFields() || {};
		return fields[cfg.field] || '';
	}

	// Writes only real changes: every write re-renders the checkout, which runs sync() again.
	function save(value) {
		if (currentValue() === value) return;
		var fields = Object.assign({}, wp.data.select(STORE).getAdditionalFields() || {});
		fields[cfg.field] = value;
		wp.data.dispatch(STORE).setAdditionalFields(fields);
	}

	function parse(value) {
		var m = /^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/.exec(value || '');
		return m ? [parseFloat(m[1]), parseFloat(m[2])] : null;
	}

	// The point and the address's department and city follow each other.
	var CART = 'wc/store/cart';
	var NOMINATIM = 'https://nominatim.openstreetmap.org/';
	var lastKey = ''; // Department and city the map was last centred on (or filled in from the point).
	var recenter = null;

	// Lowercase, no accents, single spaces: "San José" and "san jose" are the same place.
	function norm(text) {
		return String(text || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
	}
	var costa = (cfg.costa || []).map(norm);
	// Ciudad de la Costa and its neighbourhoods all count as the same city.
	function sameCity(a, b) {
		a = norm(a); b = norm(b);
		return a === b || (costa.indexOf(a) !== -1 && costa.indexOf(b) !== -1);
	}
	// "Canelones" or "Departamento de Canelones" -> "UY-CA".
	function stateCode(name) {
		var n = norm(name).replace(/^departamento de /, '');
		var codes = Object.keys(cfg.states || {});
		for (var i = 0; i < codes.length; i++) if (norm(cfg.states[codes[i]]) === n) return codes[i];
		return '';
	}
	// Nominatim address -> { state, city } as WooCommerce has them, or null outside Uruguay.
	// Montevideo gives city "Montevideo" (not the barrio); places without a city give their locality.
	function placeOf(addr) {
		if (!addr || addr.country_code !== 'uy') return null;
		var iso = addr['ISO3166-2-lvl4'];
		var state = iso && cfg.states && cfg.states[iso] ? iso : stateCode(addr.state);
		var city = addr.city || addr.town || addr.village || addr.hamlet || addr.suburb || '';
		return state ? { state: state, city: city } : null;
	}
	function shipping() {
		return (wp.data.select(CART).getCustomerData() || {}).shippingAddress || {};
	}
	// Same as the customer typing them: the checkout recalculates the shipping rates.
	// With "Usar la misma dirección para la facturación" on, the billing address follows,
	// as the checkout's own form does; otherwise it would differ and WooCommerce would
	// untick that box on the next visit.
	function applyPlace(place) {
		lastKey = place.state + '|' + norm(place.city);
		var change = { state: place.state, city: place.city };
		var cart = wp.data.dispatch(CART);
		cart.setShippingAddress(Object.assign({}, shipping(), change));
		if (wp.data.select(STORE).getUseShippingAsBilling()) {
			var billing = (wp.data.select(CART).getCustomerData() || {}).billingAddress || {};
			cart.setBillingAddress(Object.assign({}, billing, change));
		}
	}

	function build() {
		var box = document.createElement('div');
		box.className = 'cin-map';
		box.innerHTML =
			'<p class="cin-map__title">Marcá tu ubicación en el mapa <span>(opcional)</span></p>' +
			'<p class="cin-map__help">Ayuda al repartidor a encontrarte. Tocá el mapa o arrastrá el marcador hasta tu puerta.</p>' +
			'<div class="cin-map__actions">' +
			'<button type="button" class="cin-map__btn" data-act="locate">Usar mi ubicación</button>' +
			'<button type="button" class="cin-map__btn" data-act="search">Buscar mi dirección</button>' +
			'<button type="button" class="cin-map__btn cin-map__btn--link" data-act="clear" hidden>Quitar marca</button>' +
			'</div>' +
			'<div class="cin-map__ask" role="group" aria-label="Ciudad del punto marcado" hidden>' +
			'<p class="cin-map__ask-text" aria-live="polite"></p>' +
			'<button type="button" class="cin-map__btn cin-map__btn--main" data-act="use">Usar esta ciudad</button>' +
			'<button type="button" class="cin-map__btn cin-map__btn--link" data-act="keep">Dejar como está</button>' +
			'</div>' +
			'<div class="cin-map__canvas" role="application" aria-label="Mapa para marcar la ubicación de entrega"></div>' +
			'<p class="cin-map__status" aria-live="polite"></p>';

		L.Icon.Default.imagePath = cfg.iconsPath;
		var canvas = box.querySelector('.cin-map__canvas');
		var map = L.map(canvas, { scrollWheelZoom: false }).setView(cfg.center, 12);
		// The map is created before it is in the page (0 px wide); refit whenever its size changes.
		if ('ResizeObserver' in window) new ResizeObserver(function () { map.invalidateSize(); }).observe(canvas);
		L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
			maxZoom: 19,
			attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
		}).addTo(map);

		var marker = null;
		var status = box.querySelector('.cin-map__status');
		var clearBtn = box.querySelector('[data-act="clear"]');
		var ask = box.querySelector('.cin-map__ask');
		var pending = null;

		function describe(place) {
			return (place.city ? place.city + ', ' : '') + cfg.states[place.state];
		}

		// Fills in department and city from the point; asks first when the address says another place.
		function relate(place) {
			ask.hidden = true;
			if (!place) return;
			var cur = shipping();
			var stateOk = !cur.state || cur.state === place.state;
			var cityOk = !cur.city || !place.city || sameCity(cur.city, place.city);
			if (stateOk && cityOk) {
				if (!cur.state || (!cur.city && place.city)) applyPlace({ state: place.state, city: cur.city || place.city });
				return;
			}
			pending = place;
			ask.querySelector('.cin-map__ask-text').textContent = 'El punto está en ' + describe(place) + '. ¿Usar esta ciudad?';
			ask.hidden = false;
		}

		// One reverse lookup per customer action (Nominatim asks for moderate use).
		function lookup(latlng) {
			fetch(NOMINATIM + 'reverse?format=jsonv2&zoom=14&addressdetails=1&accept-language=es&lat=' + latlng.lat + '&lon=' + latlng.lng)
				.then(function (r) { return r.json(); })
				.then(function (res) { relate(placeOf(res && res.address)); })
				.catch(function () { status.textContent = 'Marcamos el punto, pero no pudimos ver en qué ciudad está. Revisá el departamento y la ciudad.'; });
		}

		ask.querySelector('[data-act="use"]').addEventListener('click', function () {
			if (pending) {
				applyPlace(pending);
				status.textContent = 'Cambiamos la dirección a ' + describe(pending) + '.';
			}
			ask.hidden = true;
		});
		ask.querySelector('[data-act="keep"]').addEventListener('click', function () { ask.hidden = true; });

		// Places the marker. `store: false` only shows a point that is already saved.
		function setPoint(latlng, opts) {
			opts = opts || {};
			if (!marker) {
				marker = L.marker(latlng, { draggable: true, autoPan: true }).addTo(map);
				marker.on('dragend', function () { setPoint(marker.getLatLng(), { keepView: true }); });
			} else {
				marker.setLatLng(latlng);
			}
			if (!opts.keepView) map.setView(latlng, Math.max(map.getZoom(), 16));
			if (opts.store !== false) {
				var ll = marker.getLatLng();
				save(ll.lat.toFixed(6) + ',' + ll.lng.toFixed(6));
				// The address search already knows the place; the other actions look it up.
				if (opts.place !== undefined) relate(opts.place);
				else lookup(ll);
			}
			clearBtn.hidden = false;
			status.textContent = opts.message || 'Ubicación marcada. Podés arrastrar el marcador para ajustarla.';
		}

		function removePoint() {
			if (marker) { map.removeLayer(marker); marker = null; }
			clearBtn.hidden = true;
			ask.hidden = true;
		}

		map.on('click', function (e) { setPoint(e.latlng, { keepView: true }); });

		clearBtn.addEventListener('click', function () {
			removePoint();
			save('');
			status.textContent = 'Quitaste la marca del mapa.';
		});

		box.querySelector('[data-act="locate"]').addEventListener('click', function () {
			if (!navigator.geolocation) { status.textContent = 'Tu navegador no permite obtener la ubicación.'; return; }
			status.textContent = 'Buscando tu ubicación…';
			navigator.geolocation.getCurrentPosition(
				function (pos) { setPoint([pos.coords.latitude, pos.coords.longitude], { message: 'Usamos tu ubicación actual. Revisá que el marcador esté en tu puerta.' }); },
				function () { status.textContent = 'No pudimos obtener tu ubicación. Marcala tocando el mapa.'; },
				{ enableHighAccuracy: true, timeout: 10000 }
			);
		});

		box.querySelector('[data-act="search"]').addEventListener('click', function () {
			var get = function (id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; };
			var street = get('shipping-address_1');
			if (!street) { status.textContent = 'Escribí primero la dirección de envío.'; return; }
			var q = [street, get('shipping-city'), 'Uruguay'].filter(Boolean).join(', ');
			status.textContent = 'Buscando la dirección…';
			fetch(NOMINATIM + 'search?format=json&limit=1&addressdetails=1&countrycodes=uy&accept-language=es&q=' + encodeURIComponent(q))
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res[0]) setPoint([parseFloat(res[0].lat), parseFloat(res[0].lon)], { message: 'Encontramos la dirección. Ajustá el marcador si no quedó exacto.', place: placeOf(res[0].address) });
					else status.textContent = 'No encontramos esa dirección. Marcala tocando el mapa.';
				})
				.catch(function () { status.textContent = 'No pudimos buscar la dirección. Marcala tocando el mapa.'; });
		});

		var saved = parse(currentValue());
		if (saved) setPoint(saved, { store: false, message: 'Ubicación marcada.' });

		return { box: box, map: map, hasPoint: function () { return !!marker; }, removePoint: removePoint, status: status };
	}

	// Without a marker, centre the map on the department and city the customer chose,
	// once they stop typing. A marker already placed never moves.
	function followAddress() {
		if (!ui || ui.box.hidden || ui.hasPoint()) return;
		var a = shipping();
		var key = (a.state || '') + '|' + norm(a.city);
		if (key === lastKey) return;
		lastKey = key;
		clearTimeout(recenter);
		if (!a.state || !cfg.states[a.state]) return;
		recenter = setTimeout(function () {
			var q = [a.city, cfg.states[a.state], 'Uruguay'].filter(Boolean).join(', ');
			fetch(NOMINATIM + 'search?format=json&limit=1&countrycodes=uy&accept-language=es&q=' + encodeURIComponent(q))
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res[0] && !ui.hasPoint()) ui.map.setView([parseFloat(res[0].lat), parseFloat(res[0].lon)], a.city ? 14 : 10);
				})
				.catch(function () {});
		}, 900);
	}

	// Show the map only for home delivery; for pickup, hide it and clear the point.
	function sync() {
		// Pickup first: with pickup selected the address block is gone, but the map may still be in the page.
		var pickup = !!wp.data.select(STORE).prefersCollection();
		if (pickup) {
			if (ui) {
				ui.box.hidden = true;
				if (ui.hasPoint()) { ui.removePoint(); ui.status.textContent = ''; }
			}
			if (currentValue()) save('');
			return;
		}

		var anchor = document.querySelector('.wp-block-woocommerce-checkout-shipping-address-block');
		if (!anchor) return;
		if (!ui) ui = build();
		if (anchor.nextElementSibling !== ui.box) anchor.insertAdjacentElement('afterend', ui.box);
		if (ui.box.hidden) ui.box.hidden = false;
		followAddress();
	}

	// The checkout renders with React; run sync at most once per frame.
	var queued = false;
	function schedule() {
		if (queued) return;
		queued = true;
		requestAnimationFrame(function () { queued = false; sync(); });
	}
	new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
	wp.data.subscribe(schedule);
	schedule();
})();
