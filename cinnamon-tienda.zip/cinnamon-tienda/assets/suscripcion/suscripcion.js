/* Coffee subscription form ([cinnamon_suscripcion], includes/suscripcion.php):
 * zone from department and city, plans available in that zone, live price,
 * grind, interior delivery and, without Mercado Pago links, the WhatsApp message. */
(function () {
	'use strict';

	var form = document.getElementById('suscripcion');
	var data = window.cinnamonSuscripcion;
	if (!form || !data) return;
	var mp = form.dataset.mode === 'mp';

	// Same as cinnamon_tienda_normalize_place().
	function normalize(text) {
		return String(text || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
	}
	function money(n) { return '$' + Math.round(n).toLocaleString('es-UY'); }
	function field(name) { return form.querySelector('[name="' + name + '"]'); }
	function picked(name) { var el = form.querySelector('[name="' + name + '"]:checked'); return el ? el.value : ''; }

	// Same rules as cinnamon_sub_zone() and cinnamon_tienda_depunta_covers().
	function zone() {
		if (!mp) return '';
		var state = field('departamento').value, city = normalize(field('ciudad').value);
		if (!state) return '';
		if (state === 'UY-MO' || (state === 'UY-CA' && data.costa.indexOf(city) !== -1)) return 'mvd';
		return 'int';
	}
	function depunta() {
		var city = normalize(field('ciudad').value).replace(/\s*-\s*canelones$/, '');
		return city !== '' && data.depunta.indexOf(city) !== -1;
	}

	// Without links every plan is offered (it goes by WhatsApp); with links, only those with a link in the zone.
	function offered(row, z) {
		if (!mp) return true;
		return z ? row.ok[z] : row.ok.mvd || row.ok.int;
	}
	function find(plan, size) {
		return data.plans.filter(function (r) { return r.plan === plan && r.size === size; })[0];
	}

	function setDisabled(name, isOff) {
		var first = null;
		form.querySelectorAll('[name="' + name + '"]').forEach(function (input) {
			var off = isOff(input.value);
			input.disabled = off;
			input.closest('.sub-option').classList.toggle('is-disabled', off);
			if (off && input.checked) input.checked = false;
			if (!off && !first) first = input;
		});
		if (!picked(name) && first) first.checked = true;
	}

	function update() {
		var z = zone();
		setDisabled('plan', function (plan) {
			return !data.plans.some(function (r) { return r.plan === plan && offered(r, z); });
		});
		setDisabled('size', function (size) {
			var row = find(picked('plan'), size);
			return !row || !offered(row, z);
		});

		var ground = picked('presentacion') === 'molido';
		form.querySelector('.sub-grind').hidden = !ground;
		var grind = ground ? 'molido para ' + field('molienda').value : 'en grano';

		if (mp) {
			var interior = form.querySelector('.sub-interior');
			interior.hidden = z !== 'int';
			var dp = form.querySelector('[name="envio"][value="depunta"]');
			var dpOk = depunta();
			dp.closest('.sub-option').hidden = !dpOk;
			dp.disabled = !dpOk;
			if (!dpOk && dp.checked) dp.checked = false;
			form.querySelectorAll('[name="envio"]').forEach(function (r) { r.required = z === 'int'; });
			var agency = field('agencia');
			var needsAgency = z === 'int' && picked('envio') === 'tres-cruces';
			agency.closest('.sub-field').hidden = !needsAgency;
			agency.required = needsAgency;
		}

		var row = find(picked('plan'), picked('size'));
		var price = form.querySelector('.sub-price');
		if (!row) {
			price.textContent = '';
		} else if (z === 'mvd') {
			price.textContent = row.plan + ' · ' + row.size + ': ' + money(row.mvd) + ' por mes, envío incluido.';
		} else if (z === 'int') {
			price.textContent = row.plan + ' · ' + row.size + ': ' + money(row.int) + ' por mes, más el envío al recibir.';
		} else {
			price.textContent = row.plan + ' · ' + row.size + ': ' + money(row.mvd) + ' por mes en Montevideo y Ciudad de la Costa (envío incluido), ' + money(row.int) + ' en el Interior (más el envío al recibir).';
		}

		if (!mp && row) {
			var text = form.dataset.intro + ': ' + row.plan + ', ' + row.size + ' por mes, ' + grind + '.';
			form.querySelector('.sub-send').href = form.dataset.wa + '?text=' + encodeURIComponent(text);
		}
	}

	form.addEventListener('change', update);
	form.addEventListener('input', function (e) { if (e.target.name === 'ciudad') update(); });
	if (mp) {
		// The grind travels as one value: "en grano" or "molido para …".
		form.addEventListener('submit', function () {
			if (picked('presentacion') !== 'molido') field('molienda').disabled = true;
		});
	}
	update();
})();
