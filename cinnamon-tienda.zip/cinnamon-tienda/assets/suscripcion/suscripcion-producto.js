/* Product subscription block (includes/suscripcion-producto.php): asks the
 * store which ways of receiving the presentation has at the typed address,
 * with the monthly total of each, and shows the agency field when needed. */
(function () {
	'use strict';

	var form = document.querySelector('.psub__form');
	var data = window.cinnamonSuscripcionProducto;
	if (!form || !data) return;

	var ways = form.querySelector('.psub__ways');
	var hint = ways.querySelector('.psub__hint');
	var price = form.querySelector('.sub-price');
	var send = form.querySelector('.sub-send');
	var agency = form.querySelector('[name="agencia"]');
	var wanted = form.querySelector('[name="forma_elegida"]').value;
	var timer = null, asked = 0;

	function field(name) { return form.querySelector('[name="' + name + '"]'); }
	function picked(name) { var el = form.querySelector('[name="' + name + '"]:checked'); return el ? el.value : ''; }

	function clearWays() { ways.querySelectorAll('.sub-option').forEach(function (o) { o.remove(); }); }

	function refresh() {
		var chosen = picked('forma');
		var needsAgency = chosen === 'agencia';
		agency.closest('.sub-field').hidden = !needsAgency;
		agency.required = needsAgency;
		var input = form.querySelector('[name="forma"]:checked');
		price.textContent = input ? 'Total: ' + input.dataset.amount + ' por mes (' + input.dataset.note + ').' : '';
		send.disabled = !input;
	}

	function load() {
		var state = field('departamento').value, city = field('ciudad').value.trim();
		var keep = picked('forma') || wanted;
		if (!state || !city) {
			clearWays();
			hint.hidden = false;
			hint.textContent = 'Completá departamento y ciudad para ver las formas de envío y el total por mes.';
			refresh();
			return;
		}
		var n = ++asked;
		var url = data.ajax + '?action=cinnamon_psub_options&producto=' + data.product
			+ '&presentacion=' + encodeURIComponent(picked('presentacion'))
			+ '&departamento=' + encodeURIComponent(state) + '&ciudad=' + encodeURIComponent(city);
		fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (res) {
			if (n !== asked) return; // An older answer arrived late.
			clearWays();
			var list = res && res.success ? res.data : [];
			hint.hidden = list.length > 0;
			hint.textContent = 'Para esa dirección todavía no hay suscripción disponible. Escribinos por WhatsApp.';
			list.forEach(function (w) {
				var label = document.createElement('label');
				label.className = 'sub-option psub__way';
				var input = document.createElement('input');
				input.type = 'radio';
				input.name = 'forma';
				input.value = w.kind;
				input.required = true;
				input.dataset.amount = w.amount;
				input.dataset.note = w.note;
				if (w.kind === keep) input.checked = true;
				var span = document.createElement('span');
				span.innerHTML = '<strong></strong>&nbsp;· <span class="psub__amount"></span>';
				span.querySelector('strong').textContent = w.label;
				span.querySelector('.psub__amount').textContent = w.amount + ' por mes';
				label.appendChild(input);
				label.appendChild(document.createTextNode(' '));
				label.appendChild(span);
				ways.appendChild(label);
			});
			if (!picked('forma') && list.length === 1) ways.querySelector('[name="forma"]').checked = true;
			wanted = '';
			refresh();
		}).catch(function () { /* Keep what is shown; the server checks again on submit. */ });
	}

	form.addEventListener('change', function (e) {
		if (e.target.name === 'forma') refresh();
		else if (e.target.name === 'presentacion' || e.target.name === 'departamento') load();
	});
	form.addEventListener('input', function (e) {
		if (e.target.name !== 'ciudad') return;
		clearTimeout(timer);
		timer = setTimeout(load, 400);
	});
	load();
})();
