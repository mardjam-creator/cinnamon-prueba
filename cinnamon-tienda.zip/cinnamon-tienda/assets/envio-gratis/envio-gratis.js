/* Free shipping bar in the block checkout order summary (Dash Pack rates only). */
(function () {
	'use strict';

	var cfg = window.cinnamonEnvioGratis;
	var wc = window.wc;
	if (!cfg || !window.wp || !wp.plugins || !wp.element || !wp.data || !wc || !wc.blocksCheckout || !wc.blocksCheckout.ExperimentalOrderMeta) return;

	var el = wp.element.createElement;
	var STORE = 'wc/store/cart';

	// "$1.850" or "$281,25", like the shop's prices.
	function money(amount, totals) {
		var parts = amount.toFixed(totals.currency_minor_unit).split('.');
		var whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, totals.currency_thousand_separator);
		var cents = parts[1] && !/^0+$/.test(parts[1]) ? totals.currency_decimal_separator + parts[1] : '';
		return totals.currency_prefix + whole + cents + totals.currency_suffix;
	}

	function itemName(item) {
		var weight = (item.variation || []).map(function (v) { return v.value; }).join(', ');
		return weight ? item.name + ' · ' + weight : item.name;
	}

	function FreeShippingBar() {
		var cart = wp.data.useSelect(function (select) { return select(STORE).getCartData(); }, []);
		var busy = wp.element.useState(null);
		if (!cart || !cart.totals) return null;

		var rate = null;
		(cart.shippingRates || []).forEach(function (pkg) {
			(pkg.shipping_rates || []).forEach(function (r) { if (r.selected) rate = r; });
		});
		var minimum = rate ? cfg.minimums[rate.instance_id] : undefined;
		if (minimum === undefined) return null;

		// Same amount the free shipping rule measures: products with taxes, after coupons.
		var t = cart.totals;
		var unit = Math.pow(10, t.currency_minor_unit);
		var total = (Number(t.total_items) + Number(t.total_items_tax) - Number(t.total_discount) - Number(t.total_discount_tax)) / unit;
		var missing = Math.max(0, minimum - total);
		var percent = Math.min(100, Math.round((total / minimum) * 100));

		if (missing <= 0) {
			return el('div', { className: 'cin-fs is-free', role: 'status' },
				el('p', { className: 'cin-fs__title' }, '¡Tu pedido tiene envío gratis con ' + cfg.carrier + '!')
			);
		}

		function add(item) {
			busy[1](item.key);
			Promise.resolve(wp.data.dispatch(STORE).changeCartItemQuantity(item.key, item.quantity + 1))
				.catch(function () {})
				.then(function () { busy[1](null); });
		}

		var rows = (cart.items || []).map(function (item) {
			var price = Number(item.prices.price) / Math.pow(10, item.prices.currency_minor_unit);
			var max = item.quantity_limits && item.quantity_limits.maximum;
			var reaches = price >= missing;
			return el('li', { key: item.key, className: 'cin-fs__item' + (reaches ? ' reaches' : '') },
				el('span', { className: 'cin-fs__name' }, itemName(item),
					reaches ? el('span', { className: 'cin-fs__tag' }, 'con este llegás') : null),
				el('span', { className: 'cin-fs__price' }, '+' + money(price, t)),
				el('button', {
					type: 'button',
					className: 'cin-fs__add',
					disabled: busy[0] !== null || (max && item.quantity >= max),
					'aria-label': 'Sumar una unidad de ' + itemName(item),
					onClick: function () { add(item); }
				}, busy[0] === item.key ? '…' : '+1')
			);
		});

		return el('div', { className: 'cin-fs' },
			el('p', { className: 'cin-fs__title', 'aria-live': 'polite' },
				'Te faltan ', el('strong', null, money(missing, t)), ' para el envío gratis con ' + cfg.carrier),
			el('div', {
				className: 'cin-fs__track',
				role: 'progressbar',
				'aria-label': 'Avance hacia el envío gratis',
				'aria-valuemin': 0,
				'aria-valuemax': 100,
				'aria-valuenow': percent,
				'aria-valuetext': money(total, t) + ' de ' + money(minimum, t)
			}, el('span', { className: 'cin-fs__fill', style: { width: percent + '%' } })),
			el('p', { className: 'cin-fs__scale' }, money(total, t) + ' de ' + money(minimum, t)),
			rows.length ? el('p', { className: 'cin-fs__hint' }, 'Sumá una unidad:') : null,
			rows.length ? el('ul', { className: 'cin-fs__items' }, rows) : null
		);
	}

	wp.plugins.registerPlugin('cinnamon-envio-gratis', {
		scope: 'woocommerce-checkout',
		render: function () {
			return el(wc.blocksCheckout.ExperimentalOrderMeta, null, el(FreeShippingBar));
		}
	});
})();
