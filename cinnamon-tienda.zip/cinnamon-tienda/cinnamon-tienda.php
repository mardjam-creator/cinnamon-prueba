<?php
/**
 * Plugin Name: Cinnamon – Configuración de tienda
 * Description: Deja lista la tienda de Cinnamon en una instalación nueva: categorías, páginas, envíos por zona, medios de pago y productos de ejemplo. También aplica la regla de envío gratis por monto en cada zona. Mantenelo activo.
 * Version: 1.12.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: Cinnamon Boutique Gourmet
 * License: GPLv2 or later
 * Text Domain: cinnamon-tienda
 *
 * @package cinnamon-tienda
 */

defined( 'ABSPATH' ) || exit;

define( 'CINNAMON_TIENDA_DIR', plugin_dir_path( __FILE__ ) );
define( 'CINNAMON_TIENDA_VERSION', '1.12.0' );

require_once CINNAMON_TIENDA_DIR . 'includes/content.php';
require_once CINNAMON_TIENDA_DIR . 'includes/setup.php';
require_once CINNAMON_TIENDA_DIR . 'includes/mapa.php';
require_once CINNAMON_TIENDA_DIR . 'includes/busqueda.php';
require_once CINNAMON_TIENDA_DIR . 'includes/agencia.php';
require_once CINNAMON_TIENDA_DIR . 'includes/depunta.php';
require_once CINNAMON_TIENDA_DIR . 'includes/peso.php';
require_once CINNAMON_TIENDA_DIR . 'includes/envio-gratis.php';
require_once CINNAMON_TIENDA_DIR . 'includes/suscripcion.php';
require_once CINNAMON_TIENDA_DIR . 'includes/suscripcion-producto.php';

/**
 * Free shipping above an amount, per shipping method instance.
 * The thresholds are saved by the setup (option cinnamon_free_shipping_from).
 *
 * @param array<string,WC_Shipping_Rate> $rates   Rates.
 * @param array                          $package Package.
 * @return array
 */
function cinnamon_tienda_free_shipping( $rates, $package ) {
	$thresholds = (array) get_option( 'cinnamon_free_shipping_from', array() );
	if ( ! $thresholds ) {
		return $rates;
	}
	// Products total with taxes and after coupons, like "compras iguales o mayores a $2.500".
	$total = 0;
	foreach ( $package['contents'] as $item ) {
		$total += (float) $item['line_total'] + (float) $item['line_tax'];
	}
	foreach ( $rates as $rate ) {
		$from = $thresholds[ $rate->get_instance_id() ] ?? null;
		if ( null !== $from && $total >= (float) $from ) {
			$rate->set_cost( 0 );
			$rate->set_taxes( array() );
		}
	}
	return $rates;
}
add_filter( 'woocommerce_package_rates', 'cinnamon_tienda_free_shipping', 20, 2 );

/**
 * Uruguayan addresses: postcode optional (most customers don't know theirs).
 * The block checkout and the server-side validation both read this locale.
 *
 * @param array $locale Locale settings per country.
 * @return array
 */
function cinnamon_tienda_address_locale( $locale ) {
	$locale['UY']['postcode']['required'] = false;
	return $locale;
}
add_filter( 'woocommerce_get_country_locale', 'cinnamon_tienda_address_locale' );

/**
 * Admin screen: Herramientas > Configurar Cinnamon.
 */
function cinnamon_tienda_menu() {
	add_management_page( 'Configurar Cinnamon', 'Configurar Cinnamon', 'manage_woocommerce', 'cinnamon-tienda', 'cinnamon_tienda_screen' );
}
add_action( 'admin_menu', 'cinnamon_tienda_menu' );

/**
 * Steps the screen offers, in order.
 *
 * @return array<string,string>
 */
function cinnamon_tienda_steps() {
	return array(
		'idioma'     => 'Idioma: Español (Argentina). WooCommerce no tiene traducción para Uruguay; la de Argentina es la más cercana',
		'ajustes'    =>'Ajustes de la tienda: pesos uruguayos, dirección, zona horaria y enlaces (/tienda, /categoria, /producto)',
		'categorias' => 'Categorías de productos (las mismas que cinnamon.uy)',
		'paginas'    => 'Páginas: Inicio, Sobre nosotros, Envíos, Contacto, Ofertas, Política de privacidad, y nombres en español para Tienda, Carrito, Finalizar compra y Mi cuenta',
		'envios'     => 'Zonas de envío: Montevideo, Canelones, Maldonado e Interior, con agencia a elección, retiro en el local y envío gratis por monto',
		'pagos'      => 'Medios de pago: transferencia bancaria',
		'mercadopago' => 'Mercado Pago: instalar y activar el plugin oficial "Mercado Pago payments for WooCommerce" (las credenciales se cargan después en su pantalla)',
		'productos'  => 'Productos de ejemplo: los 6 productos con precios reales del borrador anterior',
		'limpiar'    => 'Borrar el contenido de ejemplo de WordPress ("Hola mundo" y "Página de ejemplo")',
	);
}

/**
 * Renders the setup screen and runs the chosen steps.
 */
function cinnamon_tienda_screen() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$report = array();
	if ( isset( $_POST['cinnamon_tienda_run'] ) ) {
		check_admin_referer( 'cinnamon_tienda_run' );
		$chosen = array_map( 'sanitize_key', (array) wp_unslash( $_POST['steps'] ?? array() ) );
		$report = cinnamon_tienda_run( $chosen );
	}
	$done = (array) get_option( 'cinnamon_tienda_done', array() );
	?>
	<div class="wrap">
		<h1>Configurar Cinnamon</h1>
		<p>Ejecutá estos pasos una vez, en una instalación nueva con WooCommerce activo. Se pueden repetir sin duplicar nada: cada paso actualiza lo que ya existe.</p>
		<?php if ( $report ) : ?>
			<div class="notice notice-success"><ul style="list-style:disc;padding-left:1.5em">
				<?php foreach ( $report as $line ) : ?>
					<li><?php echo esc_html( $line ); ?></li>
				<?php endforeach; ?>
			</ul></div>
		<?php endif; ?>
		<form method="post">
			<?php wp_nonce_field( 'cinnamon_tienda_run' ); ?>
			<table class="form-table" role="presentation"><tbody>
			<?php foreach ( cinnamon_tienda_steps() as $key => $label ) : ?>
				<tr><td>
					<label><input type="checkbox" name="steps[]" value="<?php echo esc_attr( $key ); ?>" <?php checked( 'limpiar' !== $key || empty( $done['limpiar'] ) ); ?>>
					<?php echo esc_html( $label ); ?></label>
					<?php if ( ! empty( $done[ $key ] ) ) : ?>
						<span style="color:#2f6b3a"> &check; hecho el <?php echo esc_html( wp_date( 'd/m/Y H:i', $done[ $key ] ) ); ?></span>
					<?php endif; ?>
				</td></tr>
			<?php endforeach; ?>
			</tbody></table>
			<?php submit_button( 'Ejecutar pasos seleccionados', 'primary', 'cinnamon_tienda_run' ); ?>
		</form>
	</div>
	<?php
}

/**
 * WP-CLI: wp cinnamon configurar [--pasos=ajustes,categorias,...]
 */
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command(
		'cinnamon configurar',
		function ( $args, $assoc ) {
			$steps = isset( $assoc['pasos'] ) ? explode( ',', $assoc['pasos'] ) : array_keys( cinnamon_tienda_steps() );
			foreach ( cinnamon_tienda_run( $steps ) as $line ) {
				WP_CLI::log( $line );
			}
			WP_CLI::success( 'Listo.' );
		}
	);
}
