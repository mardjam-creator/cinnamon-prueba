/* "Pago con QR" option in the block checkout. Plain JS, no build step. */
(function () {
	'use strict';

	var registry = window.wc && window.wc.wcBlocksRegistry;
	var wcSettings = window.wc && window.wc.wcSettings;
	if (!registry || !wcSettings || !window.wp || !window.wp.element) return;

	var el = window.wp.element.createElement;
	var decode = (window.wp.htmlEntities && window.wp.htmlEntities.decodeEntities) || function (s) { return s; };
	var data = wcSettings.getSetting('cinnamon_qr_data', {});
	var title = decode(data.title || 'Pago con QR');

	var qrIcon = el('svg', { viewBox: '0 0 24 24', width: 22, height: 22, 'aria-hidden': 'true', style: { marginRight: '8px', flex: 'none' } },
		el('path', { fill: 'currentColor', d: 'M3 3h8v8H3zm2 2v4h4V5zm8-2h8v8h-8zm2 2v4h4V5zM3 13h8v8H3zm2 2v4h4v-4zm10-2h2v2h-2zm2 2h2v2h-2zm-2 2h2v2h-2zm4 0h2v4h-4v-2h2zm-4 2h2v2h-2zm4-6h2v2h-2z' })
	);

	var Label = function () {
		return el('span', { style: { display: 'inline-flex', alignItems: 'center' } }, qrIcon, title);
	};
	var Content = function () {
		return el('p', { className: 'cinnamon-qr-checkout' }, decode(data.description || ''));
	};

	registry.registerPaymentMethod({
		name: 'cinnamon_qr',
		label: el(Label),
		content: el(Content),
		edit: el(Content),
		canMakePayment: function () { return true; },
		ariaLabel: title,
		supports: { features: data.supports || ['products'] }
	});
})();
