/* Media library picker for the QR image field in the gateway settings. */
jQuery(function ($) {
	var $field = $('#woocommerce_cinnamon_qr_qr_image');
	if (!$field.length || !window.wp || !wp.media) return;

	var $preview = $('<img alt="" style="display:block;max-width:180px;margin-top:10px;border:1px solid #ddd;padding:6px;background:#fff">');
	var $pick = $('<button type="button" class="button" style="margin-left:6px">Elegir imagen</button>');
	$field.after($pick);
	$pick.after($preview);

	function refresh() {
		var url = $.trim($field.val());
		$preview.attr('src', url).toggle(!!url);
	}

	var frame;
	$pick.on('click', function (e) {
		e.preventDefault();
		if (!frame) {
			frame = wp.media({ title: 'Elegí la imagen del código QR', button: { text: 'Usar esta imagen' }, library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				$field.val(frame.state().get('selection').first().get('url')).trigger('change');
				refresh();
			});
		}
		frame.open();
	});
	$field.on('input change', refresh);
	refresh();
});
