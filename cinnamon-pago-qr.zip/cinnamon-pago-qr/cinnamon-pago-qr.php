<?php
/**
 * Plugin Name: Cinnamon – Pago con QR
 * Description: Medio de pago para WooCommerce: el cliente confirma el pedido y ve un código QR con el monto y las instrucciones para pagar desde la app de su banco o billetera. El pedido queda "En espera" hasta que confirmás el pago.
 * Version: 1.0.1
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: Cinnamon Boutique Gourmet
 * License: GPLv2 or later
 * Text Domain: cinnamon-pago-qr
 *
 * @package cinnamon-pago-qr
 */

defined( 'ABSPATH' ) || exit;

define( 'CINNAMON_QR_VERSION', '1.0.1' );
define( 'CINNAMON_QR_FILE', __FILE__ );
define( 'CINNAMON_QR_DIR', plugin_dir_path( __FILE__ ) );
define( 'CINNAMON_QR_URL', plugin_dir_url( __FILE__ ) );

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}
		require_once CINNAMON_QR_DIR . 'includes/class-gateway.php';
		add_filter(
			'woocommerce_payment_gateways',
			function ( $gateways ) {
				$gateways[] = 'Cinnamon_QR_Gateway';
				return $gateways;
			}
		);

		// These run on pages where WooCommerce may not have built the gateways yet.
		add_action(
			'woocommerce_view_order',
			function ( $order_id ) {
				$gateway = Cinnamon_QR_Gateway::instance();
				if ( $gateway ) {
					$gateway->view_order( $order_id );
				}
			},
			5
		);
		add_action(
			'woocommerce_email_before_order_table',
			function ( $order, $sent_to_admin, $plain_text = false ) {
				$gateway = Cinnamon_QR_Gateway::instance();
				if ( $gateway ) {
					$gateway->email_instructions( $order, $sent_to_admin, $plain_text );
				}
			},
			10,
			3
		);
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( function_exists( 'is_order_received_page' ) && ( is_order_received_page() || is_view_order_page() ) ) {
			wp_enqueue_style( 'cinnamon-qr', CINNAMON_QR_URL . 'assets/qr.css', array(), CINNAMON_QR_VERSION );
		}
	}
);

// Block checkout support.
add_action(
	'woocommerce_blocks_payment_method_type_registration',
	function ( $registry ) {
		require_once CINNAMON_QR_DIR . 'includes/class-blocks.php';
		$registry->register( new Cinnamon_QR_Blocks() );
	}
);

// Declare compatibility with WooCommerce's order storage and checkout blocks.
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', CINNAMON_QR_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', CINNAMON_QR_FILE, true );
		}
	}
);
