<?php
/**
 * "Pago con QR" in the block checkout.
 *
 * @package cinnamon-pago-qr
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Cinnamon_QR_Blocks extends AbstractPaymentMethodType {

	protected $name = 'cinnamon_qr';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_cinnamon_qr_settings', array() );
	}

	public function is_active() {
		$gateway = Cinnamon_QR_Gateway::instance();
		return $gateway && $gateway->is_available();
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'cinnamon-qr-blocks',
			CINNAMON_QR_URL . 'assets/blocks.js',
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
			CINNAMON_QR_VERSION,
			true
		);
		return array( 'cinnamon-qr-blocks' );
	}

	public function get_payment_method_data() {
		// The gateway falls back to its defaults for settings never saved.
		$gateway = Cinnamon_QR_Gateway::instance();
		return array(
			'title'       => $gateway ? $gateway->title : 'Pago con QR',
			'description' => $gateway ? $gateway->description : '',
			'supports'    => array( 'products' ),
		);
	}
}
