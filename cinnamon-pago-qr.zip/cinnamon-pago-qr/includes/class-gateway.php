<?php
/**
 * "Pago con QR" payment gateway.
 *
 * The shop uploads a static QR (from its bank or wallet). The customer places
 * the order, sees the QR with the exact amount and order number, pays from
 * their app and sends the receipt. The order waits "on hold" until the shop
 * confirms the payment.
 *
 * @package cinnamon-pago-qr
 */

defined( 'ABSPATH' ) || exit;

class Cinnamon_QR_Gateway extends WC_Payment_Gateway {

	const ID = 'cinnamon_qr';

	/** @var string */
	public $qr_image;

	/** @var string */
	public $instructions;

	/** @var string */
	public $whatsapp;

	public function __construct() {
		$this->id                 = self::ID;
		$this->has_fields         = false;
		$this->method_title       = 'Pago con QR';
		$this->method_description = 'El cliente confirma el pedido y ve tu código QR de Toke con el monto exacto para pagar desde la app de su banco. El pedido queda "En espera" hasta que confirmes el pago y lo pases a "Procesando".';
		$this->icon               = '';
		$this->supports           = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title        = $this->get_option( 'title' );
		$this->description  = $this->get_option( 'description' );
		$this->qr_image     = $this->get_option( 'qr_image' );
		$this->instructions = $this->get_option( 'instructions' );
		$this->whatsapp     = preg_replace( '/\D/', '', (string) $this->get_option( 'whatsapp' ) );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
	}

	/**
	 * The configured gateway instance, loading WooCommerce's gateways if needed.
	 *
	 * @return self|null
	 */
	public static function instance() {
		$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		return $gateways[ self::ID ] ?? null;
	}

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'      => array(
				'title'   => 'Activar',
				'type'    => 'checkbox',
				'label'   => 'Ofrecer el pago con QR',
				'default' => 'no',
			),
			'title'        => array(
				'title'   => 'Título',
				'type'    => 'text',
				'default' => 'Pago con QR (Toke)',
			),
			'description'  => array(
				'title'       => 'Descripción en el checkout',
				'type'        => 'textarea',
				'description' => 'Se muestra al elegir este medio de pago, antes de confirmar el pedido.',
				'default'     => 'Pagá con Toke desde la app de tu banco. Al confirmar el pedido te mostramos el código QR y el monto exacto.',
			),
			'qr_image'     => array(
				'title'       => 'Imagen del código QR',
				'type'        => 'text',
				'description' => 'Tu QR de cobro de Toke, en PNG o JPG. Usá "Elegir imagen" para subirlo. Mientras no haya una imagen, este medio de pago no se ofrece.',
				'default'     => '',
				'class'       => 'cinnamon-qr-image-field',
			),
			'instructions' => array(
				'title'       => 'Instrucciones',
				'type'        => 'textarea',
				'description' => 'Se muestran junto al QR después de confirmar el pedido y en el mail. Podés usar {total} para el monto y {pedido} para el número de pedido. Una línea por paso.',
				'default'     => "Abrí la app de tu banco y entrá a \"Pagar con Toke\".\nEscaneá el código QR.\nIngresá el monto exacto: {total}.\nConfirmá el pago y envianos el comprobante indicando el pedido N.º {pedido}.",
				'css'         => 'min-height:120px',
			),
			'whatsapp'     => array(
				'title'       => 'WhatsApp para el comprobante',
				'type'        => 'text',
				'description' => 'Número con código de país, por ejemplo 59896181666. Vacío = sin botón de WhatsApp.',
				'default'     => '59896181666',
			),
		);
	}

	/**
	 * Only offered once a QR image is configured.
	 */
	public function is_available() {
		return parent::is_available() && '' !== trim( (string) $this->qr_image );
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		// "On hold" also reserves the stock until the payment is confirmed.
		$order->update_status( 'on-hold', 'Esperando el pago con QR y el comprobante del cliente.' );
		WC()->cart->empty_cart();
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * QR, amount and steps for an order.
	 *
	 * @param WC_Order $order Order.
	 * @param bool     $for_email Email-safe markup (inline styles, no buttons script).
	 * @return string
	 */
	/**
	 * Order total as plain text ("$4.321,25"), without HTML entities.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function plain_total( $order ) {
		$html = wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) );
		return trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ) );
	}

	public function payment_box( $order, $for_email = false ) {
		$total  = self::plain_total( $order );
		$number = $order->get_order_number();
		$steps  = array_filter( array_map( 'trim', explode( "\n", (string) $this->instructions ) ) );
		$steps  = array_map( fn( $s ) => str_replace( array( '{total}', '{pedido}' ), array( $total, $number ), $s ), $steps );

		$wa_url = '';
		if ( $this->whatsapp ) {
			$msg    = sprintf( 'Hola Cinnamon, ya pagué con QR el pedido N.º %s por %s. Les envío el comprobante.', $number, $total );
			$wa_url = 'https://wa.me/' . $this->whatsapp . '?text=' . rawurlencode( $msg );
		}

		if ( $for_email ) {
			$html  = '<div style="margin:0 0 24px;padding:16px;border:1px solid #e8dccb;border-radius:10px">';
			$html .= '<h2 style="margin:0 0 8px">Pagá tu pedido con QR</h2>';
			$html .= '<p style="margin:0 0 12px">Monto a pagar: <strong>' . esc_html( $total ) . '</strong> · Pedido N.º <strong>' . esc_html( $number ) . '</strong></p>';
			$html .= '<p style="margin:0 0 12px"><img src="' . esc_url( $this->qr_image ) . '" alt="Código QR para pagar" width="220" style="width:220px;height:auto"></p>';
			$html .= '<ol style="margin:0 0 12px;padding-left:20px">';
			foreach ( $steps as $step ) {
				$html .= '<li>' . esc_html( $step ) . '</li>';
			}
			$html .= '</ol>';
			if ( $wa_url ) {
				$html .= '<p style="margin:0"><a href="' . esc_url( $wa_url ) . '">Enviar el comprobante por WhatsApp</a></p>';
			}
			return $html . '</div>';
		}

		ob_start();
		?>
		<section class="cinnamon-qr" aria-labelledby="cinnamon-qr-title">
			<h2 id="cinnamon-qr-title" class="cinnamon-qr__title">Pagá tu pedido con QR</h2>
			<div class="cinnamon-qr__body">
				<figure class="cinnamon-qr__code">
					<img src="<?php echo esc_url( $this->qr_image ); ?>" alt="Código QR para pagar el pedido">
				</figure>
				<div class="cinnamon-qr__info">
					<p class="cinnamon-qr__amount"><span>Monto a pagar</span><strong><?php echo esc_html( $total ); ?></strong></p>
					<p class="cinnamon-qr__order">Pedido N.º <strong><?php echo esc_html( $number ); ?></strong></p>
					<ol class="cinnamon-qr__steps">
						<?php foreach ( $steps as $step ) : ?>
							<li><?php echo esc_html( $step ); ?></li>
						<?php endforeach; ?>
					</ol>
					<?php if ( $wa_url ) : ?>
						<a class="cinnamon-qr__wa" href="<?php echo esc_url( $wa_url ); ?>" target="_blank" rel="noopener">Enviar el comprobante por WhatsApp</a>
					<?php endif; ?>
					<p class="cinnamon-qr__note">Preparamos tu pedido cuando confirmamos el pago. Te avisamos por mail.</p>
				</div>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && $order->has_status( 'on-hold' ) ) {
			echo $this->payment_box( $order ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
		}
	}

	/**
	 * "Mi cuenta" > order: same box while the payment is pending.
	 *
	 * @param int $order_id Order ID.
	 */
	public function view_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && self::ID === $order->get_payment_method() && $order->has_status( 'on-hold' ) ) {
			echo $this->payment_box( $order ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
		}
	}

	/**
	 * Customer "on hold" email: QR and steps above the order table.
	 *
	 * @param WC_Order $order         Order.
	 * @param bool     $sent_to_admin Sent to the shop.
	 * @param bool     $plain_text    Plain text email.
	 */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		if ( $sent_to_admin || self::ID !== $order->get_payment_method() || ! $order->has_status( 'on-hold' ) ) {
			return;
		}
		if ( $plain_text ) {
			$total = self::plain_total( $order );
			echo "Pagá tu pedido con QR\n";
			echo 'Monto a pagar: ' . esc_html( $total ) . ' · Pedido N.º ' . esc_html( $order->get_order_number() ) . "\n";
			echo 'Código QR: ' . esc_url_raw( $this->qr_image ) . "\n\n";
			echo esc_html( str_replace( array( '{total}', '{pedido}' ), array( $total, $order->get_order_number() ), (string) $this->instructions ) ) . "\n\n";
			return;
		}
		echo $this->payment_box( $order, true ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside.
	}

	/**
	 * Media picker on the gateway settings screen.
	 *
	 * @param string $hook Admin page.
	 */
	public function admin_scripts( $hook ) {
		if ( 'woocommerce_page_wc-settings' !== $hook || ( $_GET['section'] ?? '' ) !== self::ID ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'cinnamon-qr-admin', CINNAMON_QR_URL . 'assets/admin.js', array( 'jquery' ), CINNAMON_QR_VERSION, true );
	}

}
